using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Text; 
using System.Data;
using System.Data.SqlClient;
 

namespace CodeGen
{
	/// <summary>
	/// Summary description for frmStoredProcGenerator.
	/// </summary>
	public class frmStoredProcGenerator : System.Windows.Forms.Form
	{
		private System.Windows.Forms.Panel panel1;
		private System.Windows.Forms.Button btnClose;
		private System.Windows.Forms.RichTextBox txtStoredProcedure;
		private System.Windows.Forms.ComboBox cmbTables;
		private System.Windows.Forms.CheckedListBox chklstTableFields;
		private System.Windows.Forms.TextBox textBox1;
		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.Label label2;
		private System.Windows.Forms.Label label3;
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		// Vaariables required to declare Program variables
		string sqlconstring;
		string Sqlqry,Sqlqry1;
		SqlConnection sqlconnection= new SqlConnection();
		SqlDataAdapter da= new SqlDataAdapter();
		private System.Windows.Forms.Button btnReset;
		private System.Windows.Forms.Button btnClear;
		private System.Windows.Forms.Button btnGenerate;
		private System.Windows.Forms.Button button1;
		DataSet ds = new DataSet();

		public frmStoredProcGenerator()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			//
			// TODO: Add any constructor code after InitializeComponent call
			//
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if(components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.panel1 = new System.Windows.Forms.Panel();
			this.txtStoredProcedure = new System.Windows.Forms.RichTextBox();
			this.btnReset = new System.Windows.Forms.Button();
			this.btnClose = new System.Windows.Forms.Button();
			this.cmbTables = new System.Windows.Forms.ComboBox();
			this.chklstTableFields = new System.Windows.Forms.CheckedListBox();
			this.textBox1 = new System.Windows.Forms.TextBox();
			this.label1 = new System.Windows.Forms.Label();
			this.label2 = new System.Windows.Forms.Label();
			this.label3 = new System.Windows.Forms.Label();
			this.btnClear = new System.Windows.Forms.Button();
			this.btnGenerate = new System.Windows.Forms.Button();
			this.button1 = new System.Windows.Forms.Button();
			this.panel1.SuspendLayout();
			this.SuspendLayout();
			// 
			// panel1
			// 
			this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.panel1.Controls.Add(this.txtStoredProcedure);
			this.panel1.Location = new System.Drawing.Point(8, 224);
			this.panel1.Name = "panel1";
			this.panel1.Size = new System.Drawing.Size(496, 184);
			this.panel1.TabIndex = 1;
			// 
			// txtStoredProcedure
			// 
			this.txtStoredProcedure.Location = new System.Drawing.Point(8, 8);
			this.txtStoredProcedure.Name = "txtStoredProcedure";
			this.txtStoredProcedure.ScrollBars = System.Windows.Forms.RichTextBoxScrollBars.ForcedBoth;
			this.txtStoredProcedure.Size = new System.Drawing.Size(480, 168);
			this.txtStoredProcedure.TabIndex = 5;
			this.txtStoredProcedure.Text = "";
			// 
			// btnReset
			// 
			this.btnReset.Location = new System.Drawing.Point(336, 192);
			this.btnReset.Name = "btnReset";
			this.btnReset.Size = new System.Drawing.Size(80, 24);
			this.btnReset.TabIndex = 2;
			this.btnReset.Text = "Reset";
			this.btnReset.Click += new System.EventHandler(this.btnDispaly_Click);
			// 
			// btnClose
			// 
			this.btnClose.Location = new System.Drawing.Point(424, 192);
			this.btnClose.Name = "btnClose";
			this.btnClose.Size = new System.Drawing.Size(80, 24);
			this.btnClose.TabIndex = 3;
			this.btnClose.Text = "&Close";
			this.btnClose.Click += new System.EventHandler(this.btnClose_Click);
			// 
			// cmbTables
			// 
			this.cmbTables.Location = new System.Drawing.Point(112, 48);
			this.cmbTables.Name = "cmbTables";
			this.cmbTables.Size = new System.Drawing.Size(184, 21);
			this.cmbTables.TabIndex = 4;
			this.cmbTables.SelectedIndexChanged += new System.EventHandler(this.cmbTables_SelectedIndexChanged);
			// 
			// chklstTableFields
			// 
			this.chklstTableFields.CheckOnClick = true;
			this.chklstTableFields.HorizontalScrollbar = true;
			this.chklstTableFields.Location = new System.Drawing.Point(112, 80);
			this.chklstTableFields.Name = "chklstTableFields";
			this.chklstTableFields.Size = new System.Drawing.Size(184, 94);
			this.chklstTableFields.TabIndex = 5;
			// 
			// textBox1
			// 
			this.textBox1.Location = new System.Drawing.Point(112, 16);
			this.textBox1.Name = "textBox1";
			this.textBox1.Size = new System.Drawing.Size(184, 20);
			this.textBox1.TabIndex = 6;
			this.textBox1.Text = "";
			// 
			// label1
			// 
			this.label1.Location = new System.Drawing.Point(0, 16);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(104, 16);
			this.label1.TabIndex = 7;
			this.label1.Text = "St Procedure Name";
			// 
			// label2
			// 
			this.label2.Location = new System.Drawing.Point(0, 48);
			this.label2.Name = "label2";
			this.label2.Size = new System.Drawing.Size(104, 24);
			this.label2.TabIndex = 8;
			this.label2.Text = "St Procedure Table";
			// 
			// label3
			// 
			this.label3.Location = new System.Drawing.Point(0, 80);
			this.label3.Name = "label3";
			this.label3.Size = new System.Drawing.Size(104, 32);
			this.label3.TabIndex = 9;
			this.label3.Text = "Stored Procedure Parameter";
			// 
			// btnClear
			// 
			this.btnClear.Location = new System.Drawing.Point(248, 192);
			this.btnClear.Name = "btnClear";
			this.btnClear.Size = new System.Drawing.Size(80, 24);
			this.btnClear.TabIndex = 10;
			this.btnClear.Text = "Clear";
			this.btnClear.Click += new System.EventHandler(this.btnClear_Click);
			// 
			// btnGenerate
			// 
			this.btnGenerate.Location = new System.Drawing.Point(160, 192);
			this.btnGenerate.Name = "btnGenerate";
			this.btnGenerate.Size = new System.Drawing.Size(80, 24);
			this.btnGenerate.TabIndex = 11;
			this.btnGenerate.Text = "&Generate";
			this.btnGenerate.Click += new System.EventHandler(this.btnGenerate_Click);
			// 
			// button1
			// 
			this.button1.Location = new System.Drawing.Point(304, 104);
			this.button1.Name = "button1";
			this.button1.Size = new System.Drawing.Size(64, 24);
			this.button1.TabIndex = 12;
			this.button1.Text = "Select All";
			// 
			// frmStoredProcGenerator
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(512, 414);
			this.Controls.Add(this.button1);
			this.Controls.Add(this.btnGenerate);
			this.Controls.Add(this.btnClear);
			this.Controls.Add(this.label3);
			this.Controls.Add(this.label2);
			this.Controls.Add(this.label1);
			this.Controls.Add(this.textBox1);
			this.Controls.Add(this.chklstTableFields);
			this.Controls.Add(this.cmbTables);
			this.Controls.Add(this.btnClose);
			this.Controls.Add(this.btnReset);
			this.Controls.Add(this.panel1);
			this.Name = "frmStoredProcGenerator";
			this.Text = "Stored Procedure Generator";
			this.Load += new System.EventHandler(this.frmStoredProcGenerator_Load);
			this.panel1.ResumeLayout(false);
			this.ResumeLayout(false);

		}
		#endregion
		
		[STAThread]
		static void Main() 
		{
			Application.Run(new frmStoredProcGenerator());
		}
		
		private void btnClose_Click(object sender, System.EventArgs e)
		{
			Close(); 
		}
		
		private void btnDispaly_Click(object sender, System.EventArgs e)
		{
			
		}

		private void frmStoredProcGenerator_Load(object sender, System.EventArgs e)
		{
			// Open a Pemanant Connection
			sqlconstring = System.Configuration.ConfigurationSettings.AppSettings["ConnectionString"] + ";initial catalog=ProjectMaint";
			//sqlconstring = "workstation id=SW1;packet size=4096;user id=sa;data source=devserver;persist security info=False;initial catalog=GovOvrDB";
			sqlconnection= new SqlConnection(sqlconstring);
			sqlconnection.Open();
			Sqlqry="";
			Sqlqry= "SELECT * FROM Information_Schema.Tables WHERE (Table_Type = 'BASE TABLE')"; 
			da= new SqlDataAdapter(Sqlqry,sqlconnection); 
			da.Fill (ds,"DataTables");
			      
			for (int i=0;i<=ds.Tables["DataTables"].Rows.Count-1 ;i++)
			{
				cmbTables.Items.Add(ds.Tables["DataTables"].Rows[i]["Table_Name"].ToString()); 
			}
		}

		private void cmbTables_SelectedIndexChanged(object sender, System.EventArgs e)
		{
				
			
			Sqlqry1="select column_name,data_Type, case when Character_Maximum_Length is null " +    
				" then 0 when data_Type like '%char' then Character_Maximum_Length " + 
				" else 0 end as max_length from  INFORMATION_SCHEMA.COLUMNS " +
				" where table_name='" +cmbTables.Text.ToString()   +"' order by ordinal_position";
							
			da= new SqlDataAdapter(Sqlqry1,sqlconnection); 
			da.Fill (ds,"DataType");

			chklstTableFields.Items.Clear();  
			for (int i=0;i<=ds.Tables["DataType"].Rows.Count-1;i++)
			{
				chklstTableFields.Items.Add(ds.Tables["DataType"].Rows[i]["column_name"].ToString()); 
			}
		}

		private void btnGenerate_Click(object sender, System.EventArgs e)
		{
			string comments,purpose,logic,space="   ";
			string createdBy,createdOn,lastModifyBy,lastModifyOn,changeHistory;
			string procedureName="Main",inputParametrs="dummy"; 
			
					
			purpose="Used for";
			logic="";
			createdBy="Prashant";
			createdOn="24/02/2005";
			lastModifyBy="None";
			lastModifyOn="None";
			changeHistory="None";

			StringBuilder stringBuilder= new StringBuilder();
			stringBuilder.Append("/**********************************************************************************************\n");

			stringBuilder.Append("Purpose : " + space + purpose +"\n");
			stringBuilder.Append(space + "InputParameters \n");
			for(int i =0; i<=chklstTableFields.Items.Count-1;i++)
			{
				stringBuilder.Append(space + chklstTableFields.Items[i].ToString()+"\n");  
			}
			stringBuilder.Append("Logic :"+ space +logic+"\n");
			stringBuilder.Append("Created By :"+ space +createdBy+"\n");
			stringBuilder.Append("Created On :"+ space +createdOn+"\n");
			stringBuilder.Append("Last Modified By :"+ space +lastModifyBy +"\n");
			stringBuilder.Append("Last Modified On :"+ space +lastModifyOn +"\n");
			stringBuilder.Append("Change History :"+ space +changeHistory  +"\n");
			stringBuilder.Append("/**********************************************************************************************/\n\n");
			stringBuilder.Append("CREATE PROCEDURE "+procedureName+"\n");
			
			//stringBuilder.Append("@"+inputParametrs+"\n");
			for(int i =0; i<=chklstTableFields.Items.Count-1;i++)
			{
				stringBuilder.Append(space +"@"+ chklstTableFields.Items[i].ToString()+"\n");  
			}
			stringBuilder.Append("AS\n");
			
			txtStoredProcedure.Text = stringBuilder.ToString();  

	
		}

		private void btnClear_Click(object sender, System.EventArgs e)
		{
			txtStoredProcedure.Text = "";
		}
	}
}
