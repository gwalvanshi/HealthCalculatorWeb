namespace  CodeGen
{ 
	public class X1
	{
		private string x;
		/// <summary>
		///
		/// </summary>
		public string X
		{
			get
			{
				return x;
			}
			set 
			{ 
				x=value; 
			}
		}
	}
}
