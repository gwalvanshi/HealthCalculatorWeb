using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;
using System.Text;

namespace CodeGen
{
	/// <summary>
	/// Summary description for Form1.
	/// </summary>
	public class frmPropertyCodeGen : System.Windows.Forms.Form
	{
		private System.Windows.Forms.Button btnGenerate;
		private System.Windows.Forms.Button btnClear;
		private System.Windows.Forms.Button btnClearCodeWin;
		private System.Windows.Forms.Panel panel1;
		private System.Windows.Forms.TextBox txtComment;
		private System.Windows.Forms.Label label5;
		private System.Windows.Forms.ComboBox cmbDatatype;
		private System.Windows.Forms.Label label4;
		private System.Windows.Forms.ComboBox cmbAccessLevel;
		private System.Windows.Forms.TextBox txtVariableName;
		private System.Windows.Forms.TextBox txtPropertyName;
		private System.Windows.Forms.Label label3;
		private System.Windows.Forms.Label label2;
		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.Panel panel2;
		private System.Windows.Forms.RichTextBox txtCode;
		
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		public frmPropertyCodeGen()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			//
			// TODO: Add any constructor code after InitializeComponent call
			//
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if (components != null) 
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.btnGenerate = new System.Windows.Forms.Button();
			this.btnClear = new System.Windows.Forms.Button();
			this.btnClearCodeWin = new System.Windows.Forms.Button();
			this.panel1 = new System.Windows.Forms.Panel();
			this.txtComment = new System.Windows.Forms.TextBox();
			this.label5 = new System.Windows.Forms.Label();
			this.cmbDatatype = new System.Windows.Forms.ComboBox();
			this.label4 = new System.Windows.Forms.Label();
			this.cmbAccessLevel = new System.Windows.Forms.ComboBox();
			this.txtVariableName = new System.Windows.Forms.TextBox();
			this.txtPropertyName = new System.Windows.Forms.TextBox();
			this.label3 = new System.Windows.Forms.Label();
			this.label2 = new System.Windows.Forms.Label();
			this.label1 = new System.Windows.Forms.Label();
			this.panel2 = new System.Windows.Forms.Panel();
			this.txtCode = new System.Windows.Forms.RichTextBox();
			this.panel1.SuspendLayout();
			this.panel2.SuspendLayout();
			this.SuspendLayout();
			// 
			// btnGenerate
			// 
			this.btnGenerate.Cursor = System.Windows.Forms.Cursors.Hand;
			this.btnGenerate.Location = new System.Drawing.Point(16, 154);
			this.btnGenerate.Name = "btnGenerate";
			this.btnGenerate.Size = new System.Drawing.Size(80, 24);
			this.btnGenerate.TabIndex = 4;
			this.btnGenerate.Text = "&Generate";
			this.btnGenerate.Click += new System.EventHandler(this.btnGenerate_Click);
			// 
			// btnClear
			// 
			this.btnClear.Cursor = System.Windows.Forms.Cursors.Hand;
			this.btnClear.Location = new System.Drawing.Point(112, 154);
			this.btnClear.Name = "btnClear";
			this.btnClear.Size = new System.Drawing.Size(56, 24);
			this.btnClear.TabIndex = 9;
			this.btnClear.Text = "&Clear";
			this.btnClear.Click += new System.EventHandler(this.btnClear_Click);
			// 
			// btnClearCodeWin
			// 
			this.btnClearCodeWin.Cursor = System.Windows.Forms.Cursors.Hand;
			this.btnClearCodeWin.Location = new System.Drawing.Point(188, 154);
			this.btnClearCodeWin.Name = "btnClearCodeWin";
			this.btnClearCodeWin.Size = new System.Drawing.Size(140, 24);
			this.btnClearCodeWin.TabIndex = 12;
			this.btnClearCodeWin.Text = "Clear  Output Code";
			this.btnClearCodeWin.Click += new System.EventHandler(this.btnClearCodeWin_Click);
			// 
			// panel1
			// 
			this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.panel1.Controls.Add(this.txtComment);
			this.panel1.Controls.Add(this.label5);
			this.panel1.Controls.Add(this.cmbDatatype);
			this.panel1.Controls.Add(this.label4);
			this.panel1.Controls.Add(this.cmbAccessLevel);
			this.panel1.Controls.Add(this.txtVariableName);
			this.panel1.Controls.Add(this.txtPropertyName);
			this.panel1.Controls.Add(this.label3);
			this.panel1.Controls.Add(this.label2);
			this.panel1.Controls.Add(this.label1);
			this.panel1.Location = new System.Drawing.Point(8, 3);
			this.panel1.Name = "panel1";
			this.panel1.Size = new System.Drawing.Size(416, 144);
			this.panel1.TabIndex = 14;
			this.panel1.Paint += new System.Windows.Forms.PaintEventHandler(this.panel1_Paint);
			// 
			// txtComment
			// 
			this.txtComment.Location = new System.Drawing.Point(92, 117);
			this.txtComment.Name = "txtComment";
			this.txtComment.Size = new System.Drawing.Size(304, 20);
			this.txtComment.TabIndex = 21;
			this.txtComment.Text = "";
			this.txtComment.TextChanged += new System.EventHandler(this.txtComment_TextChanged);
			// 
			// label5
			// 
			this.label5.AutoSize = true;
			this.label5.Location = new System.Drawing.Point(12, 117);
			this.label5.Name = "label5";
			this.label5.Size = new System.Drawing.Size(53, 16);
			this.label5.TabIndex = 20;
			this.label5.Text = "Comment";
			this.label5.Click += new System.EventHandler(this.label5_Click);
			// 
			// cmbDatatype
			// 
			this.cmbDatatype.Items.AddRange(new object[] {
															 "string",
															 "int",
															 "double",
															 "datetime",
															 "float",
															 "SqlConnection",
															 "SqlCommand",
															 "DataTable",
															 "DataSet"});
			this.cmbDatatype.Location = new System.Drawing.Point(92, 89);
			this.cmbDatatype.Name = "cmbDatatype";
			this.cmbDatatype.Size = new System.Drawing.Size(144, 21);
			this.cmbDatatype.TabIndex = 16;
			this.cmbDatatype.SelectedIndexChanged += new System.EventHandler(this.cmbDatatype_SelectedIndexChanged);
			// 
			// label4
			// 
			this.label4.AutoSize = true;
			this.label4.Location = new System.Drawing.Point(12, 89);
			this.label4.Name = "label4";
			this.label4.Size = new System.Drawing.Size(56, 16);
			this.label4.TabIndex = 19;
			this.label4.Text = "Data Type";
			this.label4.Click += new System.EventHandler(this.label4_Click);
			// 
			// cmbAccessLevel
			// 
			this.cmbAccessLevel.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
			this.cmbAccessLevel.Items.AddRange(new object[] {
																"public",
																"private"});
			this.cmbAccessLevel.Location = new System.Drawing.Point(92, 9);
			this.cmbAccessLevel.Name = "cmbAccessLevel";
			this.cmbAccessLevel.Size = new System.Drawing.Size(144, 21);
			this.cmbAccessLevel.TabIndex = 12;
			this.cmbAccessLevel.SelectedIndexChanged += new System.EventHandler(this.cmbAccessLevel_SelectedIndexChanged);
			// 
			// txtVariableName
			// 
			this.txtVariableName.Location = new System.Drawing.Point(92, 61);
			this.txtVariableName.Name = "txtVariableName";
			this.txtVariableName.Size = new System.Drawing.Size(144, 20);
			this.txtVariableName.TabIndex = 14;
			this.txtVariableName.Text = "";
			this.txtVariableName.TextChanged += new System.EventHandler(this.txtVariableName_TextChanged);
			// 
			// txtPropertyName
			// 
			this.txtPropertyName.Location = new System.Drawing.Point(92, 35);
			this.txtPropertyName.Name = "txtPropertyName";
			this.txtPropertyName.Size = new System.Drawing.Size(144, 20);
			this.txtPropertyName.TabIndex = 13;
			this.txtPropertyName.Text = "";
			this.txtPropertyName.TextChanged += new System.EventHandler(this.txtPropertyName_TextChanged);
			// 
			// label3
			// 
			this.label3.AutoSize = true;
			this.label3.Location = new System.Drawing.Point(12, 61);
			this.label3.Name = "label3";
			this.label3.Size = new System.Drawing.Size(79, 16);
			this.label3.TabIndex = 18;
			this.label3.Text = "Variable Name";
			this.label3.Click += new System.EventHandler(this.label3_Click);
			// 
			// label2
			// 
			this.label2.AutoSize = true;
			this.label2.Location = new System.Drawing.Point(12, 35);
			this.label2.Name = "label2";
			this.label2.Size = new System.Drawing.Size(80, 16);
			this.label2.TabIndex = 17;
			this.label2.Text = "Property Name";
			this.label2.Click += new System.EventHandler(this.label2_Click);
			// 
			// label1
			// 
			this.label1.AutoSize = true;
			this.label1.Location = new System.Drawing.Point(12, 9);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(71, 16);
			this.label1.TabIndex = 15;
			this.label1.Text = "Access Level";
			this.label1.Click += new System.EventHandler(this.label1_Click);
			// 
			// panel2
			// 
			this.panel2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.panel2.Controls.Add(this.txtCode);
			this.panel2.Location = new System.Drawing.Point(8, 188);
			this.panel2.Name = "panel2";
			this.panel2.Size = new System.Drawing.Size(416, 168);
			this.panel2.TabIndex = 15;
			this.panel2.Paint += new System.Windows.Forms.PaintEventHandler(this.panel2_Paint);
			// 
			// txtCode
			// 
			this.txtCode.Location = new System.Drawing.Point(8, 8);
			this.txtCode.Name = "txtCode";
			this.txtCode.ScrollBars = System.Windows.Forms.RichTextBoxScrollBars.ForcedBoth;
			this.txtCode.Size = new System.Drawing.Size(400, 152);
			this.txtCode.TabIndex = 0;
			this.txtCode.Text = "";
			// 
			// frmPropertyCodeGen
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(432, 366);
			this.Controls.Add(this.panel2);
			this.Controls.Add(this.btnClearCodeWin);
			this.Controls.Add(this.btnClear);
			this.Controls.Add(this.btnGenerate);
			this.Controls.Add(this.panel1);
			this.Name = "frmPropertyCodeGen";
			this.Text = "Property Code Generator";
			this.Load += new System.EventHandler(this.Form1_Load);
			this.panel1.ResumeLayout(false);
			this.panel2.ResumeLayout(false);
			this.ResumeLayout(false);

		}
		#endregion

		/// <summary>
		/// The main entry point for the application.
		/// </summary>
		[STAThread]
		static void Main() 
		{
			Application.Run(new frmPropertyCodeGen());
		}
		
		private void Form1_Load(object sender, System.EventArgs e)
		{
			
		}		
		
	
		private void btnGenerate_Click(object sender, System.EventArgs e)
		{
			string space=" ";
			StringBuilder stringBuilder=new StringBuilder();			
			stringBuilder.Append("private"+space+ cmbDatatype.Text+ space +txtVariableName.Text +";\n");

			stringBuilder.Append("/// <summary>\n");
			stringBuilder.Append("///"+txtComment.Text+"\n");
			stringBuilder.Append("/// </summary>\n");

			stringBuilder.Append(cmbAccessLevel.Text +space+ cmbDatatype.Text+space+txtPropertyName.Text +"\n");
			stringBuilder.Append("{\n get{\n return"+space+txtVariableName.Text+";\n}");
			stringBuilder.Append("\n set \n { \n"+ txtVariableName.Text +"=value; \n }\n}");
			txtCode.Text=txtCode.Text+"\n"+stringBuilder.ToString();
		
		}

		private void btnClear_Click(object sender, System.EventArgs e)
		{
			cmbAccessLevel.SelectedIndex=-1;
			txtVariableName.Text="";
			txtPropertyName.Text="";
			txtComment.Text="";
			cmbDatatype.Text="";
		}

		private void btnClearCodeWin_Click(object sender, System.EventArgs e)
		{
			txtCode.Text="";
		}

		private void label4_Click(object sender, System.EventArgs e)
		{
		
		}

		private void cmbDatatype_SelectedIndexChanged(object sender, System.EventArgs e)
		{
		
		}

		private void label5_Click(object sender, System.EventArgs e)
		{
		
		}

		private void txtComment_TextChanged(object sender, System.EventArgs e)
		{
		
		}

		private void panel1_Paint(object sender, System.Windows.Forms.PaintEventArgs e)
		{
		
		}

		private void txtCode_TextChanged(object sender, System.EventArgs e)
		{
		
		}

		private void panel2_Paint(object sender, System.Windows.Forms.PaintEventArgs e)
		{
		
		}

		private void label1_Click(object sender, System.EventArgs e)
		{
		
		}

		private void label3_Click(object sender, System.EventArgs e)
		{
		
		}

		private void txtPropertyName_TextChanged(object sender, System.EventArgs e)
		{
		
		}

		private void label2_Click(object sender, System.EventArgs e)
		{
		
		}

		private void txtVariableName_TextChanged(object sender, System.EventArgs e)
		{
		
		}

		private void cmbAccessLevel_SelectedIndexChanged(object sender, System.EventArgs e)
		{
		
		}

		

		
	}
}
