using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Text;
using System.Data;  

namespace CodeGen
{
	/// <summary>
	/// Summary description for frmClassGenerator.
	/// </summary>
	public class frmClassGenerator : System.Windows.Forms.Form
	{
		private System.Windows.Forms.Panel panel2;
		private System.Windows.Forms.Panel panel1;
		private System.Windows.Forms.TextBox txtComment;
		private System.Windows.Forms.Label label5;
		private System.Windows.Forms.Label label4;
		private System.Windows.Forms.Label label3;
		private System.Windows.Forms.Label label2;
		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.Button btnGenerate;
		private System.Windows.Forms.Label label6;
		private System.Windows.Forms.Label label7;
		private System.Windows.Forms.Label label8;
		private System.Windows.Forms.ComboBox cmbClassType;
		private System.Windows.Forms.TextBox txtClassName;
		private System.Windows.Forms.ComboBox cmbClassReturnType;
		private System.Windows.Forms.ComboBox cmbParentClassName;
		private System.Windows.Forms.Button btnReset;
		private System.Windows.Forms.Button btnClearCode;
		private System.Windows.Forms.Button btnClose;
		private System.Windows.Forms.CheckedListBox chklstNameSpaces;
		private System.Windows.Forms.CheckedListBox chklstStdMethods;
		private System.Windows.Forms.CheckedListBox chklstStdProperties;
		private System.Windows.Forms.TextBox txtNamespace;
		private System.Windows.Forms.Label label9;
		private System.Windows.Forms.RichTextBox txtCode;
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		public frmClassGenerator()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			//
			// TODO: Add any constructor code after InitializeComponent call
			//
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if(components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.panel2 = new System.Windows.Forms.Panel();
			this.btnClearCode = new System.Windows.Forms.Button();
			this.btnReset = new System.Windows.Forms.Button();
			this.panel1 = new System.Windows.Forms.Panel();
			this.txtNamespace = new System.Windows.Forms.TextBox();
			this.label9 = new System.Windows.Forms.Label();
			this.chklstNameSpaces = new System.Windows.Forms.CheckedListBox();
			this.chklstStdProperties = new System.Windows.Forms.CheckedListBox();
			this.chklstStdMethods = new System.Windows.Forms.CheckedListBox();
			this.label8 = new System.Windows.Forms.Label();
			this.label7 = new System.Windows.Forms.Label();
			this.label6 = new System.Windows.Forms.Label();
			this.cmbClassReturnType = new System.Windows.Forms.ComboBox();
			this.txtComment = new System.Windows.Forms.TextBox();
			this.label5 = new System.Windows.Forms.Label();
			this.cmbParentClassName = new System.Windows.Forms.ComboBox();
			this.label4 = new System.Windows.Forms.Label();
			this.cmbClassType = new System.Windows.Forms.ComboBox();
			this.txtClassName = new System.Windows.Forms.TextBox();
			this.label3 = new System.Windows.Forms.Label();
			this.label2 = new System.Windows.Forms.Label();
			this.label1 = new System.Windows.Forms.Label();
			this.btnGenerate = new System.Windows.Forms.Button();
			this.btnClose = new System.Windows.Forms.Button();
			this.txtCode = new System.Windows.Forms.RichTextBox();
			this.panel2.SuspendLayout();
			this.panel1.SuspendLayout();
			this.SuspendLayout();
			// 
			// panel2
			// 
			this.panel2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.panel2.Controls.Add(this.txtCode);
			this.panel2.Location = new System.Drawing.Point(16, 368);
			this.panel2.Name = "panel2";
			this.panel2.Size = new System.Drawing.Size(472, 112);
			this.panel2.TabIndex = 20;
			// 
			// btnClearCode
			// 
			this.btnClearCode.Cursor = System.Windows.Forms.Cursors.Hand;
			this.btnClearCode.Location = new System.Drawing.Point(112, 336);
			this.btnClearCode.Name = "btnClearCode";
			this.btnClearCode.Size = new System.Drawing.Size(76, 24);
			this.btnClearCode.TabIndex = 18;
			this.btnClearCode.Text = "Clear Code";
			this.btnClearCode.Click += new System.EventHandler(this.btnClearCode_Click);
			// 
			// btnReset
			// 
			this.btnReset.Cursor = System.Windows.Forms.Cursors.Hand;
			this.btnReset.Location = new System.Drawing.Point(208, 336);
			this.btnReset.Name = "btnReset";
			this.btnReset.Size = new System.Drawing.Size(56, 24);
			this.btnReset.TabIndex = 17;
			this.btnReset.Text = "&Reset";
			this.btnReset.Click += new System.EventHandler(this.btnReset_Click);
			// 
			// panel1
			// 
			this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.panel1.Controls.Add(this.txtNamespace);
			this.panel1.Controls.Add(this.label9);
			this.panel1.Controls.Add(this.chklstNameSpaces);
			this.panel1.Controls.Add(this.chklstStdProperties);
			this.panel1.Controls.Add(this.chklstStdMethods);
			this.panel1.Controls.Add(this.label8);
			this.panel1.Controls.Add(this.label7);
			this.panel1.Controls.Add(this.label6);
			this.panel1.Controls.Add(this.cmbClassReturnType);
			this.panel1.Controls.Add(this.txtComment);
			this.panel1.Controls.Add(this.label5);
			this.panel1.Controls.Add(this.cmbParentClassName);
			this.panel1.Controls.Add(this.label4);
			this.panel1.Controls.Add(this.cmbClassType);
			this.panel1.Controls.Add(this.txtClassName);
			this.panel1.Controls.Add(this.label3);
			this.panel1.Controls.Add(this.label2);
			this.panel1.Controls.Add(this.label1);
			this.panel1.Location = new System.Drawing.Point(8, 8);
			this.panel1.Name = "panel1";
			this.panel1.Size = new System.Drawing.Size(480, 325);
			this.panel1.TabIndex = 19;
			this.panel1.Paint += new System.Windows.Forms.PaintEventHandler(this.panel1_Paint);
			// 
			// txtNamespace
			// 
			this.txtNamespace.Location = new System.Drawing.Point(104, 104);
			this.txtNamespace.Name = "txtNamespace";
			this.txtNamespace.Size = new System.Drawing.Size(168, 20);
			this.txtNamespace.TabIndex = 32;
			this.txtNamespace.Text = "";
			// 
			// label9
			// 
			this.label9.AutoSize = true;
			this.label9.Location = new System.Drawing.Point(0, 104);
			this.label9.Name = "label9";
			this.label9.Size = new System.Drawing.Size(98, 16);
			this.label9.TabIndex = 33;
			this.label9.Text = "Namespace Name";
			// 
			// chklstNameSpaces
			// 
			this.chklstNameSpaces.CheckOnClick = true;
			this.chklstNameSpaces.Items.AddRange(new object[] {
																  "System",
																  "System.Data",
																  "System.Data.SqlClient",
																  "System.Data.SqlTypes",
																  "System.Collections.Specialized;",
																  "System.Collections"});
			this.chklstNameSpaces.Location = new System.Drawing.Point(104, 41);
			this.chklstNameSpaces.Name = "chklstNameSpaces";
			this.chklstNameSpaces.Size = new System.Drawing.Size(168, 49);
			this.chklstNameSpaces.TabIndex = 31;
			this.chklstNameSpaces.ThreeDCheckBoxes = true;
			this.chklstNameSpaces.SelectedIndexChanged += new System.EventHandler(this.chklstNameSpaces_SelectedIndexChanged);
			// 
			// chklstStdProperties
			// 
			this.chklstStdProperties.CheckOnClick = true;
			this.chklstStdProperties.Items.AddRange(new object[] {
																	 "Error Message",
																	 "AedStatus"});
			this.chklstStdProperties.Location = new System.Drawing.Point(104, 192);
			this.chklstStdProperties.Name = "chklstStdProperties";
			this.chklstStdProperties.Size = new System.Drawing.Size(168, 34);
			this.chklstStdProperties.TabIndex = 30;
			this.chklstStdProperties.ThreeDCheckBoxes = true;
			// 
			// chklstStdMethods
			// 
			this.chklstStdMethods.CheckOnClick = true;
			this.chklstStdMethods.Items.AddRange(new object[] {
																  "Add",
																  "Edit",
																  "Delete",
																  "Validate",
																  "InsertRecords",
																  "UpdateRecords",
																  "DeleteRecords"});
			this.chklstStdMethods.Location = new System.Drawing.Point(104, 240);
			this.chklstStdMethods.Name = "chklstStdMethods";
			this.chklstStdMethods.Size = new System.Drawing.Size(168, 49);
			this.chklstStdMethods.TabIndex = 29;
			this.chklstStdMethods.ThreeDCheckBoxes = true;
			// 
			// label8
			// 
			this.label8.AutoSize = true;
			this.label8.Location = new System.Drawing.Point(0, 240);
			this.label8.Name = "label8";
			this.label8.Size = new System.Drawing.Size(97, 16);
			this.label8.TabIndex = 27;
			this.label8.Text = "Standard Methods";
			// 
			// label7
			// 
			this.label7.AutoSize = true;
			this.label7.Location = new System.Drawing.Point(0, 192);
			this.label7.Name = "label7";
			this.label7.Size = new System.Drawing.Size(105, 16);
			this.label7.TabIndex = 25;
			this.label7.Text = "Standard Properties";
			// 
			// label6
			// 
			this.label6.AutoSize = true;
			this.label6.Location = new System.Drawing.Point(280, 136);
			this.label6.Name = "label6";
			this.label6.Size = new System.Drawing.Size(61, 16);
			this.label6.TabIndex = 23;
			this.label6.Text = "Class Type";
			// 
			// cmbClassReturnType
			// 
			this.cmbClassReturnType.Items.AddRange(new object[] {
																	"public",
																	"private"});
			this.cmbClassReturnType.Location = new System.Drawing.Point(344, 136);
			this.cmbClassReturnType.Name = "cmbClassReturnType";
			this.cmbClassReturnType.Size = new System.Drawing.Size(128, 21);
			this.cmbClassReturnType.TabIndex = 22;
			// 
			// txtComment
			// 
			this.txtComment.Location = new System.Drawing.Point(80, 296);
			this.txtComment.Name = "txtComment";
			this.txtComment.Size = new System.Drawing.Size(336, 20);
			this.txtComment.TabIndex = 21;
			this.txtComment.Text = "";
			// 
			// label5
			// 
			this.label5.AutoSize = true;
			this.label5.Location = new System.Drawing.Point(12, 296);
			this.label5.Name = "label5";
			this.label5.Size = new System.Drawing.Size(53, 16);
			this.label5.TabIndex = 20;
			this.label5.Text = "Comment";
			// 
			// cmbParentClassName
			// 
			this.cmbParentClassName.Items.AddRange(new object[] {
																	"",
																	"Testing Class"});
			this.cmbParentClassName.Location = new System.Drawing.Point(104, 160);
			this.cmbParentClassName.Name = "cmbParentClassName";
			this.cmbParentClassName.Size = new System.Drawing.Size(168, 21);
			this.cmbParentClassName.TabIndex = 16;
			// 
			// label4
			// 
			this.label4.AutoSize = true;
			this.label4.Location = new System.Drawing.Point(0, 168);
			this.label4.Name = "label4";
			this.label4.Size = new System.Drawing.Size(102, 16);
			this.label4.TabIndex = 19;
			this.label4.Text = "Parent Class Name";
			this.label4.Click += new System.EventHandler(this.label4_Click);
			// 
			// cmbClassType
			// 
			this.cmbClassType.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
			this.cmbClassType.Items.AddRange(new object[] {
															  "BO(Business Object Class)",
															  "DA(Data Access Class)",
															  "MC(Master Class)"});
			this.cmbClassType.Location = new System.Drawing.Point(104, 9);
			this.cmbClassType.Name = "cmbClassType";
			this.cmbClassType.Size = new System.Drawing.Size(168, 21);
			this.cmbClassType.TabIndex = 12;
			this.cmbClassType.SelectedIndexChanged += new System.EventHandler(this.cmbClassType_SelectedIndexChanged);
			// 
			// txtClassName
			// 
			this.txtClassName.Location = new System.Drawing.Point(104, 136);
			this.txtClassName.Name = "txtClassName";
			this.txtClassName.Size = new System.Drawing.Size(168, 20);
			this.txtClassName.TabIndex = 14;
			this.txtClassName.Text = "";
			// 
			// label3
			// 
			this.label3.AutoSize = true;
			this.label3.Location = new System.Drawing.Point(0, 136);
			this.label3.Name = "label3";
			this.label3.Size = new System.Drawing.Size(66, 16);
			this.label3.TabIndex = 18;
			this.label3.Text = "Class Name";
			this.label3.Click += new System.EventHandler(this.label3_Click);
			// 
			// label2
			// 
			this.label2.Location = new System.Drawing.Point(0, 41);
			this.label2.Name = "label2";
			this.label2.Size = new System.Drawing.Size(88, 32);
			this.label2.TabIndex = 17;
			this.label2.Text = "Standard NameSpaces";
			this.label2.Click += new System.EventHandler(this.label2_Click);
			// 
			// label1
			// 
			this.label1.AutoSize = true;
			this.label1.Location = new System.Drawing.Point(0, 11);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(65, 16);
			this.label1.TabIndex = 15;
			this.label1.Text = "Object Type";
			this.label1.Click += new System.EventHandler(this.label1_Click);
			// 
			// btnGenerate
			// 
			this.btnGenerate.Cursor = System.Windows.Forms.Cursors.Hand;
			this.btnGenerate.Location = new System.Drawing.Point(16, 336);
			this.btnGenerate.Name = "btnGenerate";
			this.btnGenerate.Size = new System.Drawing.Size(80, 24);
			this.btnGenerate.TabIndex = 16;
			this.btnGenerate.Text = "&Generate";
			this.btnGenerate.Click += new System.EventHandler(this.btnGenerate_Click);
			// 
			// btnClose
			// 
			this.btnClose.Cursor = System.Windows.Forms.Cursors.Hand;
			this.btnClose.Location = new System.Drawing.Point(280, 336);
			this.btnClose.Name = "btnClose";
			this.btnClose.Size = new System.Drawing.Size(56, 24);
			this.btnClose.TabIndex = 21;
			this.btnClose.Text = "Clo&se";
			this.btnClose.Click += new System.EventHandler(this.btnClose_Click);
			// 
			// txtCode
			// 
			this.txtCode.Location = new System.Drawing.Point(8, 8);
			this.txtCode.Name = "txtCode";
			this.txtCode.ScrollBars = System.Windows.Forms.RichTextBoxScrollBars.ForcedBoth;
			this.txtCode.Size = new System.Drawing.Size(456, 96);
			this.txtCode.TabIndex = 0;
			this.txtCode.Text = "";
			// 
			// frmClassGenerator
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(496, 486);
			this.Controls.Add(this.btnClose);
			this.Controls.Add(this.panel2);
			this.Controls.Add(this.btnClearCode);
			this.Controls.Add(this.btnReset);
			this.Controls.Add(this.panel1);
			this.Controls.Add(this.btnGenerate);
			this.Name = "frmClassGenerator";
			this.Text = "Class Code Generator";
			this.Load += new System.EventHandler(this.frmClassGenerator_Load);
			this.panel2.ResumeLayout(false);
			this.panel1.ResumeLayout(false);
			this.ResumeLayout(false);

		}
		#endregion

		private void label4_Click(object sender, System.EventArgs e)
		{
		
		}

		private void label1_Click(object sender, System.EventArgs e)
		{
		
		}

		private void panel1_Paint(object sender, System.Windows.Forms.PaintEventArgs e)
		{
		
		}

		private void label2_Click(object sender, System.EventArgs e)
		{
		
		}

		private void label3_Click(object sender, System.EventArgs e)
		{
		
		}

		private void btnClose_Click(object sender, System.EventArgs e)
		{
			Close(); 
		}

		private void btnGenerate_Click(object sender, System.EventArgs e)
		{
		// The function will get the information from user and 
		// depending on it will generate namespace , Class and methods.
		
		
			string space=" ";
			
			StringBuilder stringBuilder=new StringBuilder();
			// loop to Generate declaration Required namspace
			if (txtNamespace.Text.Trim()  == "") 
			{
				MessageBox.Show("Please Give the Namespace Name","Warning");   
			}
			else
			{
				if (txtClassName.Text.Trim() != "" && cmbClassReturnType.Text != "") 
				{
					//create Using sytem objects
					if (chklstNameSpaces.CheckedItems.Count!=0)
					{
						for( int i = 0 ;i<=chklstNameSpaces.CheckedItems.Count - 1 ;i++)  
						{
							stringBuilder.Append("using"+space + chklstNameSpaces.CheckedItems[i].ToString() +";\n");  
						}
					}
					//Cretae a namespace 
					stringBuilder.Append("namespace"+space +txtNamespace.Text);
					stringBuilder.Append("\n { \n");
					stringBuilder.Append("/// <summary>\n");
					stringBuilder.Append("///"+txtComment.Text+"\n");
					stringBuilder.Append("/// </summary>\n\n");
					
					//Create class 
					if (cmbParentClassName.Text.Trim()!="")
					{
						stringBuilder.Append(""+space+cmbClassReturnType.Text+ space +"class"+ space +txtClassName.Text+ " : " + cmbParentClassName.Text + "\n");
					}
					else
					{
						stringBuilder.Append(""+space+cmbClassReturnType.Text+ space +"class"+ space +txtClassName.Text +"\n");
					}

					stringBuilder.Append("\n"+space+"{ \n");
					stringBuilder.Append("\n ///Start of Class \n");
					// loop to Generate Required Methods

					if (chklstStdMethods.CheckedItems.Count!=0)
					{
						for(int i = 0 ;i<=chklstStdMethods.CheckedItems.Count - 1 ;i++)  
						{
							stringBuilder.Append(space+space+space+"public"+space+"bool" +space+ chklstStdMethods.CheckedItems[i].ToString() +"()");  
							stringBuilder.Append("\n"+space+space+space+space+"{ \n");
							stringBuilder.Append(""+space+space+space+"///Comments \n");
							stringBuilder.Append("\n"+space+space+space+space+" } \n");
						}
					}
					
					if (chklstStdProperties.CheckedItems.Count!=0)
					{
						for(int i = 0 ;i<=chklstStdProperties.CheckedItems.Count - 1 ;i++)  
						{
							stringBuilder.Append(space+space+space+"public"+space+"bool" +space+ chklstStdProperties.CheckedItems[i].ToString() +"()");  
							stringBuilder.Append("\n"+space+space+space+space+"{ \n");
							stringBuilder.Append(""+space+space+space+"///Comments \n");
							stringBuilder.Append("\n"+space+space+space+space+" } \n");
						}
					}

					stringBuilder.Append("\n "+space+space+"} \n");
					stringBuilder.Append("\n } \n");
					txtCode.Text = stringBuilder.ToString();  
				}
				else
				{
					MessageBox.Show("Please Type the Class Name","Warning");  
				}
			}
		}

		private void btnClearCode_Click(object sender, System.EventArgs e)
		{
			txtCode.Text ="";
		}

		private void btnReset_Click(object sender, System.EventArgs e)
		{
			txtCode.Text ="";
			txtClassName.Text ="";
			txtComment.Text="";
			cmbClassType.SelectedIndex = 0;  
			cmbClassReturnType.SelectedIndex =0;
			cmbParentClassName.SelectedIndex =0; 
			cmbClassType.Refresh(); 
			chklstNameSpaces.ClearSelected();
			chklstStdMethods.ClearSelected();
			chklstStdProperties.ClearSelected();
			//loop to clear the standard Namespace ckeckedlist box
			for( int i = 0 ;i<=chklstNameSpaces.Items.Count - 1 ;i++)  
				{
					chklstNameSpaces.SetItemCheckState (i,CheckState.Unchecked);
				}
			
			for( int i = 0 ;i<=chklstStdProperties.Items.Count - 1 ;i++)  
			{
				chklstStdProperties.SetItemCheckState (i,CheckState.Unchecked);
			}
			
			for( int i = 0 ;i<=chklstStdMethods.Items.Count - 1 ;i++)  
			{
				chklstStdMethods.SetItemCheckState (i,CheckState.Unchecked);
			}
			
            

		}

		private void frmClassGenerator_Load(object sender, System.EventArgs e)
		{
			txtCode.Text ="";
			txtClassName.Text ="";
			txtComment.Text="";
			cmbClassType.SelectedIndex = 0;  
			cmbClassReturnType.SelectedIndex =0;
			cmbParentClassName.SelectedIndex =0; 
		}

		private void cmbClassType_SelectedIndexChanged(object sender, System.EventArgs e)
		{
			DataSet ds = new DataSet();
			DataTable dt = new DataTable();
			DataTable dt1= new DataTable(); 
			ds.ReadXml("Common.xml",XmlReadMode.Auto);
			dt= ds.Tables[0];
			
			DataView dv=new DataView();
			
			switch(cmbClassType.Text.ToString())
			{
				case "BO(Business Object Class)" :	dt.DefaultView.RowFilter = "UsedIn ='BO'";
													dv = dt.DefaultView;			
													chklstNameSpaces.Items.Clear();
													for(int i=0;i<=dv.Count-1;i++)
													{
														chklstNameSpaces.Items.Add(dv[i].Row["namespacename"].ToString(),CheckState.Unchecked);   	
													}
                    								dt= ds.Tables[1];
													dt.DefaultView.RowFilter = "UsedIn ='BO'";
													dv = dt.DefaultView;			
													chklstStdMethods.Items.Clear();
													for(int i=0;i<=dv.Count-1;i++)
													{
														chklstStdMethods.Items.Add(dv[i].Row["MethodName"].ToString(),CheckState.Unchecked);   	
													}
													break;
					
														
				case "DA(Data Access Class)" :	dt.DefaultView.RowFilter = "UsedIn ='DA'";
													dv = dt.DefaultView;			
													chklstNameSpaces.Items.Clear();
													for(int i=0;i<=dv.Count-1;i++) 
													{
														chklstNameSpaces.Items.Add(dv[i].Row["namespacename"].ToString(),CheckState.Unchecked);   	
													}
													dt= ds.Tables[1];
													dt.DefaultView.RowFilter = "UsedIn ='DA'";
													dv = dt.DefaultView;			
													chklstStdMethods.Items.Clear();
													for(int i=0;i<=dv.Count-1;i++)
													{
														chklstStdMethods.Items.Add(dv[i].Row["MethodName"].ToString(),CheckState.Unchecked);   	
													}
													break;
				case "MC(Master Class)" :	dt.DefaultView.RowFilter = "UsedIn ='MC'";
													dv = dt.DefaultView;			
													chklstNameSpaces.Items.Clear();
													for(int i=0;i<=dv.Count-1;i++) 
													{
														chklstNameSpaces.Items.Add(dv[i].Row["namespacename"].ToString(),CheckState.Unchecked);   	
													}
													dt= ds.Tables[1];
													dt.DefaultView.RowFilter = "UsedIn ='MC'";
													dv = dt.DefaultView;			
													chklstStdMethods.Items.Clear();
													for(int i=0;i<=dv.Count-1;i++)
													{
														chklstStdMethods.Items.Add(dv[i].Row["MethodName"].ToString(),CheckState.Unchecked);   	
													}
													break;
					
			}


			
			}

		private void chklstNameSpaces_SelectedIndexChanged(object sender, System.EventArgs e)
		{
		
		}


	}
}
