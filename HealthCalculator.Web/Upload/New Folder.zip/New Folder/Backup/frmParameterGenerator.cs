using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;
using System.Data.SqlClient;
using System.Data.OleDb;
using System.Text;

namespace CodeGen
{
	/// <summary>
	/// Summary description for Form1.
	/// </summary>
	public class frmParameterGenerator : System.Windows.Forms.Form
	{
		private System.Windows.Forms.Button btnGenerate;
		private System.Windows.Forms.Button btnClear;
		private System.Windows.Forms.Button btnClearCodeWin;
		private System.Windows.Forms.Panel panel1;
		private System.Windows.Forms.TextBox txtComment;
		private System.Windows.Forms.Label label5;
		private System.Windows.Forms.ComboBox cmbDatatype;
		private System.Windows.Forms.Label label4;
		private System.Windows.Forms.ComboBox cmbAccessLevel;
		private System.Windows.Forms.TextBox txtVariableName;
		private System.Windows.Forms.Label label3;
		private System.Windows.Forms.Label label2;
		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.Panel panel2;
		private System.Windows.Forms.TextBox textBox1;
		private System.Windows.Forms.TextBox textBox2;
		private System.Windows.Forms.ComboBox cboParamType;
		private System.Windows.Forms.TextBox txtParamName;
		private System.Windows.Forms.TextBox txtCmdName;
		private System.Windows.Forms.RichTextBox txtCode;
		
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		public frmParameterGenerator()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			//
			// TODO: Add any constructor code after InitializeComponent call
			//
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if (components != null) 
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.btnGenerate = new System.Windows.Forms.Button();
			this.btnClear = new System.Windows.Forms.Button();
			this.btnClearCodeWin = new System.Windows.Forms.Button();
			this.panel1 = new System.Windows.Forms.Panel();
			this.txtCmdName = new System.Windows.Forms.TextBox();
			this.cboParamType = new System.Windows.Forms.ComboBox();
			this.label5 = new System.Windows.Forms.Label();
			this.label1 = new System.Windows.Forms.Label();
			this.cmbDatatype = new System.Windows.Forms.ComboBox();
			this.label4 = new System.Windows.Forms.Label();
			this.txtVariableName = new System.Windows.Forms.TextBox();
			this.txtParamName = new System.Windows.Forms.TextBox();
			this.label3 = new System.Windows.Forms.Label();
			this.label2 = new System.Windows.Forms.Label();
			this.textBox1 = new System.Windows.Forms.TextBox();
			this.textBox2 = new System.Windows.Forms.TextBox();
			this.panel2 = new System.Windows.Forms.Panel();
			this.txtCode = new System.Windows.Forms.RichTextBox();
			this.panel1.SuspendLayout();
			this.panel2.SuspendLayout();
			this.SuspendLayout();
			// 
			// btnGenerate
			// 
			this.btnGenerate.Cursor = System.Windows.Forms.Cursors.Hand;
			this.btnGenerate.Location = new System.Drawing.Point(16, 154);
			this.btnGenerate.Name = "btnGenerate";
			this.btnGenerate.Size = new System.Drawing.Size(80, 24);
			this.btnGenerate.TabIndex = 4;
			this.btnGenerate.Text = "&Generate";
			this.btnGenerate.Click += new System.EventHandler(this.btnGenerate_Click);
			// 
			// btnClear
			// 
			this.btnClear.Cursor = System.Windows.Forms.Cursors.Hand;
			this.btnClear.Location = new System.Drawing.Point(112, 154);
			this.btnClear.Name = "btnClear";
			this.btnClear.Size = new System.Drawing.Size(56, 24);
			this.btnClear.TabIndex = 9;
			this.btnClear.Text = "&Clear";
			this.btnClear.Click += new System.EventHandler(this.btnClear_Click);
			// 
			// btnClearCodeWin
			// 
			this.btnClearCodeWin.Cursor = System.Windows.Forms.Cursors.Hand;
			this.btnClearCodeWin.Location = new System.Drawing.Point(188, 154);
			this.btnClearCodeWin.Name = "btnClearCodeWin";
			this.btnClearCodeWin.Size = new System.Drawing.Size(140, 24);
			this.btnClearCodeWin.TabIndex = 12;
			this.btnClearCodeWin.Text = "Clear  Output Code";
			this.btnClearCodeWin.Click += new System.EventHandler(this.btnClearCodeWin_Click);
			// 
			// panel1
			// 
			this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.panel1.Controls.Add(this.txtCmdName);
			this.panel1.Controls.Add(this.cboParamType);
			this.panel1.Controls.Add(this.label5);
			this.panel1.Controls.Add(this.label1);
			this.panel1.Controls.Add(this.cmbDatatype);
			this.panel1.Controls.Add(this.label4);
			this.panel1.Controls.Add(this.txtVariableName);
			this.panel1.Controls.Add(this.txtParamName);
			this.panel1.Controls.Add(this.label3);
			this.panel1.Controls.Add(this.label2);
			this.panel1.Controls.Add(this.textBox1);
			this.panel1.Controls.Add(this.textBox2);
			this.panel1.Location = new System.Drawing.Point(8, 3);
			this.panel1.Name = "panel1";
			this.panel1.Size = new System.Drawing.Size(416, 144);
			this.panel1.TabIndex = 14;
			this.panel1.Paint += new System.Windows.Forms.PaintEventHandler(this.panel1_Paint);
			// 
			// txtCmdName
			// 
			this.txtCmdName.Location = new System.Drawing.Point(128, 35);
			this.txtCmdName.Name = "txtCmdName";
			this.txtCmdName.Size = new System.Drawing.Size(144, 20);
			this.txtCmdName.TabIndex = 23;
			this.txtCmdName.Text = "";
			// 
			// cboParamType
			// 
			this.cboParamType.Items.AddRange(new object[] {
															  "SqlParameter\t",
															  "OleDbParameter"});
			this.cboParamType.Location = new System.Drawing.Point(128, 8);
			this.cboParamType.Name = "cboParamType";
			this.cboParamType.Size = new System.Drawing.Size(144, 21);
			this.cboParamType.TabIndex = 22;
			// 
			// label5
			// 
			this.label5.AutoSize = true;
			this.label5.Location = new System.Drawing.Point(8, 32);
			this.label5.Name = "label5";
			this.label5.Size = new System.Drawing.Size(123, 16);
			this.label5.TabIndex = 21;
			this.label5.Text = "Command object Name";
			// 
			// label1
			// 
			this.label1.AutoSize = true;
			this.label1.Location = new System.Drawing.Point(8, 7);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(85, 16);
			this.label1.TabIndex = 20;
			this.label1.Text = "Parameter Type";
			// 
			// cmbDatatype
			// 
			this.cmbDatatype.Items.AddRange(new object[] {
															 "string",
															 "int",
															 "double",
															 "datetime",
															 "float",
															 "SqlConnection",
															 "SqlCommand",
															 "DataTable",
															 "DataSet"});
			this.cmbDatatype.Location = new System.Drawing.Point(128, 112);
			this.cmbDatatype.Name = "cmbDatatype";
			this.cmbDatatype.Size = new System.Drawing.Size(144, 21);
			this.cmbDatatype.TabIndex = 16;
			this.cmbDatatype.SelectedIndexChanged += new System.EventHandler(this.cmbDatatype_SelectedIndexChanged);
			// 
			// label4
			// 
			this.label4.AutoSize = true;
			this.label4.Location = new System.Drawing.Point(12, 110);
			this.label4.Name = "label4";
			this.label4.Size = new System.Drawing.Size(56, 16);
			this.label4.TabIndex = 19;
			this.label4.Text = "Data Type";
			this.label4.Click += new System.EventHandler(this.label4_Click);
			// 
			// txtVariableName
			// 
			this.txtVariableName.Location = new System.Drawing.Point(128, 88);
			this.txtVariableName.Name = "txtVariableName";
			this.txtVariableName.Size = new System.Drawing.Size(144, 20);
			this.txtVariableName.TabIndex = 14;
			this.txtVariableName.Text = "";
			this.txtVariableName.TextChanged += new System.EventHandler(this.txtVariableName_TextChanged);
			// 
			// txtParamName
			// 
			this.txtParamName.Location = new System.Drawing.Point(128, 62);
			this.txtParamName.Name = "txtParamName";
			this.txtParamName.Size = new System.Drawing.Size(144, 20);
			this.txtParamName.TabIndex = 13;
			this.txtParamName.Text = "";
			this.txtParamName.TextChanged += new System.EventHandler(this.txtPropertyName_TextChanged);
			// 
			// label3
			// 
			this.label3.AutoSize = true;
			this.label3.Location = new System.Drawing.Point(12, 88);
			this.label3.Name = "label3";
			this.label3.Size = new System.Drawing.Size(124, 16);
			this.label3.TabIndex = 18;
			this.label3.Text = "Parameter object Name";
			this.label3.Click += new System.EventHandler(this.label3_Click);
			// 
			// label2
			// 
			this.label2.AutoSize = true;
			this.label2.Location = new System.Drawing.Point(12, 62);
			this.label2.Name = "label2";
			this.label2.Size = new System.Drawing.Size(90, 16);
			this.label2.TabIndex = 17;
			this.label2.Text = "Parameter Name";
			this.label2.Click += new System.EventHandler(this.label2_Click);
			// 
			// textBox1
			// 
			this.textBox1.Location = new System.Drawing.Point(372, 344);
			this.textBox1.Name = "textBox1";
			this.textBox1.Size = new System.Drawing.Size(144, 20);
			this.textBox1.TabIndex = 13;
			this.textBox1.Text = "";
			// 
			// textBox2
			// 
			this.textBox2.Location = new System.Drawing.Point(372, 376);
			this.textBox2.Name = "textBox2";
			this.textBox2.Size = new System.Drawing.Size(144, 20);
			this.textBox2.TabIndex = 14;
			this.textBox2.Text = "";
			// 
			// panel2
			// 
			this.panel2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.panel2.Controls.Add(this.txtCode);
			this.panel2.Location = new System.Drawing.Point(8, 188);
			this.panel2.Name = "panel2";
			this.panel2.Size = new System.Drawing.Size(416, 168);
			this.panel2.TabIndex = 15;
			this.panel2.Paint += new System.Windows.Forms.PaintEventHandler(this.panel2_Paint);
			// 
			// txtCode
			// 
			this.txtCode.Location = new System.Drawing.Point(8, 8);
			this.txtCode.Name = "txtCode";
			this.txtCode.ScrollBars = System.Windows.Forms.RichTextBoxScrollBars.ForcedBoth;
			this.txtCode.Size = new System.Drawing.Size(400, 152);
			this.txtCode.TabIndex = 0;
			this.txtCode.Text = "";
			// 
			// frmParameterGenerator
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(432, 366);
			this.Controls.Add(this.panel2);
			this.Controls.Add(this.btnClearCodeWin);
			this.Controls.Add(this.btnClear);
			this.Controls.Add(this.btnGenerate);
			this.Controls.Add(this.panel1);
			this.Name = "frmParameterGenerator";
			this.Text = "Parameter Code Generator";
			this.Load += new System.EventHandler(this.Form1_Load);
			this.panel1.ResumeLayout(false);
			this.panel2.ResumeLayout(false);
			this.ResumeLayout(false);

		}
		#endregion

		/// <summary>
		/// The main entry point for the application.
		/// </summary>
		[STAThread]
		static void Main() 
		{
			Application.Run(new frmPropertyCodeGen());
		}
		
		private void Form1_Load(object sender, System.EventArgs e)
		{
			
			SqlParameter sqlParameter;
			sqlParameter=new SqlParameter("@vchar_MTNMemoLotId",SqlDbType.VarChar);
			sqlParameter.Direction=ParameterDirection.Input;
			//by prashant dt 22.02.06
			//sqlParameter.Value=MTNmemoLotId;
			//sqlCommand.Parameters.Add(sqlParameter);

		}		
		
	
		private void btnGenerate_Click(object sender, System.EventArgs e)
		{
						
			string space=" ";
			StringBuilder stringBuilder=new StringBuilder();
			
			stringBuilder.Append(cboParamType.Text + space + txtVariableName.Text+space+"="+space+"new"+space+cboParamType.Text+"();");

			stringBuilder.Append("private"+space+ cmbDatatype.Text+ space +txtVariableName.Text +";\n");

			stringBuilder.Append("/// <summary>\n");
			stringBuilder.Append("///"+txtComment.Text+"\n");
			stringBuilder.Append("/// </summary>\n");
			//by prashant dt 22.02.06
			//stringBuilder.Append(cmbAccessLevel.Text +space+ cmbDatatype.Text+space+txtPropertyName.Text +"\n");
			stringBuilder.Append("{\n get{\n return"+space+txtVariableName.Text+";\n}");
			stringBuilder.Append("\n set \n { \n"+ txtVariableName.Text +"=value; \n }\n}");
			txtCode.Text=txtCode.Text+"\n"+stringBuilder.ToString();
		
		}

		private void btnClear_Click(object sender, System.EventArgs e)
		{
			cmbAccessLevel.SelectedIndex=-1;
			txtVariableName.Text="";
			//by prashant dt 22.02.06
			//txtPropertyName.Text="";
			txtComment.Text="";
			cmbDatatype.Text="";
		}

		private void btnClearCodeWin_Click(object sender, System.EventArgs e)
		{
			txtCode.Text="";
		}

		private void label4_Click(object sender, System.EventArgs e)
		{
		
		}

		private void cmbDatatype_SelectedIndexChanged(object sender, System.EventArgs e)
		{
		
		}

		private void label5_Click(object sender, System.EventArgs e)
		{
		
		}

		private void txtComment_TextChanged(object sender, System.EventArgs e)
		{
		
		}

		private void panel1_Paint(object sender, System.Windows.Forms.PaintEventArgs e)
		{
		
		}

		private void txtCode_TextChanged(object sender, System.EventArgs e)
		{
		
		}

		private void panel2_Paint(object sender, System.Windows.Forms.PaintEventArgs e)
		{
		
		}

		private void label1_Click(object sender, System.EventArgs e)
		{
		
		}

		private void label3_Click(object sender, System.EventArgs e)
		{
		
		}

		private void txtPropertyName_TextChanged(object sender, System.EventArgs e)
		{
		
		}

		private void label2_Click(object sender, System.EventArgs e)
		{
		
		}

		private void txtVariableName_TextChanged(object sender, System.EventArgs e)
		{
		
		}

		private void cmbAccessLevel_SelectedIndexChanged(object sender, System.EventArgs e)
		{
		
		}

		
		
	}
}
