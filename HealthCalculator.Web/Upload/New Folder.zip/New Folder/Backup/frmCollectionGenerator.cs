using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Text;
namespace CodeGen
{
	/// <summary>
	/// Summary description for frmCollectionGenerator.
	/// </summary>
	public class frmCollectionGenerator : System.Windows.Forms.Form
	{
		private System.Windows.Forms.Button btnGenerate;
		private System.Windows.Forms.Panel panel2;
		private System.Windows.Forms.Button btnClearCodeWin;
		private System.Windows.Forms.Button btnClear;
		private System.Windows.Forms.Panel panel1;
		private System.Windows.Forms.Label label3;
		private System.Windows.Forms.Label label2;
		private System.Windows.Forms.Label label5;
		private System.Windows.Forms.TextBox txtComment;
		private System.Windows.Forms.TextBox txtClassName;
		private System.Windows.Forms.TextBox txtColName;
		private System.Windows.Forms.TextBox txtNameSpace;
		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.RichTextBox txtCode;
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		public frmCollectionGenerator()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			//
			// TODO: Add any constructor code after InitializeComponent call
			//
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if(components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.btnGenerate = new System.Windows.Forms.Button();
			this.panel2 = new System.Windows.Forms.Panel();
			this.btnClearCodeWin = new System.Windows.Forms.Button();
			this.btnClear = new System.Windows.Forms.Button();
			this.panel1 = new System.Windows.Forms.Panel();
			this.txtNameSpace = new System.Windows.Forms.TextBox();
			this.label1 = new System.Windows.Forms.Label();
			this.txtComment = new System.Windows.Forms.TextBox();
			this.label5 = new System.Windows.Forms.Label();
			this.txtClassName = new System.Windows.Forms.TextBox();
			this.txtColName = new System.Windows.Forms.TextBox();
			this.label3 = new System.Windows.Forms.Label();
			this.label2 = new System.Windows.Forms.Label();
			this.txtCode = new System.Windows.Forms.RichTextBox();
			this.panel2.SuspendLayout();
			this.panel1.SuspendLayout();
			this.SuspendLayout();
			// 
			// btnGenerate
			// 
			this.btnGenerate.Cursor = System.Windows.Forms.Cursors.Hand;
			this.btnGenerate.Location = new System.Drawing.Point(17, 120);
			this.btnGenerate.Name = "btnGenerate";
			this.btnGenerate.Size = new System.Drawing.Size(80, 24);
			this.btnGenerate.TabIndex = 4;
			this.btnGenerate.Text = "&Generate";
			this.btnGenerate.Click += new System.EventHandler(this.btnGenerate_Click);
			// 
			// panel2
			// 
			this.panel2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.panel2.Controls.Add(this.txtCode);
			this.panel2.Location = new System.Drawing.Point(9, 158);
			this.panel2.Name = "panel2";
			this.panel2.Size = new System.Drawing.Size(416, 199);
			this.panel2.TabIndex = 20;
			// 
			// btnClearCodeWin
			// 
			this.btnClearCodeWin.Cursor = System.Windows.Forms.Cursors.Hand;
			this.btnClearCodeWin.Location = new System.Drawing.Point(189, 123);
			this.btnClearCodeWin.Name = "btnClearCodeWin";
			this.btnClearCodeWin.Size = new System.Drawing.Size(140, 24);
			this.btnClearCodeWin.TabIndex = 6;
			this.btnClearCodeWin.Text = "Clear  Output Code";
			this.btnClearCodeWin.Click += new System.EventHandler(this.btnClearCodeWin_Click);
			// 
			// btnClear
			// 
			this.btnClear.Cursor = System.Windows.Forms.Cursors.Hand;
			this.btnClear.Location = new System.Drawing.Point(113, 122);
			this.btnClear.Name = "btnClear";
			this.btnClear.Size = new System.Drawing.Size(56, 24);
			this.btnClear.TabIndex = 5;
			this.btnClear.Text = "&Clear";
			// 
			// panel1
			// 
			this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.panel1.Controls.Add(this.txtNameSpace);
			this.panel1.Controls.Add(this.label1);
			this.panel1.Controls.Add(this.txtComment);
			this.panel1.Controls.Add(this.label5);
			this.panel1.Controls.Add(this.txtClassName);
			this.panel1.Controls.Add(this.txtColName);
			this.panel1.Controls.Add(this.label3);
			this.panel1.Controls.Add(this.label2);
			this.panel1.Location = new System.Drawing.Point(9, 5);
			this.panel1.Name = "panel1";
			this.panel1.Size = new System.Drawing.Size(416, 109);
			this.panel1.TabIndex = 19;
			this.panel1.Paint += new System.Windows.Forms.PaintEventHandler(this.panel1_Paint);
			// 
			// txtNameSpace
			// 
			this.txtNameSpace.Location = new System.Drawing.Point(81, 5);
			this.txtNameSpace.Name = "txtNameSpace";
			this.txtNameSpace.Size = new System.Drawing.Size(303, 20);
			this.txtNameSpace.TabIndex = 0;
			this.txtNameSpace.Text = "";
			// 
			// label1
			// 
			this.label1.AutoSize = true;
			this.label1.Location = new System.Drawing.Point(8, 5);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(65, 16);
			this.label1.TabIndex = 23;
			this.label1.Text = "Namespace";
			// 
			// txtComment
			// 
			this.txtComment.Location = new System.Drawing.Point(83, 80);
			this.txtComment.Name = "txtComment";
			this.txtComment.Size = new System.Drawing.Size(304, 20);
			this.txtComment.TabIndex = 3;
			this.txtComment.Text = "";
			// 
			// label5
			// 
			this.label5.AutoSize = true;
			this.label5.Location = new System.Drawing.Point(6, 80);
			this.label5.Name = "label5";
			this.label5.Size = new System.Drawing.Size(53, 16);
			this.label5.TabIndex = 20;
			this.label5.Text = "Comment";
			// 
			// txtClassName
			// 
			this.txtClassName.Location = new System.Drawing.Point(83, 55);
			this.txtClassName.Name = "txtClassName";
			this.txtClassName.Size = new System.Drawing.Size(144, 20);
			this.txtClassName.TabIndex = 2;
			this.txtClassName.Text = "";
			// 
			// txtColName
			// 
			this.txtColName.Location = new System.Drawing.Point(83, 30);
			this.txtColName.Name = "txtColName";
			this.txtColName.Size = new System.Drawing.Size(144, 20);
			this.txtColName.TabIndex = 1;
			this.txtColName.Text = "";
			// 
			// label3
			// 
			this.label3.AutoSize = true;
			this.label3.Location = new System.Drawing.Point(6, 55);
			this.label3.Name = "label3";
			this.label3.Size = new System.Drawing.Size(66, 16);
			this.label3.TabIndex = 18;
			this.label3.Text = "Class Name";
			// 
			// label2
			// 
			this.label2.AutoSize = true;
			this.label2.Location = new System.Drawing.Point(6, 30);
			this.label2.Name = "label2";
			this.label2.Size = new System.Drawing.Size(34, 16);
			this.label2.TabIndex = 17;
			this.label2.Text = "Name";
			// 
			// txtCode
			// 
			this.txtCode.Location = new System.Drawing.Point(8, 8);
			this.txtCode.Name = "txtCode";
			this.txtCode.ScrollBars = System.Windows.Forms.RichTextBoxScrollBars.ForcedBoth;
			this.txtCode.Size = new System.Drawing.Size(400, 184);
			this.txtCode.TabIndex = 0;
			this.txtCode.Text = "";
			// 
			// frmCollectionGenerator
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(448, 366);
			this.Controls.Add(this.btnGenerate);
			this.Controls.Add(this.panel2);
			this.Controls.Add(this.btnClearCodeWin);
			this.Controls.Add(this.btnClear);
			this.Controls.Add(this.panel1);
			this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D;
			this.Name = "frmCollectionGenerator";
			this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
			this.Text = "Collection Class Code Generator";
			this.Load += new System.EventHandler(this.frmCollectionGenerator_Load);
			this.panel2.ResumeLayout(false);
			this.panel1.ResumeLayout(false);
			this.ResumeLayout(false);

		}
		#endregion
		/// <summary>
		/// The main entry point for the application.
		/// </summary>
		[STAThread]
		static void Main() 
		{
			Application.Run(new frmCollectionGenerator());
		}

		private void frmCollectionGenerator_Load(object sender, System.EventArgs e)
		{
			
		}

		private void btnGenerate_Click(object sender, System.EventArgs e)
		{
			string space=" ";

			StringBuilder stringBuilder=new StringBuilder();
			stringBuilder.Append("using System.Collections.Specialized;\n");
			stringBuilder.Append("namespace"+space +txtNameSpace.Text);
			stringBuilder.Append("\n { \n");
			stringBuilder.Append("/// <summary>\n");
			stringBuilder.Append("///"+txtComment.Text+"\n");
			stringBuilder.Append("/// </summary>\n");
			
			stringBuilder.Append("public class"+space +txtColName.Text +":NameObjectCollectionBase\n");
			stringBuilder.Append("\n { \n");
			stringBuilder.Append("public"+space+txtColName.Text +"()\n{\n}");


			//this Method on the basics of index

			stringBuilder.Append("/// <summary>\n");
			stringBuilder.Append("/// This method is used to get/set "+txtClassName.Text + " object value in the collection \n");
			stringBuilder.Append("///on the basics of index as int.\n");
			stringBuilder.Append("/// </summary>\n");
			stringBuilder.Append("public" + space + txtClassName.Text + space+"this[int index]\n");
			stringBuilder.Append("{\n");
			stringBuilder.Append("get\n");
			stringBuilder.Append("{\n");
			stringBuilder.Append("return ("+ txtClassName.Text +") this.BaseGet(index);\n");
			stringBuilder.Append("\n}");
			stringBuilder.Append("set\n");
			stringBuilder.Append("{\n");
			stringBuilder.Append("this.BaseSet(index,value);\n");
			stringBuilder.Append("\n}");
			stringBuilder.Append("\n}");


			//this Method on the basics of Key as string

			stringBuilder.Append("/// <summary>\n");
			stringBuilder.Append("/// This method is used to get/set "+txtClassName.Text + " object value in the collection \n");
			stringBuilder.Append("///on the basics of key of type string.\n");
			stringBuilder.Append("/// </summary>\n");
			stringBuilder.Append("public" + space + txtClassName.Text + space+"this[string key]\n");
			stringBuilder.Append("{\n");
				stringBuilder.Append("get\n");
					stringBuilder.Append("{\n");
						stringBuilder.Append("return ("+ txtClassName.Text +") this.BaseGet(key);\n");
					stringBuilder.Append("\n}");
				stringBuilder.Append("set\n");
					stringBuilder.Append("{\n");
						stringBuilder.Append("this.BaseSet(key,value);\n");
				stringBuilder.Append("\n}");
			stringBuilder.Append("\n}");



			//Add Method on the basics of Key as string

			stringBuilder.Append("/// <summary>\n");
			stringBuilder.Append("/// This method is used to add "+txtClassName.Text + " object  in the collection \n");
			stringBuilder.Append("///on the basics of key of type string.\n");
			stringBuilder.Append("/// </summary>\n");
			
			stringBuilder.Append("public void Add(string key,"+txtClassName.Text+space+ txtClassName.Text.ToLower()+")\n");
			stringBuilder.Append("{\n");
			stringBuilder.Append("this.BaseAdd(key,"+txtClassName.Text.ToLower() +");");
			stringBuilder.Append("\n}");

			//Clear method

			stringBuilder.Append("/// <summary>\n");
			stringBuilder.Append("/// This method is used to clear the value of the collection \n");
			stringBuilder.Append("/// </summary>\n");
			
			stringBuilder.Append("public void Clear()\n");
			stringBuilder.Append("{\n");
			stringBuilder.Append("this.BaseClear();\n");
			stringBuilder.Append("\n}");


			//Remove Method on the basics of Key as string

			stringBuilder.Append("/// <summary>\n");
			stringBuilder.Append("/// This method is used to remove "+txtClassName.Text + " object  from the collection \n");
			stringBuilder.Append("///on the basics of key of type string.\n");
			stringBuilder.Append("/// </summary>\n");
			
			stringBuilder.Append("public void Remove(string key)\n");
			stringBuilder.Append("{\n");
			stringBuilder.Append("this.BaseRemove(key);\n");
			stringBuilder.Append("\n}");
			
			//Remove Method on the basics of Index as int
			stringBuilder.Append("/// <summary>\n");
			stringBuilder.Append("/// This method is used to remove "+txtClassName.Text + " object  from the collection \n");
			stringBuilder.Append("///on the basics of collection index.\n");
			stringBuilder.Append("/// </summary>\n");

			stringBuilder.Append("public void Remove(int index)\n");
			stringBuilder.Append("{\n");
			stringBuilder.Append("this.BaseRemoveAt(index);\n");
			stringBuilder.Append("\n}");


			stringBuilder.Append("\n}\n }");
			txtCode.Text=stringBuilder.ToString();

		}

		private void panel1_Paint(object sender, System.Windows.Forms.PaintEventArgs e)
		{
		
		}

		private void btnClearCodeWin_Click(object sender, System.EventArgs e)
		{
			txtCode.Text="";
		}
	}
}
