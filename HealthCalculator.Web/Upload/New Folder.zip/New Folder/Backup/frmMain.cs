using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;

namespace CodeGen
{
	/// <summary>
	/// Summary description for frmMain.
	/// </summary>
	public class frmMain : System.Windows.Forms.Form
	{
		private System.Windows.Forms.Button btnProperty;
		private System.Windows.Forms.Button btnCollection;
		private System.Windows.Forms.Button btnClass;
		private System.Windows.Forms.Button btnParameterGenerator;
		private System.Windows.Forms.Button btnStoredProcedure;
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		public frmMain()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			//
			// TODO: Add any constructor code after InitializeComponent call
			//
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if(components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.btnProperty = new System.Windows.Forms.Button();
			this.btnCollection = new System.Windows.Forms.Button();
			this.btnClass = new System.Windows.Forms.Button();
			this.btnParameterGenerator = new System.Windows.Forms.Button();
			this.btnStoredProcedure = new System.Windows.Forms.Button();
			this.SuspendLayout();
			// 
			// btnProperty
			// 
			this.btnProperty.Location = new System.Drawing.Point(8, 8);
			this.btnProperty.Name = "btnProperty";
			this.btnProperty.Size = new System.Drawing.Size(112, 24);
			this.btnProperty.TabIndex = 1;
			this.btnProperty.Text = "Property Generator";
			this.btnProperty.Click += new System.EventHandler(this.btnProperty_Click);
			// 
			// btnCollection
			// 
			this.btnCollection.Location = new System.Drawing.Point(264, 8);
			this.btnCollection.Name = "btnCollection";
			this.btnCollection.Size = new System.Drawing.Size(128, 24);
			this.btnCollection.TabIndex = 2;
			this.btnCollection.Text = "Collection Generator";
			this.btnCollection.Click += new System.EventHandler(this.btnCollection_Click);
			// 
			// btnClass
			// 
			this.btnClass.Location = new System.Drawing.Point(128, 8);
			this.btnClass.Name = "btnClass";
			this.btnClass.Size = new System.Drawing.Size(128, 24);
			this.btnClass.TabIndex = 4;
			this.btnClass.Text = "Class Generator";
			this.btnClass.Click += new System.EventHandler(this.btnClass_Click);
			// 
			// btnParameterGenerator
			// 
			this.btnParameterGenerator.Location = new System.Drawing.Point(400, 8);
			this.btnParameterGenerator.Name = "btnParameterGenerator";
			this.btnParameterGenerator.Size = new System.Drawing.Size(128, 24);
			this.btnParameterGenerator.TabIndex = 6;
			this.btnParameterGenerator.Text = "SP Parameter Builder";
			this.btnParameterGenerator.Click += new System.EventHandler(this.btnParameterGenerator_Click);
			// 
			// btnStoredProcedure
			// 
			this.btnStoredProcedure.Location = new System.Drawing.Point(552, 8);
			this.btnStoredProcedure.Name = "btnStoredProcedure";
			this.btnStoredProcedure.Size = new System.Drawing.Size(96, 24);
			this.btnStoredProcedure.TabIndex = 8;
			this.btnStoredProcedure.Text = "Code Generator";
			this.btnStoredProcedure.Click += new System.EventHandler(this.btnStoredProcedure_Click);
			// 
			// frmMain
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(672, 246);
			this.Controls.Add(this.btnStoredProcedure);
			this.Controls.Add(this.btnParameterGenerator);
			this.Controls.Add(this.btnClass);
			this.Controls.Add(this.btnCollection);
			this.Controls.Add(this.btnProperty);
			this.IsMdiContainer = true;
			this.Name = "frmMain";
			this.Text = "Techlink Infoware Pvt. Ltd. Code Generator For C#.NET";
			this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
			this.Load += new System.EventHandler(this.frmMain_Load);
			this.ResumeLayout(false);

		}
		#endregion

		private void frmMain_Load(object sender, System.EventArgs e)
		{
		
		}
		/// <summary>
		/// The main entry point for the application.
		/// </summary>
		[STAThread]
		static void Main() 
		{
			Application.Run(new frmMain());
		}

		private void btnProperty_Click(object sender, System.EventArgs e)
		{
			Form newPropertyWindow=new frmPropertyCodeGen();
			newPropertyWindow.MdiParent=this;
			newPropertyWindow.StartPosition=FormStartPosition.CenterScreen;
			newPropertyWindow.Show();
		}

		private void btnCollection_Click(object sender, System.EventArgs e)
		{
			Form newCollectionWindow=new frmCollectionGenerator();
			newCollectionWindow.MdiParent=this;
			newCollectionWindow.StartPosition=FormStartPosition.CenterScreen;			
			newCollectionWindow.Show();
		}

		private void btnClass_Click(object sender, System.EventArgs e)
		{
			Form newClassWindow=new frmClassGenerator();
			newClassWindow.MdiParent=this;
			newClassWindow.StartPosition=FormStartPosition.CenterScreen;			
			newClassWindow.Show();
		
		}

		private void btnParameterGenerator_Click(object sender, System.EventArgs e)
		{
			Form newSpParameterbulder=new frmParameterGenerator();
			newSpParameterbulder.MdiParent=this;
			newSpParameterbulder.StartPosition=FormStartPosition.CenterScreen;			
			newSpParameterbulder.Show();
		}

		private void btnStoredProcedure_Click(object sender, System.EventArgs e)
		{
			Form newFinalCodeGenerator = new frmFinalCodeGenerator(); 
			newFinalCodeGenerator.MdiParent = this;
			newFinalCodeGenerator.StartPosition = FormStartPosition.CenterScreen;
			newFinalCodeGenerator.Show();
	
		}


	}
}
