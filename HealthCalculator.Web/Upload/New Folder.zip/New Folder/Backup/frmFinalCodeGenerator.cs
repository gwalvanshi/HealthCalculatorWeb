using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;
using System.Text;
using System.Data.SqlClient;
using System.Data.SqlTypes;
using System.Data.OleDb;


namespace CodeGen
{
	/// <summary>
	/// Summary description for frmFinalCodeGenerator.
	/// </summary>
	public class frmFinalCodeGenerator : System.Windows.Forms.Form
	{
		private System.Windows.Forms.TabControl tabCodeWizard;
		private System.Windows.Forms.GroupBox gbxBO;
		private System.Windows.Forms.GroupBox gbxDA;
		private System.Windows.Forms.GroupBox gbxMasterClass;
		private System.Windows.Forms.Label label9;
		private System.Windows.Forms.Label label3;
		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.Label label2;
		private System.Windows.Forms.Label label5;
		private System.Windows.Forms.Label label6;
		private System.Windows.Forms.Label label8;
		private System.Windows.Forms.TextBox txtMCClassName;
		private System.Windows.Forms.TextBox txtMCComments;
		private System.Windows.Forms.TextBox txtDAComments;
		private System.Windows.Forms.TextBox txtDAClassName;
		private System.Windows.Forms.Label label10;
		private System.Windows.Forms.TextBox txtDAParentClass;
		private System.Windows.Forms.Label label11;
		private System.Windows.Forms.Label label12;
		private System.Windows.Forms.TextBox txtBOComments;
		private System.Windows.Forms.TextBox txtBOClassName;
		private System.Windows.Forms.TextBox txtBODataClass;
		private System.Windows.Forms.ComboBox cmbTableName;
		private System.Windows.Forms.Label label16;
		private System.Windows.Forms.TextBox txtCreatedBy;
		private System.Windows.Forms.Label label17;
		private System.Windows.Forms.TextBox txtCreatedDate;
		private System.Windows.Forms.Label label18;
		private System.Windows.Forms.DataGrid dgFields;
		private System.Windows.Forms.CheckBox chkMasterClass;
		private System.Windows.Forms.CheckBox chkDataAccess;
		private System.Windows.Forms.CheckBox chkBusinessObject;
		private DataSet dsTableInfo;
		private System.Windows.Forms.RichTextBox txtSPInsert;
		private System.Windows.Forms.TabPage tabTable;
		private System.Windows.Forms.TabPage tabClass;
		private System.Windows.Forms.TabPage tabInsert;
		private System.Windows.Forms.TabPage tabUpdate;
		private System.Windows.Forms.TabPage tabDelete;
		private System.Windows.Forms.TabPage tabGet;
		private System.Windows.Forms.RichTextBox txtSPGet;
		private System.Windows.Forms.RichTextBox txtSPDelete;
		private System.Windows.Forms.RichTextBox txtSPUpdate;
		private System.Windows.Forms.TabPage tabSP;
		private System.Windows.Forms.Button btnGenerateSP;
		private System.Windows.Forms.DataGrid dgSP;
		private System.Windows.Forms.CheckBox chkInsertSelectAll;
		private System.Windows.Forms.Button btnClassGenerator;
		private System.Windows.Forms.CheckBox chkUpateSelectAll;
		private System.Windows.Forms.CheckBox chkDeleteSelectAll;
		private System.Windows.Forms.CheckBox chkGetSelectAll;
		private System.Windows.Forms.RichTextBox txtMasterClass;
		private System.Windows.Forms.TextBox txtNamespace;
		private System.Windows.Forms.TextBox txtBOParentClass;
		private System.Windows.Forms.TabPage tabMCCode;
		private System.Windows.Forms.TabPage tabBOCode;
		private System.Windows.Forms.RichTextBox txtBOCode;
		private System.Windows.Forms.TabPage tabDACode;
		private System.Windows.Forms.RichTextBox txtDACode;
		private System.Windows.Forms.Label label4;
		private System.Windows.Forms.TextBox txtDBConnect;
		private System.Windows.Forms.SaveFileDialog saveFileDialog1;
		private System.Windows.Forms.Button btnSaveSPInsert;
		private System.Windows.Forms.Button btnSaveSPUpdate;
		private System.Windows.Forms.Button btnSaveSPDelete;
		private System.Windows.Forms.Button btnSaveSPGet;
		private System.Windows.Forms.Button btnSelectMC;
		private System.Windows.Forms.Button btnSelectBO;
		private System.Windows.Forms.Button btnSelectDA;
		private System.Windows.Forms.Label label7;
		private System.Windows.Forms.ComboBox cmbDataBaseName;
		private System.Windows.Forms.Label label19;
		private System.Windows.Forms.ComboBox cmbConnectionType;
		private System.Windows.Forms.DataGrid dgDataAccess;
		private System.Windows.Forms.DataGrid dgBusinessObject;
		private System.Windows.Forms.Label label13;
		private System.Windows.Forms.ComboBox cmbProjectName;
		private System.Windows.Forms.TabPage tabBOCollection;
		private System.Windows.Forms.RichTextBox txtBOCollection;
		private System.Windows.Forms.Button button1;
		private System.Windows.Forms.Label label14;
		private System.Windows.Forms.TextBox txtCollectionName;
		private System.Windows.Forms.Label label20;
		private System.Windows.Forms.TextBox txtCollectionComment;
		private System.Windows.Forms.CheckBox chkChildClass;
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;
		private enum ProcedureType
		{
			Insert=0,
			Update=1,
			Delete=2,
			Get=3
		}
		private string GetInsertMethod(string classType,string comment)
		{
	
			string daClassNameVariable="";
			string daDB="";
			string connType = cmbConnectionType.SelectedItem.ToString();
			StringBuilder stringBuilder=new StringBuilder();
			//stringBuilder.Append("\n { \n");
			stringBuilder.Append("/// <summary>\n");
			stringBuilder.Append("///"+comment+"\n");
			stringBuilder.Append("/// </summary>\n\n");
			stringBuilder.Append("");
			stringBuilder.Append("\tpublic bool ");
			
			if(classType.Equals("BO"))
			{
				if(chkChildClass.Checked)
				{
					stringBuilder.Append("Add"+"("+txtDBConnect.Text+" "+txtDBConnect.Text.ToLower()+")\n");

				}
				else
					stringBuilder.Append("Add( )\n");
			}
				
			else
				stringBuilder.Append("InsertRecords( )\n");
			
			stringBuilder.Append("\t{\n");

			stringBuilder.Append("\t\tbool isStatus = false;\n");

			stringBuilder.Append("\t\ttry \n");
			
			stringBuilder.Append("\t\t{\n");

            daDB = "obj" + txtDBConnect.Text.Trim();//Substring(0, 1).ToLower() + txtDBConnect.Text.Substring(1, txtDBConnect.Text.Length - 1);				

			if(classType.Equals("BO"))
			{
				//Creating Connection class variable
                daClassNameVariable = "obj" + txtBODataClass.Text.Trim();// txtBODataClass.Text.Substring(0, 1).ToLower() + txtBODataClass.Text.Substring(1, txtBODataClass.Text.Length - 1);				
				stringBuilder.Append("\t\t\t" + txtDBConnect.Text +"  " +daDB + " = new " );		
				stringBuilder.Append(txtDBConnect.Text+"( );\n");
				
				//Creating transaction
				stringBuilder.Append("\t\t\t"+daDB+".BeginTrans();\n");

				//Creating DA class variable
				stringBuilder.Append("\t\t\t" + txtBODataClass.Text +"  " + daClassNameVariable + " = new " );		
				stringBuilder.Append(txtBODataClass.Text+"("+daDB+");\n");
				stringBuilder.Append("\t\t\t"+"PropertySet"+"("+daClassNameVariable+");\n");
			
				stringBuilder.Append("\t\t\tisStatus = " + daClassNameVariable + ".InsertRecords();\n" );		
				stringBuilder.Append("\t\t\tif(isStatus)\n");
				stringBuilder.Append("\t\t\t{\n");
				stringBuilder.Append("\t\t\t\t"+daDB+".CommitTrans();\n");
				stringBuilder.Append("\t\t\t\tisStatus=true;\n");
				stringBuilder.Append("\t\t\t}\n");																									 
				stringBuilder.Append("\t\t\telse\n");
				stringBuilder.Append("\t\t\t{\n");
                stringBuilder.Append("\t\t\t\t" + daDB + ".RollBackTrans();\n");
				stringBuilder.Append("\t\t\t\tisStatus=false;\n");
				stringBuilder.Append("\t\t\t}\n");
                              
               

			}

			if(classType.Equals("DA"))
			{
                stringBuilder.Append("\t\t\t" + connType + "Command " + "obj" + connType + "Command=new " + connType + "Command(" + @"""" + "usp_ins" + cmbTableName.Text + @"""" + "," + daDB + ".ActiveConnection," + daDB + ".ActiveTransaction);\n");
				stringBuilder.Append("\t\t\t"+ "obj"+ connType +"Command.CommandType=CommandType.StoredProcedure;\n");
                stringBuilder.Append("\t\t\t" + "PropertySet(" + "obj" + connType + "Command);\n");
                stringBuilder.Append("\t\t\tif(" + "obj" + connType + "Command.ExecuteNonQuery()>0)\n");
				stringBuilder.Append("\t\t\t\tisStatus=true;\n");
				stringBuilder.Append("\t\t\telse\n");
				stringBuilder.Append("\t\t\t\tisStatus=false;\n");
			}
          
			
			
			if(classType.Equals("BO"))
			{
                stringBuilder.Append("\t\t}\n");
                stringBuilder.Append("\t\tcatch(Exception ex) \n");
                stringBuilder.Append("\t\t{\n");
                stringBuilder.Append("\t\t\t\t" + daDB + ".RollBackTrans();\n");
                stringBuilder.Append("\t\t\t\t" + daDB + ".CloseConnection();\n");
                stringBuilder.Append("\t\t\t throw new Exception(\" ");
				stringBuilder.Append("Business Object: "+txtBOClassName.Text +"." );
				stringBuilder.Append("Method: Add.\"+ex.Message);\n");
                stringBuilder.Append("\t\t}\n");
                stringBuilder.Append("\t\t " + daDB + ".CloseConnection();\n");
                stringBuilder.Append("\t\treturn isStatus;\n");
                stringBuilder.Append("\t}");
			}
			
			if(classType.Equals("DA"))
			{
                stringBuilder.Append("\t\t}\n");
                stringBuilder.Append("\t\tcatch(Exception ex) \n");
                stringBuilder.Append("\t\t{\n");               
                stringBuilder.Append("\t\t\t throw new Exception(\" ");
				stringBuilder.Append("Data Access Object: "+txtDAClassName.Text +"." );
				stringBuilder.Append("Method: InsertRecords.\"+ex.Message);\n");
                stringBuilder.Append("\t\t}\n");
                stringBuilder.Append("\t\treturn isStatus;\n");
                stringBuilder.Append("\t}");
			}			

          
			return stringBuilder.ToString();
		}
		private string GetUpdateMethod(string classType,string comment)
		{
			string daClassNameVariable="";
			string daDB="";
			string connType = cmbConnectionType.SelectedItem.ToString();
			StringBuilder stringBuilder=new StringBuilder();
			
			//stringBuilder.Append("\n { \n");
			stringBuilder.Append("/// <summary>\n");
			stringBuilder.Append("///"+comment+"\n");
			stringBuilder.Append("/// </summary>\n\n");
			stringBuilder.Append("");
			
			
			stringBuilder.Append("\tpublic bool ");
			
			if(classType.Equals("BO"))
				stringBuilder.Append("Update( )\n");
			else
				stringBuilder.Append("UpdateRecords( )\n");
			
			stringBuilder.Append("\t{\n");

			stringBuilder.Append("\t\tbool isStatus = false;\n");

			stringBuilder.Append("\t\ttry \n");
			
			stringBuilder.Append("\t\t{\n");

            daDB = "obj" + txtDBConnect.Text.Trim(); //.Text.Substring(0,1).ToLower()+txtDBConnect.Text.Substring(1,txtDBConnect.Text.Length-1);				

			if(classType.Equals("BO"))
			{
				//Creating Connection class variable

                daClassNameVariable = "obj" + txtBODataClass.Text.Trim();// txtBODataClass.Text.Substring(0, 1).ToLower() + txtBODataClass.Text.Substring(1, txtBODataClass.Text.Length - 1);				
                stringBuilder.Append("\t\t\t" + txtDBConnect.Text + "  " + daDB + " = new ");
                stringBuilder.Append(txtDBConnect.Text + "( );\n");
				
				
				//Creating transaction
				stringBuilder.Append("\t\t\t"+daDB+".BeginTrans();\n");

				//Creating DA class variable
				stringBuilder.Append("\t\t\t" + txtBODataClass.Text +"  " + daClassNameVariable + " = new " );		
				stringBuilder.Append(txtBODataClass.Text+"("+daDB+");\n");
				stringBuilder.Append("\t\t\t"+"PropertySet"+"("+daClassNameVariable+");\n");
			
				stringBuilder.Append("\t\t\tisStatus = " + daClassNameVariable + ".UpdateRecords();\n" );		
				stringBuilder.Append("\t\t\tif(isStatus)\n");
				stringBuilder.Append("\t\t\t{\n");
				stringBuilder.Append("\t\t\t\t"+daDB+".CommitTrans();\n");
				stringBuilder.Append("\t\t\t\tisStatus=true;\n");
				stringBuilder.Append("\t\t\t}\n");
				stringBuilder.Append("\t\t\telse\n");
				stringBuilder.Append("\t\t\t{\n");
                stringBuilder.Append("\t\t\t\t" + daDB + ".RollBackTrans();\n");
				stringBuilder.Append("\t\t\t\tisStatus=false;\n");
				stringBuilder.Append("\t\t\t}\n");
			}

			if(classType.Equals("DA"))
			{
                stringBuilder.Append("\t\t\t" + connType + "Command " + "obj" + connType + "Command=new " + connType + "Command(" + @"""" + "usp_upd" + cmbTableName.Text + @"""" + "," + daDB + ".ActiveConnection," + daDB + ".ActiveTransaction);\n");
                stringBuilder.Append("\t\t\t" + "obj" + connType + "Command.CommandType=CommandType.StoredProcedure;\n");
                stringBuilder.Append("\t\t\t" + "PropertySet(" + "obj" + connType + "Command);\n");
                stringBuilder.Append("\t\t\tif(" + "obj" + connType + "Command.ExecuteNonQuery()>0)\n");
                stringBuilder.Append("\t\t\t\tisStatus=true;\n");
                stringBuilder.Append("\t\t\telse\n");
                stringBuilder.Append("\t\t\t\tisStatus=false;\n");
				
			}          
			
			
			if(classType.Equals("BO"))
			{
                stringBuilder.Append("\t\t}\n");
                stringBuilder.Append("\t\tcatch(Exception ex) \n");
                stringBuilder.Append("\t\t{\n");
                stringBuilder.Append("\t\t\t\t" + daDB + ".RollBackTrans();\n");
                stringBuilder.Append("\t\t\t\t" + daDB + ".CloseConnection();\n");
                stringBuilder.Append("\t\t\t throw new Exception(\" ");
				stringBuilder.Append("Business Object: "+txtBOClassName.Text +"." );
				stringBuilder.Append("Method: Add.\"+ex.Message);\n");
                stringBuilder.Append("\t\t}\n");
                stringBuilder.Append("\t\t " + daDB + ".CloseConnection();\n");
                stringBuilder.Append("\t\treturn isStatus;\n");
                stringBuilder.Append("\t}");
			}
			
			if(classType.Equals("DA"))
			{
                stringBuilder.Append("\t\t}\n");
                stringBuilder.Append("\t\tcatch(Exception ex) \n");
                stringBuilder.Append("\t\t{\n");
                stringBuilder.Append("\t\t\t throw new Exception(\" ");
				stringBuilder.Append("Data Access Object: "+txtDAClassName.Text +"." );
				stringBuilder.Append("Method: UpdateRecords.\"+ex.Message);\n");
                stringBuilder.Append("\t\t}\n");
                stringBuilder.Append("\t\treturn isStatus;\n");
                stringBuilder.Append("\t}");
			}

          
			return stringBuilder.ToString();
		}
		private string GetDeleteMethod(string classType, string comment)
		{
			string daClassNameVariable="";
			string daDB="";
			string connType = cmbConnectionType.SelectedItem.ToString();
			StringBuilder stringBuilder=new StringBuilder();
			//stringBuilder.Append("\n { \n");
			stringBuilder.Append("/// <summary>\n");
			stringBuilder.Append("///"+comment+"\n");
			stringBuilder.Append("/// </summary>\n\n");
			stringBuilder.Append("");
			
			stringBuilder.Append("\tpublic bool ");
			
			if(classType.Equals("BO"))
				stringBuilder.Append("Delete( )\n");
			else
				stringBuilder.Append("DeleteRecords( )\n");
			
			stringBuilder.Append("\t{\n");

			stringBuilder.Append("\t\tbool isStatus = false;\n");

			stringBuilder.Append("\t\ttry \n");
			
			stringBuilder.Append("\t\t{\n");

			 daDB = "obj" + txtDBConnect.Text.Trim(); //.Substring(0,1).ToLower()+txtDBConnect.Text.Substring(1,txtDBConnect.Text.Length-1);				

			if(classType.Equals("BO"))
			{
				//Creating Connection class variable
                daClassNameVariable = "obj" + txtBODataClass.Text.Trim();// txtBODataClass.Text.Substring(0, 1).ToLower() + txtBODataClass.Text.Substring(1, txtBODataClass.Text.Length - 1);				
                stringBuilder.Append("\t\t\t" + txtDBConnect.Text + "  " + daDB + " = new ");
                stringBuilder.Append(txtDBConnect.Text + "( );\n");				
				
				//Creating transaction
				stringBuilder.Append("\t\t\t"+daDB+".BeginTrans();\n");

				//Creating DA class variable
				stringBuilder.Append("\t\t\t" + txtBODataClass.Text +"  " + daClassNameVariable + " = new " );		
				stringBuilder.Append(txtBODataClass.Text+"("+daDB+");\n");
			}		
			if(classType.Equals("DA"))
			{
                stringBuilder.Append("\t\t\t" + connType + "Command " + "obj" + connType + "Command=new " + connType + "Command(" + @"""" + "usp_del" + cmbTableName.Text + @"""" + "," + daDB + ".ActiveConnection," + daDB + ".ActiveTransaction);\n");
                stringBuilder.Append("\t\t\t" + "obj" + connType + "Command.CommandType=CommandType.StoredProcedure;\n");

				
			}
			stringBuilder.Append(GetPropertySet(classType,"Delete"));

			if(classType.Equals("BO"))
			{
				stringBuilder.Append("\t\t\tisStatus = " + daClassNameVariable + ".DeleteRecords();\n" );		
				stringBuilder.Append("\t\t\tif(isStatus)\n");
				stringBuilder.Append("\t\t\t{\n");             
				stringBuilder.Append("\t\t\t\t"+daDB+".CommitTrans();\n");
				stringBuilder.Append("\t\t\t\tisStatus=true;\n");
				stringBuilder.Append("\t\t\t}\n");
				stringBuilder.Append("\t\t\telse\n");
				stringBuilder.Append("\t\t\t{\n");
                stringBuilder.Append("\t\t\t\t" + daDB + ".RollBackTrans();\n");
				stringBuilder.Append("\t\t\t\tisStatus=false;\n");
				stringBuilder.Append("\t\t\t}\n");
			}
			if(classType.Equals("DA"))	
			{
                stringBuilder.Append("\t\t\tif(" + "obj" + connType + "Command.ExecuteNonQuery()>0)\n");
				stringBuilder.Append("\t\t\t\tisStatus=true;\n");
				stringBuilder.Append("\t\t\telse\n");
				stringBuilder.Append("\t\t\t\tisStatus=false;\n");
			}

			
			
			if(classType.Equals("BO"))
			{
                stringBuilder.Append("\t\t}\n");

                stringBuilder.Append("\t\tcatch(Exception ex) \n");

                stringBuilder.Append("\t\t{\n");
                stringBuilder.Append("\t\t\t\t" + daDB + ".RollBackTrans();\n");
                stringBuilder.Append("\t\t\t\t" + daDB + ".CloseConnection();\n");
                stringBuilder.Append("\t\t\t throw new Exception(\" ");

				stringBuilder.Append("Business Object: "+txtBOClassName.Text +"." );
				stringBuilder.Append("Method: Delete.\"+ex.Message);\n");

                stringBuilder.Append("\t\t}\n");
                stringBuilder.Append("\t\t\t " + daDB + ".CloseConnection();\n");
                stringBuilder.Append("\t\treturn isStatus;\n");

                stringBuilder.Append("\t}");

			}
			
			if(classType.Equals("DA"))
			{
                stringBuilder.Append("\t\t}\n");
                stringBuilder.Append("\t\tcatch(Exception ex) \n");
                stringBuilder.Append("\t\t{\n");               
                stringBuilder.Append("\t\t\t throw new Exception(\" ");

				stringBuilder.Append("Data Access Object: "+txtDAClassName.Text +"." );
				stringBuilder.Append("Method: DeleteRecords.\"+ex.Message);\n");

                stringBuilder.Append("\t\t}\n");
                stringBuilder.Append("\t\treturn isStatus;\n");
                stringBuilder.Append("\t}");
			}
			
			return stringBuilder.ToString();
		}

		private string GetRecordsMethod(string classType,string comment)
		{
            string arrayList = "ArrayList";           
             
			string daClassNameVariable= "";
			string daDB="";
			string connType = cmbConnectionType.SelectedItem.ToString();
			StringBuilder stringBuilder=new StringBuilder();
            daDB = "obj" + txtDBConnect.Text.Trim(); 
			//stringBuilder.Append("\n { \n");
			stringBuilder.Append("/// <summary>\n");
			stringBuilder.Append("///"+comment+"\n");
			stringBuilder.Append("/// </summary>\n\n");
			stringBuilder.Append("");
            stringBuilder.Append("\tpublic ArrayList ");
			
			stringBuilder.Append("GetRecords( )\n");
			
			stringBuilder.Append("\t{\n");

            stringBuilder.Append("\t\t\t" + arrayList + "  " +"obj"+ txtBODataClass.Text.Substring(2, 13) + arrayList + " = new ");
            stringBuilder.Append(arrayList +"()"+ ";\n");

			stringBuilder.Append("\t\ttry \n");			
			stringBuilder.Append("\t\t{\n");
            stringBuilder.Append("\t\t\t" + connType + "Command " + "obj" + connType + "Command=new " + connType + "Command(" + @"""" + "usp_get" + cmbTableName.Text + @"""" + "," + daDB + ".ActiveConnection);\n");
            stringBuilder.Append("\t\t\t" + "obj" + connType + "Command.CommandType=CommandType.StoredProcedure;\n");
            stringBuilder.Append("\t\t\t" + connType + "DataReader" +" "+ "obj" + connType + "DataReader;\n");
            stringBuilder.Append("\t\t\t" + "obj" + connType + "DataReader" + "=" + "obj" + connType + "Command" + ".ExecuteReader();\n");
            stringBuilder.Append("\t\t\t" +"while(" +"obj" + connType + "DataReader" +".Read())\n");
            stringBuilder.Append("\t\t\t{\n");
            stringBuilder.Append("\t\t\t" + txtBODataClass.Text + "  " + "obj" + txtBODataClass.Text + " = new ");
            stringBuilder.Append(txtBODataClass.Text + "(" + daDB +" )" + ";\n");
            string propertyName = " ";
            DataTable dtFields = ((DataView)dgFields.DataSource).Table;
            for (int rowCount = 0; rowCount <= dtFields.Rows.Count - 1; rowCount++)
            {
                propertyName = dtFields.Rows[rowCount]["PropertyName"].ToString();

                stringBuilder.Append("\t\t\t"  + "obj" + txtBODataClass.Text+"."+propertyName+" =");
                stringBuilder.Append("obj" + connType + "DataReader" + "[" + @"""" + propertyName + @"""" + "]" +".ToString()" + ";\n");
            }
            stringBuilder.Append("\t\t\t" + "obj" + txtBODataClass.Text.Substring(2, 13) + arrayList + ".Add(" + "obj" + txtBODataClass.Text + ");\n");

            stringBuilder.Append("\t\t\t}\n");
			stringBuilder.Append("\t\t}\n");
			stringBuilder.Append("\t\tcatch(Exception ex) \n");			
			
			stringBuilder.Append("\t\t{\n");
			
			stringBuilder.Append("\t\t\t throw new Exception(\" ");
			
			
		    stringBuilder.Append("Data Access Object: "+txtDAClassName.Text +"." );
		     stringBuilder.Append("Method: GetRecords.\"+ex.Message);\n");
			stringBuilder.Append("\t\t}\n");
            stringBuilder.Append("\t\t" + "return" +" "+ "obj" + txtBODataClass.Text.Substring(2, 13) + arrayList + ";\n"); 
			stringBuilder.Append("\t}");
			return stringBuilder.ToString();
		}
		private string GetPropertySet(string classType,string methodType)
		{
			
			string propertyName="";
			string parameterName="";
			string daClassNameVariable="";
			string sqlType;
			string connType = cmbConnectionType.SelectedItem.ToString();
			bool isInsert=false,isUpdate=false,isGenerate=false;

			int maxLength;

			StringBuilder stringBuilder=new StringBuilder();
			DataTable dtFields =((DataView)dgFields.DataSource).Table;

			stringBuilder.Append("");
            daClassNameVariable = "obj" + txtBODataClass.Text.Trim();// Substring(0, 1).ToLower() + txtBODataClass.Text.Substring(1, txtBODataClass.Text.Length - 1);			
			if(!(methodType.Equals("Delete") || methodType.Equals("Get")))
			{
				if(classType.Equals("BO"))
				{

					stringBuilder.Append("\tprivate void PropertySet(");
					stringBuilder.Append(txtBODataClass.Text);
					stringBuilder.Append("  " + daClassNameVariable +")\n");
					stringBuilder.Append("\t{\n");
				}  

				if(classType.Equals("DA"))			
				{
                    daClassNameVariable = "obj" + txtBODataClass.Text.Trim();// Substring(0, 1).ToLower() + txtBODataClass.Text.Substring(1, txtBODataClass.Text.Length - 1);
					stringBuilder.Append("\tprivate void PropertySet(");
					stringBuilder.Append(connType+"Command "+"obj"+connType+"command)\n");
					stringBuilder.Append("\t{\n");
					stringBuilder.Append("\t\t\t"+connType+"Parameter "+"obj"+connType+"parameter=null;\n");				
				}
			}			
			for(int rowCount=0;rowCount <= dtFields.Rows.Count-1 ;rowCount++)
			{
				isInsert=false;isUpdate=false;
				isGenerate=false;
				
				switch(methodType)
				{
					case "Delete":
					{
						if(Convert.ToBoolean(dtFields.Rows[rowCount]["DeleteParam"].ToString()))
						{
							isGenerate=true;
						}
						break;
					}
					case "Get":
					{
						if(Convert.ToBoolean(dtFields.Rows[rowCount]["GetParam"].ToString()))
						{
							isGenerate=true;
						}
						break;
					}
					default:
					{
						isInsert= Convert.ToBoolean(dtFields.Rows[rowCount]["InsertParam"].ToString());
						isUpdate= Convert.ToBoolean(dtFields.Rows[rowCount]["UpdateParam"].ToString());
						if(isInsert && isUpdate)
						{
							isGenerate=true;
						}
						break;
					}
				}
				if(isGenerate)
				{
					propertyName= dtFields.Rows[rowCount]["PropertyName"].ToString();
					parameterName= dtFields.Rows[rowCount]["ParameterName"].ToString();
					sqlType=dtFields.Rows[rowCount]["SqlType"].ToString();
					maxLength=Convert.ToInt16(dtFields.Rows[rowCount]["MaxLength"].ToString());

					if(methodType.Equals("Delete") || methodType.Equals("Get"))
						stringBuilder.Append("\t");

					if(classType.Equals("BO"))
					{
						stringBuilder.Append("\t\t"+daClassNameVariable +"."+propertyName+" = "+propertyName +";");
						stringBuilder.Append("\n");
					}
					if(classType.Equals("DA"))
					{

                        stringBuilder.Append("\t\t\t" + "obj" + connType + "parameter=new " + connType + "Parameter(\"" + parameterName + "\",");
                        stringBuilder.Append(connType + "DbType." + GetSqlDBType(sqlType) + ","+maxLength+");\n"); //GetSqlDBType should be changed according to connection type
						if(methodType.Equals("Delete") || methodType.Equals("Get"))
							stringBuilder.Append("\t");
                        stringBuilder.Append("\t\t\t" + "obj" + connType + "parameter.Direction=ParameterDirection.Input;\n");
						if(methodType.Equals("Delete") || methodType.Equals("Get"))
							stringBuilder.Append("\t");
                        stringBuilder.Append("\t\t\t" + "obj" + connType + "parameter.Value=" + propertyName + ";\n");
						if(methodType.Equals("Delete") || methodType.Equals("Get"))
							stringBuilder.Append("\t");
                        stringBuilder.Append("\t\t\t" + "obj" + connType + "command.Parameters.Add(" + "obj" + connType + "parameter);\n");
						stringBuilder.Append("\n");		
					}
				}
			}
			if(!(methodType.Equals("Delete") || methodType.Equals("Get")))
				stringBuilder.Append("\t}");
			return stringBuilder.ToString();
		}
		private string GetSqlDBType(string dbType)
		{
			string sqlDbType="";
			switch(dbType.ToLower())
			{
				case"decimal":{sqlDbType= "Decimal";break;}
				case"float":{sqlDbType= "Float";break;}
				case"image":{sqlDbType= "Image";break;}
				case"int":{sqlDbType= "Int";break;}
				case"money":{sqlDbType= "Money";break;}
				case"nchar":{sqlDbType= "NChar";break;}
				case"ntext":{sqlDbType= "NText";break;}
				case"nvarchar":{sqlDbType= "NVarChar";break;}
				case"real":{sqlDbType= "Real";break;}					
				case"datetime":{sqlDbType= "DateTime";break;}
				case"smalldatetime":{sqlDbType= "SmallDateTime";break;}
				case"smallint":{sqlDbType= "SmallInt";break;}
				case"smallmoney":{sqlDbType= "SmallMoney";break;}
				case"text":{sqlDbType= "Text";break;}
				case"timestamp":{sqlDbType= "Timestamp";break;}
				case"tinyint":{sqlDbType= "TinyInt";break;}
				case"uniqueidentifier":{sqlDbType= "UniqueIdentifier";break;}
				case"varbinary":{sqlDbType= "VarBinary";break;}
				case"varchar":{sqlDbType= "VarChar";break;}
				case"variant":{sqlDbType= "Variant";break;}
				case"char":{sqlDbType= "Char";break;}
				case"bit":{sqlDbType= "Bit";break;}
			}
			return sqlDbType;
		}
        private string GetUpperClassBody(string className, string parentClassName, string comments, string classType)
		{
			StringBuilder stringBuilder=new StringBuilder();
			//Cretae a namespace 
			stringBuilder.Append("namespace  " +txtNamespace.Text);
			stringBuilder.Append("\n { \n");
			stringBuilder.Append("/// <summary>\n");
			stringBuilder.Append("///"+comments+"\n");
			stringBuilder.Append("/// </summary>\n\n");			
			stringBuilder.Append("public class "+className);
			
			if(parentClassName.Trim().Length>0)
				stringBuilder.Append(" : "+parentClassName);
           
			stringBuilder.Append("\n{\n");
            string daDB = "";
            if (classType.Equals("DA"))
            {
                daDB = "obj" + txtDBConnect.Text.Trim();
                 stringBuilder.Append("\t" + txtDBConnect.Text + "  " + daDB + " = new ");
                stringBuilder.Append(txtDBConnect.Text + "();\n");	                
            }             	          

			return stringBuilder.ToString();
		}
        private string GetConstructor(string className, bool isVariableInitialze, string classType)
		{
			string space=" ";
			string variableName="";
			string dataType="";			
			StringBuilder stringBuilder=new StringBuilder();	
			DataTable dtFields =((DataView)dgFields.DataSource).Table;
			stringBuilder.Append("");
            string daDB = "";
            string DaCommon = "";
            if (classType.Equals("DA"))
            {
                DaCommon = "obj" + txtDBConnect.Text.Trim();
                daDB = "obj" +"Data"+ txtDBConnect.Text.Substring(1, 0).ToLower() + txtDBConnect.Text.Substring(2, txtDBConnect.Text.Length - 2);
                stringBuilder.Append("\tpublic" + space + className + "(" + txtDBConnect.Text + " "+ daDB + " )\n");
                stringBuilder.Append("\t{\n");
                stringBuilder.Append("\t" +DaCommon+"="+daDB+" \n");
            }
            else
            {
                stringBuilder.Append("\tpublic" + space + className + "( )\n");
                stringBuilder.Append("\t{\n");
            }
			
			if(isVariableInitialze)
			{

				for(int rowCount=0;rowCount <= dtFields.Rows.Count-1 ;rowCount++)
				{						
					variableName= "_" + dtFields.Rows[rowCount]["VariableName"].ToString();
					dataType= dtFields.Rows[rowCount]["NetType"].ToString();
					switch(dataType)
					{
						case "bool":
						{
							stringBuilder.Append("\t\t"+ variableName +space+"="+ space+ "false;\n");
							break;
						}
						case "string":
						{
							stringBuilder.Append("\t\t"+ variableName +space+ "=");
							stringBuilder.Append("\""+"\";");
							stringBuilder.Append("\n");
							break;
						}
						default:
						{
							stringBuilder.Append("\t\t"+ variableName +space+"="+ space+ "0;\n");
							break;
						}
					}					
				}
			}
			stringBuilder.Append("\t}\n");
				
			return stringBuilder.ToString();
			
		}
		private string GetVariables()
		{
			string space=" ";
			string variableName="";
			string dataType="";
			StringBuilder stringBuilder=new StringBuilder();	
			DataTable dtFields =((DataView)dgFields.DataSource).Table;
			stringBuilder.Append("");
			for(int rowCount=0;rowCount <= dtFields.Rows.Count-1 ;rowCount++)
			{						
				variableName="_"+ dtFields.Rows[rowCount]["VariableName"].ToString();
				dataType= dtFields.Rows[rowCount]["NetType"].ToString();
				stringBuilder.Append("\tprivate"+space+ dataType+ space +variableName +";\n");
			}
			return stringBuilder.ToString();

		}
		private string GetProperties()
		{
			string space=" ";
			string propertyName="";
			string variableName="";
			string dataType="";
			string comments="";
			StringBuilder stringBuilder=new StringBuilder();
			DataTable dtFields =((DataView)dgFields.DataSource).Table;

			stringBuilder.Append("");

			for(int rowCount=0;rowCount <= dtFields.Rows.Count-1 ;rowCount++)
			{
		
				propertyName= dtFields.Rows[rowCount]["PropertyName"].ToString();
                variableName = "_" + dtFields.Rows[rowCount]["VariableName"].ToString();
				dataType= dtFields.Rows[rowCount]["NetType"].ToString();
				comments=dtFields.Rows[rowCount]["Comments"].ToString();

				stringBuilder.Append("\t/// <summary>\n");
				stringBuilder.Append("\t///"+comments+"\n");
				stringBuilder.Append("\t/// </summary>\n");

				stringBuilder.Append("\tpublic" +space+ dataType +space+propertyName +"\n");
				stringBuilder.Append("\t{\n");
				stringBuilder.Append("\t\tget");
				stringBuilder.Append("\n\t\t{");
				stringBuilder.Append("\n \t\t\treturn"+space+variableName+";");
				stringBuilder.Append("\n\t\t}");
				stringBuilder.Append("\n\t\tset");
				stringBuilder.Append("\n\t\t{");
				stringBuilder.Append("\n\t\t\t"+ variableName +"=value;");
				stringBuilder.Append("\n\t\t}");
				stringBuilder.Append("\n\t}");
				stringBuilder.Append("\n");
			}
			return stringBuilder.ToString();
		}
		private string GetDefaultNameSpace(string classType)
		{
			string connType = cmbConnectionType.SelectedItem.ToString();

			StringBuilder stringBuilder=new StringBuilder();
			stringBuilder.Append("using System;\n");
			if(classType.Equals("BO"))
				stringBuilder.Append("using System.Collections;\n");              

			if(classType.Equals("DA"))
			{
				stringBuilder.Append("using System.Data;\n");
				stringBuilder.Append("using System.Data.SqlClient;\n");
				stringBuilder.Append("using System.Data.SqlTypes;\n");
                stringBuilder.Append("using System.Collections;\n");
                stringBuilder.Append("using System.Collections.Generic;\n");               

				if(connType=="OleDB")
					stringBuilder.Append("using System.Data.OleDb;\n");
			}
			return stringBuilder.ToString();
		}
		private void GenerateMasterClass()
		{
			txtMasterClass.Text=GetUpperClassBody(txtMCClassName.Text," ",txtMCComments.Text,"")+"\n";
			txtMasterClass.Text=txtMasterClass.Text+GetVariables()+"\n";			
			txtMasterClass.Text=txtMasterClass.Text+GetConstructor(txtMCClassName.Text,true,"")+"\n";
			txtMasterClass.Text=txtMasterClass.Text+GetProperties()+"\n";
			txtMasterClass.Text=txtMasterClass.Text+"}\n}";
		}
		private void GenerateBOClass()
		{
			string comment="";
			txtBOCode.Text=GetDefaultNameSpace("BO");
			txtBOCode.Text=txtBOCode.Text+GetUpperClassBody(txtBOClassName.Text,txtBOParentClass.Text,txtBOComments.Text,"")+"\n";
			txtBOCode.Text=txtBOCode.Text+GetConstructor(txtBOClassName.Text,false,"")+"\n";
			txtBOCode.Text=txtBOCode.Text+GetPropertySet("BO","")+"\n";
			for(int item=0; item <= dgBusinessObject.VisibleRowCount; item++)
			{
				bool isSelected = bool.Parse(dgBusinessObject[item,0].ToString());
				if( item==0 && isSelected ==true)
				{
					comment =dgBusinessObject[item,3].ToString();
					txtBOCode.Text=txtBOCode.Text+GetInsertMethod("BO",comment)+"\n";
				}
				
				if( item==1 && isSelected ==true)
				{
					comment =dgBusinessObject[item,3].ToString();
					txtBOCode.Text=txtBOCode.Text+GetUpdateMethod("BO",comment)+"\n";
				}
				
				if( item==2 && isSelected ==true)
				{
					comment =dgBusinessObject[item,3].ToString();
					txtBOCode.Text=txtBOCode.Text+GetDeleteMethod("BO",comment)+"\n";
					txtBOCode.Text=txtBOCode.Text+"}\n}";
				}
				if(item==3 && isSelected ==true)
				{
					GenerateCollectionClass();
				}
			}
		}

		private void GenerateDAClass()
		{
			string comment = "";
            string DaClass = "DA";  // Add By Santosh Gwalvanshi 05/05/08 for DataAccess Class.      
			txtDACode.Text=GetDefaultNameSpace("DA");
            txtDACode.Text = txtDACode.Text + GetUpperClassBody(txtDAClassName.Text, txtDAParentClass.Text, txtDAComments.Text, DaClass) + "\n";
            txtDACode.Text = txtDACode.Text + GetConstructor(txtDAClassName.Text, false, DaClass) + "\n";
			txtDACode.Text=txtDACode.Text+GetPropertySet("DA","")+"\n";
			for(int item=0; item <= dgDataAccess.VisibleRowCount; item++)
			{
				bool isSelected = bool.Parse(dgDataAccess[item,0].ToString());
				if ( item==0 && isSelected ==true)
				{
					comment=dgDataAccess[item,3].ToString();
					txtDACode.Text=txtDACode.Text+GetInsertMethod("DA",comment)+"\n";
				}
				
				if ( item==1 && isSelected ==true)
				{
					comment=dgDataAccess[item,3].ToString();
					txtDACode.Text=txtDACode.Text+GetUpdateMethod("DA",comment)+"\n";
				}
				
				if ( item==2 && isSelected ==true)
				{
					comment=dgDataAccess[item,3].ToString();
					txtDACode.Text=txtDACode.Text+GetDeleteMethod("DA",comment)+"\n";
					txtDACode.Text=txtDACode.Text+"}\n}";
				}
				if ( item==3 && isSelected ==true)
				{
					comment=dgDataAccess[item,3].ToString();
					txtDACode.Text=txtDACode.Text+GetRecordsMethod("DA",comment)+"\n";
					txtDACode.Text=txtDACode.Text+"}\n}";
				}
			}
		}	
		private void GenerateCollectionClass()
		{
			string space=" ";
            string arrayList = "ArrayList";
            string daDB = "";
            daDB = "obj" + txtDBConnect.Text.Trim(); 
			StringBuilder stringBuilder=new StringBuilder();
			stringBuilder.Append("using System.Collections.Specialized;\n");
			stringBuilder.Append("namespace"+space +txtNamespace.Text);
			stringBuilder.Append("\n { \n");
			stringBuilder.Append("/// <summary>\n");
			stringBuilder.Append("///"+txtCollectionComment.Text+"\n");
			stringBuilder.Append("/// </summary>\n");
			
			stringBuilder.Append("public class"+space +txtCollectionName.Text +":NameObjectCollectionBase\n");
			stringBuilder.Append("\n { \n");
			stringBuilder.Append("public"+space+txtCollectionName.Text +"()\n{\n}");


			//this Method on the basics of index

			stringBuilder.Append("/// <summary>\n");
			stringBuilder.Append("/// This method is used to get/set "+txtBOClassName.Text + " object value in the collection \n");
			stringBuilder.Append("///on the basics of index as int.\n");
			stringBuilder.Append("/// </summary>\n");
			stringBuilder.Append("public" + space + txtBOClassName.Text + space+"this[int index]\n");
			stringBuilder.Append("{\n");
			stringBuilder.Append("get\n");
			stringBuilder.Append("{\n");
			stringBuilder.Append("return ("+ txtBOClassName.Text +") this.BaseGet(index);\n");
			stringBuilder.Append("\n}");
			stringBuilder.Append("set\n");
			stringBuilder.Append("{\n");
			stringBuilder.Append("this.BaseSet(index,value);\n");
			stringBuilder.Append("\n}");
			stringBuilder.Append("\n}");


			//this Method on the basics of Key as string

			stringBuilder.Append("/// <summary>\n");
			stringBuilder.Append("/// This method is used to get/set "+txtBOClassName.Text + " object value in the collection \n");
			stringBuilder.Append("///on the basics of key of type string.\n");
			stringBuilder.Append("/// </summary>\n");
			stringBuilder.Append("public" + space + txtBOClassName.Text + space+"this[string key]\n");
			stringBuilder.Append("{\n");
			stringBuilder.Append("get\n");
			stringBuilder.Append("{\n");
			stringBuilder.Append("return ("+ txtBOClassName.Text +") this.BaseGet(key);\n");
			stringBuilder.Append("\n}");
			stringBuilder.Append("set\n");
			stringBuilder.Append("{\n");
			stringBuilder.Append("this.BaseSet(key,value);\n");
			stringBuilder.Append("\n}");
			stringBuilder.Append("\n}");



			//Add Method on the basics of Key as string

			stringBuilder.Append("/// <summary>\n");
			stringBuilder.Append("/// This method is used to add "+txtBOClassName.Text + " object  in the collection \n");
			stringBuilder.Append("///on the basics of key of type string.\n");
			stringBuilder.Append("/// </summary>\n");
			
			stringBuilder.Append("public void Add(string key,"+txtBOClassName.Text+space+ txtBOClassName.Text.ToLower()+")\n");
			stringBuilder.Append("{\n");
			stringBuilder.Append("this.BaseAdd(key,"+txtBOClassName.Text.ToLower() +");");
			stringBuilder.Append("\n}");

			//Clear method

			stringBuilder.Append("/// <summary>\n");
			stringBuilder.Append("/// This method is used to clear the value of the collection \n");
			stringBuilder.Append("/// </summary>\n");
			
			stringBuilder.Append("public void Clear()\n");
			stringBuilder.Append("{\n");
			stringBuilder.Append("this.BaseClear();\n");
			stringBuilder.Append("\n}");


			//Remove Method on the basics of Key as string

			stringBuilder.Append("/// <summary>\n");
			stringBuilder.Append("/// This method is used to remove "+txtBOClassName.Text + " object  from the collection \n");
			stringBuilder.Append("///on the basics of key of type string.\n");
			stringBuilder.Append("/// </summary>\n");
			
			stringBuilder.Append("public void Remove(string key)\n");
			stringBuilder.Append("{\n");
			stringBuilder.Append("this.BaseRemove(key);\n");
			stringBuilder.Append("\n}");
			
			//Remove Method on the basics of Index as int
			stringBuilder.Append("/// <summary>\n");
			stringBuilder.Append("/// This method is used to remove "+txtBOClassName.Text + " object  from the collection \n");
			stringBuilder.Append("///on the basics of collection index.\n");
			stringBuilder.Append("/// </summary>\n");

			stringBuilder.Append("public void Remove(int index)\n");
			stringBuilder.Append("{\n");
			stringBuilder.Append("this.BaseRemoveAt(index);\n");
			stringBuilder.Append("\n}");

			stringBuilder.Append("\npublic bool Read()\n");
			stringBuilder.Append("{\n");
			stringBuilder.Append("this.Clear();\n");
			stringBuilder.Append("bool isStatus=false;\n");           
            stringBuilder.Append("\t" + arrayList + "  " + "obj" + txtBODataClass.Text.Substring(2, 13) + arrayList + " = new ");
            stringBuilder.Append(arrayList + "()" + ";\n");
            stringBuilder.Append(txtDBConnect.Text + " " + daDB + " = new " + txtDBConnect.Text + "();\n");
            stringBuilder.Append(txtDAClassName.Text + " " + "obj" + txtDAClassName.Text + " = new " + txtDAClassName.Text + "("+ daDB +");\n");
			stringBuilder.Append("try\n");
			stringBuilder.Append("{\n");
            stringBuilder.Append("\t"+ daDB + ".OpenConnection();\n");
            stringBuilder.Append("\t" + "obj" + txtBODataClass.Text.Substring(2, 13) + arrayList + "=" + "obj" + txtDAClassName.Text + ".GetRecords();\n");
            stringBuilder.Append("\t" + daDB + ".CloseConnection();\n");
            stringBuilder.Append("\tfor (int itemCount = 0; itemCount <" + "obj" + txtBODataClass.Text.Substring(2, 13) + arrayList + ".Count; itemCount++)\n");
            stringBuilder.Append("\t{\n");
            stringBuilder.Append("\t" +"obj" + txtDAClassName.Text + "= (" + txtDAClassName.Text + ")" + "obj" + txtBODataClass.Text.Substring(2, 13) + arrayList + "[itemCount];\n");
            stringBuilder.Append("\t" +txtBOClassName.Text + " " + "obj" + txtBOClassName.Text + " = new " + txtBOClassName.Text + "();\n");

            string propertyName = " ";
            DataTable dtFields = ((DataView)dgFields.DataSource).Table;
            for (int rowCount = 0; rowCount <= dtFields.Rows.Count - 1; rowCount++)
            {
                propertyName = dtFields.Rows[rowCount]["PropertyName"].ToString();

                stringBuilder.Append("\t" + "obj" + txtBOClassName.Text + "." + propertyName + " =");
                stringBuilder.Append("obj" + txtDAClassName.Text + "." + propertyName +";\n");
               
            }
            stringBuilder.Append("\tthis.Add(" + "obj" + txtBOClassName.Text + "." + dtFields.Rows[0]["PropertyName"].ToString() + ".ToString()," + "obj" + txtBOClassName.Text + ");\n");
            stringBuilder.Append("\tisStatus=true;\n");
            stringBuilder.Append("\t}\n");
            stringBuilder.Append("}\n");
            stringBuilder.Append("\treturn isStatus;\n");
			stringBuilder.Append("\ncatch(Exception ex)\n");
			stringBuilder.Append("{\n");
            stringBuilder.Append("throw new Exception(\"" + txtNamespace.Text + "." + txtCollectionName.Text + ".Read()" + "\\n\" +ex.Message);\n");
          
			stringBuilder.Append("\n}");
			stringBuilder.Append("\n}");
			stringBuilder.Append("\n}");
            stringBuilder.Append("\n}");
			txtBOCollection.Text=stringBuilder.ToString();
		}       
		private void FillSPGrid()
		{
			DataGridTableStyle dataGridTableStyle = new DataGridTableStyle();
			dataGridTableStyle.MappingName ="SPComment";
			dataGridTableStyle.PreferredRowHeight=25;

			DataGridColumnStyle dataGridTextBoxColumn = new DataGridTextBoxColumn();
			dataGridTextBoxColumn.MappingName = "Comment";
			dataGridTextBoxColumn.HeaderText ="" ;
			dataGridTextBoxColumn.ReadOnly=true;
			dataGridTextBoxColumn.Width =100;			
			
			dataGridTableStyle.GridColumnStyles.Add(dataGridTextBoxColumn);

			DataGridColumnStyle dataGridTextBoxColumn1 = new DataGridTextBoxColumn();
			dataGridTextBoxColumn1.MappingName = "CommentValue";
			dataGridTextBoxColumn1.HeaderText =" " ;
			dataGridTextBoxColumn1.ReadOnly=false;
			dataGridTextBoxColumn1.Width =500;		
			dataGridTableStyle.GridColumnStyles.Add(dataGridTextBoxColumn1);
			
			dgSP.TableStyles.Clear();
			dgSP.TableStyles.Add(dataGridTableStyle);
			
			DataSet ds=new DataSet();
			ds.ReadXml("Common.xml");

			dgSP.DataSource=ds.Tables["SPComment"].DefaultView;
			((DataView)dgSP.DataSource).AllowNew = false;	

			dgSP.TableStyles[0].GridColumnStyles[0].ReadOnly=true;

		}
		private string GetFields(ProcedureType procedureType,bool isWhereClause)
		{			
			DataTable dtFields= new DataTable();
			StringBuilder stringBuilder=new StringBuilder();
			string space=" ";
			dtFields =((DataView)dgFields.DataSource).Table;			
	
			for(int rowCount=0;rowCount <= dtFields.Rows.Count-1 ;rowCount++)
			{
				
				switch(procedureType)
				{
					case ProcedureType.Insert:
					{
						if(dtFields.Rows[rowCount]["InsertParam"].ToString().Equals("True"))
						{
							stringBuilder.Append("\t");
							stringBuilder.Append(dtFields.Rows[rowCount]["FieldName"].ToString()+",\n");
						}
						break;
					}

					case ProcedureType.Update:
					{
						if(dtFields.Rows[rowCount]["UpdateParam"].ToString().Equals("True"))
						{
							stringBuilder.Append("\t");
							stringBuilder.Append(dtFields.Rows[rowCount]["FieldName"].ToString());
							stringBuilder.Append(space+"="+space);
							stringBuilder.Append(dtFields.Rows[rowCount]["ParameterName"].ToString()+",\n");
						}
						break;
					}
					case ProcedureType.Delete:
					{
						if(dtFields.Rows[rowCount]["DeleteParam"].ToString().Equals("True"))
						{
							stringBuilder.Append("\t");
							stringBuilder.Append(dtFields.Rows[rowCount]["FieldName"].ToString());
							stringBuilder.Append(space +"="+space);
							stringBuilder.Append(dtFields.Rows[rowCount]["ParameterName"].ToString()+",\n");
						}
						break;
					}
					case ProcedureType.Get:
					{
			
						if(!isWhereClause)
						{
							stringBuilder.Append("\t");
							stringBuilder.Append(dtFields.Rows[rowCount]["FieldName"].ToString()+",\n");
						}
						else
						{
							if(dtFields.Rows[rowCount]["GetParam"].ToString().Equals("True"))
							{							
								stringBuilder.Append("\t");
								stringBuilder.Append(dtFields.Rows[rowCount]["FieldName"].ToString());
								stringBuilder.Append(space +"="+space);
								stringBuilder.Append(dtFields.Rows[rowCount]["ParameterName"].ToString()+" and \n");

							}
						}
						break;
					}
				}			
			}
			
			if(!isWhereClause)
			{
				if(stringBuilder.ToString().Length>2)
					return stringBuilder.ToString().Substring(0,stringBuilder.ToString().Length-2);
				else
					return stringBuilder.ToString();
			}
			else
			{
				if(stringBuilder.ToString().Length>6)
					return stringBuilder.ToString().Substring(0,stringBuilder.ToString().Length-6);
				else
					return stringBuilder.ToString();

			}
		}
		//		private string GetInputParametersString(ProcedureType procedureType)

		private string GetInputParameters(string procedureType,bool hasWithDataType,bool isTabSpaceAddBefore)
		{			
			DataTable dtFields= new DataTable();
			StringBuilder stringBuilder=new StringBuilder();
			string space=" ";
			dtFields =((DataView)dgFields.DataSource).Table;
			bool isInputParam=false;
			for(int rowCount=0;rowCount <= dtFields.Rows.Count-1 ;rowCount++)
			{
				isInputParam=false;			
				switch(procedureType)
				{
					case "ins":
					{
						if(dtFields.Rows[rowCount]["InsertParam"].ToString().Equals("True"))
						{
							isInputParam=true;
						}
						break;
					}
					case "upd":
					{
						if(dtFields.Rows[rowCount]["UpdateParam"].ToString().Equals("True"))
						{
							isInputParam=true;
						}
						break;
					}
					case "del":
					{
						if(dtFields.Rows[rowCount]["DeleteParam"].ToString().Equals("True"))
						{
							isInputParam=true;
						}
						break;
					}
					case "get":
					{
						if(dtFields.Rows[rowCount]["GetParam"].ToString().Equals("True"))
						{
							isInputParam=true;
						}
						break;
					}
				}
				if (isInputParam)
				{
					if(isTabSpaceAddBefore)
						stringBuilder.Append("\t");
					stringBuilder.Append(dtFields.Rows[rowCount]["ParameterName"].ToString());

					if(hasWithDataType )
					{
						stringBuilder.Append(space);
						stringBuilder.Append(dtFields.Rows[rowCount]["SqlType"].ToString());
					}
					stringBuilder.Append(",\n");
				}

			}
			if(stringBuilder.ToString().Length>2)
				return stringBuilder.ToString().Substring(0,stringBuilder.ToString().Length-2)+"\n";
			else
				return stringBuilder.ToString();

		}
		private void FieldsGridDesign()
		{
			DataGridTableStyle dataGridTableStyle = new DataGridTableStyle();
			dataGridTableStyle.MappingName ="Table";
			
			DataGridTextBoxColumn dataGridTextBoxColumn = new DataGridTextBoxColumn();
			dataGridTextBoxColumn.MappingName = "FieldName";
			dataGridTextBoxColumn.HeaderText ="Field Name" ;
			dataGridTextBoxColumn.ReadOnly=true;
			dataGridTextBoxColumn.Width =100;
			
			dataGridTableStyle.GridColumnStyles.Add(dataGridTextBoxColumn);

			DataGridTextBoxColumn TextCol2  = new DataGridTextBoxColumn();
			TextCol2.MappingName = "SqlType";
			TextCol2.HeaderText ="SqlType" ;
			TextCol2.ReadOnly=true;
			TextCol2.Width = 50;
			dataGridTableStyle.GridColumnStyles.Add(TextCol2);

			DataGridTextBoxColumn TextCol3 = new DataGridTextBoxColumn();
			TextCol3.MappingName = "MaxLength";
			TextCol3.HeaderText ="Max Length" ;
			TextCol3.ReadOnly=true;
			TextCol3.Width = 25;
			dataGridTableStyle.GridColumnStyles.Add(TextCol3);

			DataGridTextBoxColumn TextCol4 = new DataGridTextBoxColumn();
			TextCol4.MappingName = "ShortSqlType";
			TextCol4.HeaderText ="ShortSqlType" ;
			TextCol4.ReadOnly=true;
			TextCol4.Width = 25;
			dataGridTableStyle.GridColumnStyles.Add(TextCol4);
			
			DataGridTextBoxColumn TextCol5 = new DataGridTextBoxColumn();
			TextCol5.MappingName = "ParameterName";
			TextCol5.HeaderText ="Parameter Name" ;
			TextCol5.ReadOnly=true;
			TextCol5.Width = 150;
			dataGridTableStyle.GridColumnStyles.Add(TextCol5);

			DataGridBoolColumn boolCol1 = new DataGridBoolColumn();
			boolCol1.MappingName = "InsertParam";
			boolCol1.HeaderText ="Insert";
			boolCol1.Width = 25;
			boolCol1.AllowNull=false;
			dataGridTableStyle.GridColumnStyles.Add(boolCol1);
		
			DataGridBoolColumn boolCol2 = new DataGridBoolColumn();
			boolCol2.MappingName = "UpdateParam";
			boolCol2.HeaderText ="Update";
			boolCol2.Width = 25;
			boolCol2.AllowNull=false;
			dataGridTableStyle.GridColumnStyles.Add(boolCol2);

			DataGridBoolColumn boolCol3 = new DataGridBoolColumn();
			boolCol3.MappingName = "DeleteParam";
			boolCol3.HeaderText ="Delete";			
			boolCol3.Width = 25;			
			boolCol3.AllowNull=false;	
			dataGridTableStyle.GridColumnStyles.Add(boolCol3);

			DataGridBoolColumn boolCol4 = new DataGridBoolColumn();
			boolCol4.MappingName = "GetParam";
			boolCol4.HeaderText ="Get";
			boolCol4.Width =25;
			boolCol4.AllowNull=false;
			dataGridTableStyle.GridColumnStyles.Add(boolCol4);

			DataGridTextBoxColumn TextCol6 = new DataGridTextBoxColumn();
			TextCol6.MappingName = "PropertyName";
			TextCol6.HeaderText ="Property Name" ;
			TextCol6.ReadOnly=true;
			TextCol6.Width = 150;
			dataGridTableStyle.GridColumnStyles.Add(TextCol6);

			DataGridTextBoxColumn TextCol7 = new DataGridTextBoxColumn();
			TextCol7.MappingName = "VariableName";
			TextCol7.HeaderText ="Variable Name" ;
			TextCol7.ReadOnly=true;
			TextCol7.Width = 150;
			dataGridTableStyle.GridColumnStyles.Add(TextCol7);

			DataGridTextBoxColumn TextCol8 = new DataGridTextBoxColumn();
			TextCol8.MappingName = "NetType";
			TextCol8.HeaderText =".Net Type" ;
			TextCol8.ReadOnly=true;
			TextCol8.Width = 25;
			dataGridTableStyle.GridColumnStyles.Add(TextCol8);

			DataGridTextBoxColumn TextCol9 = new DataGridTextBoxColumn();
			TextCol9.MappingName = "Comments";
			TextCol9.HeaderText ="Comments" ;
			TextCol9.ReadOnly=true;
			TextCol9.Width = 100;
			dataGridTableStyle.GridColumnStyles.Add(TextCol9);

			DataGridTextBoxColumn TextCol10 = new DataGridTextBoxColumn();
			TextCol10.MappingName = "Ordinal_Position";
			TextCol10.HeaderText ="Ordinal Position" ;
			TextCol10.ReadOnly=true;
			TextCol10.Width=0;
			dataGridTableStyle.GridColumnStyles.Add(TextCol10);
      
			// Add the DataGridTableStyle objects to the collection.
			dgFields.TableStyles.Clear();
			dgFields.TableStyles.Add(dataGridTableStyle );
			dataGridTableStyle.AllowSorting=false;
			
			FillGrid();
		}		
		private void FillTableList()
		{
			if (cmbDataBaseName.SelectedIndex >= 0 && cmbDataBaseName.SelectedValue.ToString()!="System.Data.DataRowView")
			{
				string dataBaseName = cmbDataBaseName.SelectedValue.ToString();
				string sqlCon=System.Configuration.ConfigurationSettings.AppSettings["ConnectionString"]+ ";initial catalog="+dataBaseName+"";
				SqlDataAdapter sqlDataAdapter = new  SqlDataAdapter("USE "+dataBaseName +" SELECT Table_Name FROM Information_Schema.Tables WHERE Table_Type = 'BASE TABLE'",sqlCon);
				DataSet ds = new DataSet();
			
				sqlDataAdapter.Fill(ds,"TableName");
				cmbTableName.DataSource=ds.Tables["TableName"].DefaultView;		
		
				cmbTableName.DisplayMember=ds.Tables["TableName"].Columns["Table_Name"].ToString();
				cmbTableName.ValueMember=ds.Tables["TableName"].Columns["Table_Name"].ToString();				
		
			}
				
		}
		/// <summary>
		/// This method is used to assign DataGridTableStyle to grids
		/// dgDataAccess and dgBusinessObject
		/// </summary>
		private void GridDesign(string gridType)
		{
			
			DataGridTableStyle dataGridTableStyle = new DataGridTableStyle();
			dataGridTableStyle.MappingName =gridType+ "Table";		

			DataGridBoolColumn Col1 = new DataGridBoolColumn();
			Col1.MappingName = "Select";
			Col1.HeaderText ="";
			Col1.Width =15;			
			Col1.AllowNull=false;

			dataGridTableStyle.GridColumnStyles.Add(Col1);
			DataGridTextBoxColumn gridTextBoxColumn = new DataGridTextBoxColumn();
			gridTextBoxColumn.MappingName = "DefaultName"; 
			gridTextBoxColumn.HeaderText ="DeFault Name";
			gridTextBoxColumn.ReadOnly=true;
			gridTextBoxColumn.Width =80;

			dataGridTableStyle.GridColumnStyles.Add(gridTextBoxColumn);

			DataGridTextBoxColumn Col2  = new DataGridTextBoxColumn();
			Col2.MappingName = "CustomizedName";
			Col2.HeaderText ="Customized. Name" ;
			Col2.ReadOnly=false;
			Col2.Width = 80;

			dataGridTableStyle.GridColumnStyles.Add(Col2);
			

			DataGridTextBoxColumn Col3 = new DataGridTextBoxColumn();
			Col3.MappingName = "Comments";
			Col3.HeaderText ="Comments" ;
			Col3.ReadOnly=false;
			Col3.Width = 320;
			dataGridTableStyle.GridColumnStyles.Add(Col3);		
			
			if(gridType.Equals("DA"))
			{
				dgDataAccess.TableStyles.Clear();
				dgDataAccess.TableStyles.Add(dataGridTableStyle);
			}
			else
			{
				dgBusinessObject.TableStyles.Clear();
				dgBusinessObject.TableStyles.Add(dataGridTableStyle);
			}			
		}
		private void FillProjectList()
		{
			ListViewItem listviewitem = new ListViewItem("----",0);
			string sqlCon=System.Configuration.ConfigurationSettings.AppSettings["ConnectionString"]+ ";initial catalog=ProjectMaint";
		//" user id=sa;data source=devserver;persist security info=False;initial catalog=ProjectMaint";
			SqlDataAdapter sqlDataAdapter = new  SqlDataAdapter("Select ProjectID,ProjectName from Projects",sqlCon);
			DataSet ds = new DataSet();
			sqlDataAdapter.Fill(ds,"ProjectName");
			cmbProjectName.DataSource=ds.Tables["ProjectName"].DefaultView;		
			
			cmbProjectName.DisplayMember=ds.Tables["ProjectName"].Columns["ProjectName"].ToString();
			cmbProjectName.ValueMember=ds.Tables["ProjectName"].Columns["ProjectID"].ToString();				
		
		}

		private void FillDataBaseList()
		{
			int projectID =0;
			
			if (cmbProjectName.SelectedIndex > 0)
				projectID	= int.Parse(cmbProjectName.SelectedValue.ToString());
			else 
				projectID=1;
			string sqlCon=System.Configuration.ConfigurationSettings.AppSettings["ConnectionString"]+ ";initial catalog=ProjectMaint";
			SqlDataAdapter sqlDataAdapter = new  SqlDataAdapter("Usp_GetDataBases",sqlCon);
			sqlDataAdapter.SelectCommand.CommandType=CommandType.StoredProcedure;
			sqlDataAdapter.SelectCommand.Parameters.Add(new SqlParameter("@int_ProjectID", SqlDbType.Int));
			sqlDataAdapter.SelectCommand.Parameters["@int_ProjectID"].Value = projectID;
			DataSet ds = new DataSet();
			sqlDataAdapter.Fill(ds,"DataBasesName");
			cmbDataBaseName.DataSource=ds.Tables["DataBasesName"].DefaultView;		
			cmbDataBaseName.DisplayMember=ds.Tables["DataBasesName"].Columns["DataBaseName"].ToString();
			cmbDataBaseName.ValueMember=ds.Tables["DataBasesName"].Columns["DataBaseName"].ToString();				
			
			
		}

		private void FillGrid()
		{
			string tableName =cmbTableName.SelectedValue.ToString();
			string dataBaseName = cmbDataBaseName.SelectedValue.ToString();
			string sqlCon=System.Configuration.ConfigurationSettings.AppSettings["ConnectionString"]+ ";initial catalog=ProjectMaint"; //
			
			SqlConnection sqlConnection=new SqlConnection(sqlCon);
			sqlConnection.Open();
			SqlDataAdapter sqlDataAdapter = new  SqlDataAdapter("Usp_GetTableFields"+"_"+dataBaseName,sqlConnection);
			sqlDataAdapter.SelectCommand.CommandType=CommandType.StoredProcedure;
			sqlDataAdapter.SelectCommand.Parameters.Add(new SqlParameter("@tablename", SqlDbType.VarChar,75));
			sqlDataAdapter.SelectCommand.Parameters["@tablename"].Value = tableName;
			dsTableInfo = new DataSet("TableInfo");			
			sqlDataAdapter.Fill(dsTableInfo);
			dgFields.DataSource=dsTableInfo.Tables[0].DefaultView;
			((DataView)dgFields.DataSource).AllowNew = false;	
		}

		private void FillBussinessObjectGrid()
		{
			string dataAccess=txtDAClassName.Text;
			string tableName= cmbTableName.SelectedValue.ToString();	
			DataTable dt=new DataTable("BOTable");
			dt.Columns.Add("Select",typeof(bool));
			dt.Columns.Add("DefaultName",typeof(string));
			dt.Columns.Add("CustomizedName",typeof(string));
			dt.Columns.Add("Comments",typeof(string));
					
			DataRow dr1=dt.NewRow();
			dr1["Select"]=true;
			dr1["DefaultName"]="Add";
			dr1["CustomizedName"]="Add";
			dr1["Comments"]="This method is used to add a record into the table "+ tableName + "by using " + dataAccess + ".InsertRecords";
			dt.Rows.Add(dr1);

			DataRow dr2=dt.NewRow();
			dr2["Select"]=true;
			dr2["DefaultName"]="Edit";
			dr2["CustomizedName"]="Edit";
			dr2["Comments"]="This method is used to edit a record into the table "+ tableName +  "by using " + dataAccess + ".UpdateRecords";
			dt.Rows.Add(dr2);

			DataRow dr3=dt.NewRow();
			dr3["Select"]=true;
			dr3["DefaultName"]="Delete";
			dr3["CustomizedName"]="Delete";
			dr3["Comments"]="This method is used to delete a record into the table " + tableName + "by using " + dataAccess + ".DeleteRecords";
			dt.Rows.Add(dr3);
						
			DataRow dr4=dt.NewRow();
			dr4["Select"]=true;
			dr4["DefaultName"]="Read";
			dr4["CustomizedName"]="Read";
			dr4["Comments"]="This method is used to read a record into the table " + tableName + "by using " + dataAccess + ".GetRecords";
			dt.Rows.Add(dr4);

			dgBusinessObject.DataSource=dt.DefaultView;
			((DataView)dgBusinessObject.DataSource).AllowNew=false;
					
		}

		private void FillDataAccessGrid()
		{
			string tableName= cmbTableName.SelectedValue.ToString();	
			DataTable dt=new DataTable("DATable"); 
			dt.Columns.Add("Select",typeof(bool));
			dt.Columns.Add("DefaultName",typeof(string));
			dt.Columns.Add("CustomizedName",typeof(string));
			dt.Columns.Add("Comments",typeof(string));					

			DataRow dr1=dt.NewRow();
			dr1["Select"]=true;
			dr1["DefaultName"]="InsertRecords";
			dr1["CustomizedName"]="InsertRecords";
			dr1["Comments"]="This method is used to insert a record into the table "+ tableName;
			dt.Rows.Add(dr1);

			DataRow dr2=dt.NewRow();
			dr2["Select"]=true;
			dr2["DefaultName"]="UpdateRecords";
			dr2["CustomizedName"]="UpdateRecords";
			dr2["Comments"]="This method is used to update a record into the table "+ tableName;
			dt.Rows.Add(dr2);

			DataRow dr3=dt.NewRow();
			dr3["Select"]=true;
			dr3["DefaultName"]="DeleteRecords";
			dr3["CustomizedName"]="DeleteRecords";
			dr3["Comments"]="This method is used to delete a record into the table "+ tableName;
			dt.Rows.Add(dr3);
						
			DataRow dr4=dt.NewRow();
			dr4["Select"]=true;
			dr4["DefaultName"]="GetRecords";
			dr4["CustomizedName"]="GetRecords";
			dr4["Comments"]="This method is used to get a record into the table "+ tableName;
			dt.Rows.Add(dr4);

			dgDataAccess.DataSource=dt.DefaultView;
			((DataView)dgDataAccess.DataSource).AllowNew = false;
		}


		public frmFinalCodeGenerator()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			//
			// TODO: Add any constructor code after InitializeComponent call
			//
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if(components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}
		

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
            this.tabCodeWizard = new System.Windows.Forms.TabControl();
            this.tabTable = new System.Windows.Forms.TabPage();
            this.cmbProjectName = new System.Windows.Forms.ComboBox();
            this.label13 = new System.Windows.Forms.Label();
            this.cmbConnectionType = new System.Windows.Forms.ComboBox();
            this.label19 = new System.Windows.Forms.Label();
            this.cmbDataBaseName = new System.Windows.Forms.ComboBox();
            this.label7 = new System.Windows.Forms.Label();
            this.chkGetSelectAll = new System.Windows.Forms.CheckBox();
            this.chkDeleteSelectAll = new System.Windows.Forms.CheckBox();
            this.chkUpateSelectAll = new System.Windows.Forms.CheckBox();
            this.chkInsertSelectAll = new System.Windows.Forms.CheckBox();
            this.txtCreatedBy = new System.Windows.Forms.TextBox();
            this.label17 = new System.Windows.Forms.Label();
            this.txtCreatedDate = new System.Windows.Forms.TextBox();
            this.label18 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.cmbTableName = new System.Windows.Forms.ComboBox();
            this.dgFields = new System.Windows.Forms.DataGrid();
            this.tabSP = new System.Windows.Forms.TabPage();
            this.dgSP = new System.Windows.Forms.DataGrid();
            this.btnGenerateSP = new System.Windows.Forms.Button();
            this.tabClass = new System.Windows.Forms.TabPage();
            this.label4 = new System.Windows.Forms.Label();
            this.txtDBConnect = new System.Windows.Forms.TextBox();
            this.btnClassGenerator = new System.Windows.Forms.Button();
            this.chkDataAccess = new System.Windows.Forms.CheckBox();
            this.gbxDA = new System.Windows.Forms.GroupBox();
            this.chkChildClass = new System.Windows.Forms.CheckBox();
            this.dgDataAccess = new System.Windows.Forms.DataGrid();
            this.txtDAParentClass = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.txtDAComments = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.txtDAClassName = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.chkMasterClass = new System.Windows.Forms.CheckBox();
            this.label9 = new System.Windows.Forms.Label();
            this.txtNamespace = new System.Windows.Forms.TextBox();
            this.chkBusinessObject = new System.Windows.Forms.CheckBox();
            this.gbxBO = new System.Windows.Forms.GroupBox();
            this.txtCollectionComment = new System.Windows.Forms.TextBox();
            this.label14 = new System.Windows.Forms.Label();
            this.txtCollectionName = new System.Windows.Forms.TextBox();
            this.label20 = new System.Windows.Forms.Label();
            this.dgBusinessObject = new System.Windows.Forms.DataGrid();
            this.txtBODataClass = new System.Windows.Forms.TextBox();
            this.label12 = new System.Windows.Forms.Label();
            this.txtBOParentClass = new System.Windows.Forms.TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.txtBOComments = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.txtBOClassName = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.gbxMasterClass = new System.Windows.Forms.GroupBox();
            this.txtMCComments = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.txtMCClassName = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.tabInsert = new System.Windows.Forms.TabPage();
            this.btnSaveSPInsert = new System.Windows.Forms.Button();
            this.txtSPInsert = new System.Windows.Forms.RichTextBox();
            this.tabUpdate = new System.Windows.Forms.TabPage();
            this.btnSaveSPUpdate = new System.Windows.Forms.Button();
            this.txtSPUpdate = new System.Windows.Forms.RichTextBox();
            this.tabDelete = new System.Windows.Forms.TabPage();
            this.btnSaveSPDelete = new System.Windows.Forms.Button();
            this.txtSPDelete = new System.Windows.Forms.RichTextBox();
            this.tabGet = new System.Windows.Forms.TabPage();
            this.btnSaveSPGet = new System.Windows.Forms.Button();
            this.txtSPGet = new System.Windows.Forms.RichTextBox();
            this.tabMCCode = new System.Windows.Forms.TabPage();
            this.btnSelectMC = new System.Windows.Forms.Button();
            this.txtMasterClass = new System.Windows.Forms.RichTextBox();
            this.tabDACode = new System.Windows.Forms.TabPage();
            this.btnSelectDA = new System.Windows.Forms.Button();
            this.txtDACode = new System.Windows.Forms.RichTextBox();
            this.tabBOCode = new System.Windows.Forms.TabPage();
            this.btnSelectBO = new System.Windows.Forms.Button();
            this.txtBOCode = new System.Windows.Forms.RichTextBox();
            this.tabBOCollection = new System.Windows.Forms.TabPage();
            this.button1 = new System.Windows.Forms.Button();
            this.txtBOCollection = new System.Windows.Forms.RichTextBox();
            this.saveFileDialog1 = new System.Windows.Forms.SaveFileDialog();
            this.tabCodeWizard.SuspendLayout();
            this.tabTable.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgFields)).BeginInit();
            this.tabSP.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgSP)).BeginInit();
            this.tabClass.SuspendLayout();
            this.gbxDA.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgDataAccess)).BeginInit();
            this.gbxBO.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgBusinessObject)).BeginInit();
            this.gbxMasterClass.SuspendLayout();
            this.tabInsert.SuspendLayout();
            this.tabUpdate.SuspendLayout();
            this.tabDelete.SuspendLayout();
            this.tabGet.SuspendLayout();
            this.tabMCCode.SuspendLayout();
            this.tabDACode.SuspendLayout();
            this.tabBOCode.SuspendLayout();
            this.tabBOCollection.SuspendLayout();
            this.SuspendLayout();
            // 
            // tabCodeWizard
            // 
            this.tabCodeWizard.Controls.Add(this.tabTable);
            this.tabCodeWizard.Controls.Add(this.tabSP);
            this.tabCodeWizard.Controls.Add(this.tabClass);
            this.tabCodeWizard.Controls.Add(this.tabInsert);
            this.tabCodeWizard.Controls.Add(this.tabUpdate);
            this.tabCodeWizard.Controls.Add(this.tabDelete);
            this.tabCodeWizard.Controls.Add(this.tabGet);
            this.tabCodeWizard.Controls.Add(this.tabMCCode);
            this.tabCodeWizard.Controls.Add(this.tabDACode);
            this.tabCodeWizard.Controls.Add(this.tabBOCode);
            this.tabCodeWizard.Controls.Add(this.tabBOCollection);
            this.tabCodeWizard.Location = new System.Drawing.Point(0, 16);
            this.tabCodeWizard.Name = "tabCodeWizard";
            this.tabCodeWizard.SelectedIndex = 0;
            this.tabCodeWizard.Size = new System.Drawing.Size(704, 424);
            this.tabCodeWizard.TabIndex = 0;
            this.tabCodeWizard.SelectedIndexChanged += new System.EventHandler(this.tabCodeWizard_SelectedIndexChanged);
            // 
            // tabTable
            // 
            this.tabTable.Controls.Add(this.cmbProjectName);
            this.tabTable.Controls.Add(this.label13);
            this.tabTable.Controls.Add(this.cmbConnectionType);
            this.tabTable.Controls.Add(this.label19);
            this.tabTable.Controls.Add(this.cmbDataBaseName);
            this.tabTable.Controls.Add(this.label7);
            this.tabTable.Controls.Add(this.chkGetSelectAll);
            this.tabTable.Controls.Add(this.chkDeleteSelectAll);
            this.tabTable.Controls.Add(this.chkUpateSelectAll);
            this.tabTable.Controls.Add(this.chkInsertSelectAll);
            this.tabTable.Controls.Add(this.txtCreatedBy);
            this.tabTable.Controls.Add(this.label17);
            this.tabTable.Controls.Add(this.txtCreatedDate);
            this.tabTable.Controls.Add(this.label18);
            this.tabTable.Controls.Add(this.label16);
            this.tabTable.Controls.Add(this.cmbTableName);
            this.tabTable.Controls.Add(this.dgFields);
            this.tabTable.Location = new System.Drawing.Point(4, 22);
            this.tabTable.Name = "tabTable";
            this.tabTable.Size = new System.Drawing.Size(696, 398);
            this.tabTable.TabIndex = 0;
            this.tabTable.Text = "Step1";
            this.tabTable.Click += new System.EventHandler(this.tabStep1_Click);
            // 
            // cmbProjectName
            // 
            this.cmbProjectName.Items.AddRange(new object[] {
            "----"});
            this.cmbProjectName.Location = new System.Drawing.Point(112, 16);
            this.cmbProjectName.Name = "cmbProjectName";
            this.cmbProjectName.Size = new System.Drawing.Size(192, 21);
            this.cmbProjectName.TabIndex = 51;
            this.cmbProjectName.SelectedIndexChanged += new System.EventHandler(this.cmbProjectName_SelectedIndexChanged);
            // 
            // label13
            // 
            this.label13.Location = new System.Drawing.Point(8, 16);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(88, 16);
            this.label13.TabIndex = 50;
            this.label13.Text = "ProjectName";
            // 
            // cmbConnectionType
            // 
            this.cmbConnectionType.Items.AddRange(new object[] {
            "Sql",
            "OleDB"});
            this.cmbConnectionType.Location = new System.Drawing.Point(504, 72);
            this.cmbConnectionType.Name = "cmbConnectionType";
            this.cmbConnectionType.Size = new System.Drawing.Size(120, 21);
            this.cmbConnectionType.TabIndex = 49;
            // 
            // label19
            // 
            this.label19.Location = new System.Drawing.Point(408, 80);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(88, 16);
            this.label19.TabIndex = 48;
            this.label19.Text = "ConnectionType";
            // 
            // cmbDataBaseName
            // 
            this.cmbDataBaseName.Items.AddRange(new object[] {
            "----"});
            this.cmbDataBaseName.Location = new System.Drawing.Point(112, 48);
            this.cmbDataBaseName.Name = "cmbDataBaseName";
            this.cmbDataBaseName.Size = new System.Drawing.Size(192, 21);
            this.cmbDataBaseName.TabIndex = 47;
            this.cmbDataBaseName.SelectedIndexChanged += new System.EventHandler(this.cmbDataBaseName_SelectedIndexChanged);
            // 
            // label7
            // 
            this.label7.Location = new System.Drawing.Point(8, 48);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(88, 16);
            this.label7.TabIndex = 46;
            this.label7.Text = "DataBaseName";
            // 
            // chkGetSelectAll
            // 
            this.chkGetSelectAll.Location = new System.Drawing.Point(624, 40);
            this.chkGetSelectAll.Name = "chkGetSelectAll";
            this.chkGetSelectAll.Size = new System.Drawing.Size(48, 24);
            this.chkGetSelectAll.TabIndex = 45;
            this.chkGetSelectAll.Text = "Get";
            // 
            // chkDeleteSelectAll
            // 
            this.chkDeleteSelectAll.Location = new System.Drawing.Point(552, 40);
            this.chkDeleteSelectAll.Name = "chkDeleteSelectAll";
            this.chkDeleteSelectAll.Size = new System.Drawing.Size(56, 24);
            this.chkDeleteSelectAll.TabIndex = 44;
            this.chkDeleteSelectAll.Text = "Delete";
            // 
            // chkUpateSelectAll
            // 
            this.chkUpateSelectAll.Location = new System.Drawing.Point(472, 40);
            this.chkUpateSelectAll.Name = "chkUpateSelectAll";
            this.chkUpateSelectAll.Size = new System.Drawing.Size(64, 24);
            this.chkUpateSelectAll.TabIndex = 43;
            this.chkUpateSelectAll.Text = "Update";
            // 
            // chkInsertSelectAll
            // 
            this.chkInsertSelectAll.Location = new System.Drawing.Point(408, 40);
            this.chkInsertSelectAll.Name = "chkInsertSelectAll";
            this.chkInsertSelectAll.Size = new System.Drawing.Size(56, 24);
            this.chkInsertSelectAll.TabIndex = 42;
            this.chkInsertSelectAll.Text = "Insert";
            this.chkInsertSelectAll.CheckedChanged += new System.EventHandler(this.chkInsertSelectAll_CheckedChanged);
            // 
            // txtCreatedBy
            // 
            this.txtCreatedBy.Location = new System.Drawing.Point(96, 368);
            this.txtCreatedBy.Name = "txtCreatedBy";
            this.txtCreatedBy.Size = new System.Drawing.Size(168, 20);
            this.txtCreatedBy.TabIndex = 40;
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(16, 368);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(61, 13);
            this.label17.TabIndex = 41;
            this.label17.Text = "Created BY";
            // 
            // txtCreatedDate
            // 
            this.txtCreatedDate.Location = new System.Drawing.Point(376, 368);
            this.txtCreatedDate.Name = "txtCreatedDate";
            this.txtCreatedDate.Size = new System.Drawing.Size(168, 20);
            this.txtCreatedDate.TabIndex = 38;
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(288, 368);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(70, 13);
            this.label18.TabIndex = 39;
            this.label18.Text = "Created Date";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(8, 80);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(65, 13);
            this.label16.TabIndex = 36;
            this.label16.Text = "Table Name";
            // 
            // cmbTableName
            // 
            this.cmbTableName.Location = new System.Drawing.Point(112, 80);
            this.cmbTableName.Name = "cmbTableName";
            this.cmbTableName.Size = new System.Drawing.Size(280, 21);
            this.cmbTableName.TabIndex = 1;
            this.cmbTableName.SelectedIndexChanged += new System.EventHandler(this.cmbTableName_SelectedIndexChanged);
            this.cmbTableName.SelectedValueChanged += new System.EventHandler(this.cmbTableName_SelectedValueChanged);
            // 
            // dgFields
            // 
            this.dgFields.AllowSorting = false;
            this.dgFields.CaptionVisible = false;
            this.dgFields.DataMember = "";
            this.dgFields.HeaderForeColor = System.Drawing.SystemColors.ControlText;
            this.dgFields.Location = new System.Drawing.Point(16, 112);
            this.dgFields.Name = "dgFields";
            this.dgFields.Size = new System.Drawing.Size(672, 248);
            this.dgFields.TabIndex = 0;
            this.dgFields.Navigate += new System.Windows.Forms.NavigateEventHandler(this.dgFields_Navigate);
            // 
            // tabSP
            // 
            this.tabSP.Controls.Add(this.dgSP);
            this.tabSP.Controls.Add(this.btnGenerateSP);
            this.tabSP.Location = new System.Drawing.Point(4, 22);
            this.tabSP.Name = "tabSP";
            this.tabSP.Size = new System.Drawing.Size(696, 398);
            this.tabSP.TabIndex = 6;
            this.tabSP.Text = "SP ";
            this.tabSP.Click += new System.EventHandler(this.tabSP_Click);
            // 
            // dgSP
            // 
            this.dgSP.AllowSorting = false;
            this.dgSP.CaptionVisible = false;
            this.dgSP.CausesValidation = false;
            this.dgSP.ColumnHeadersVisible = false;
            this.dgSP.DataMember = "";
            this.dgSP.HeaderForeColor = System.Drawing.SystemColors.ControlText;
            this.dgSP.Location = new System.Drawing.Point(8, 17);
            this.dgSP.Name = "dgSP";
            this.dgSP.ParentRowsVisible = false;
            this.dgSP.PreferredRowHeight = 20;
            this.dgSP.RowHeadersVisible = false;
            this.dgSP.Size = new System.Drawing.Size(680, 199);
            this.dgSP.TabIndex = 3;
            // 
            // btnGenerateSP
            // 
            this.btnGenerateSP.Location = new System.Drawing.Point(256, 248);
            this.btnGenerateSP.Name = "btnGenerateSP";
            this.btnGenerateSP.Size = new System.Drawing.Size(75, 23);
            this.btnGenerateSP.TabIndex = 2;
            this.btnGenerateSP.Text = "Generate";
            this.btnGenerateSP.Click += new System.EventHandler(this.btnGenerateSP_Click);
            // 
            // tabClass
            // 
            this.tabClass.Controls.Add(this.label4);
            this.tabClass.Controls.Add(this.txtDBConnect);
            this.tabClass.Controls.Add(this.btnClassGenerator);
            this.tabClass.Controls.Add(this.chkDataAccess);
            this.tabClass.Controls.Add(this.gbxDA);
            this.tabClass.Controls.Add(this.chkMasterClass);
            this.tabClass.Controls.Add(this.label9);
            this.tabClass.Controls.Add(this.txtNamespace);
            this.tabClass.Controls.Add(this.chkBusinessObject);
            this.tabClass.Controls.Add(this.gbxBO);
            this.tabClass.Controls.Add(this.gbxMasterClass);
            this.tabClass.Location = new System.Drawing.Point(4, 22);
            this.tabClass.Name = "tabClass";
            this.tabClass.Size = new System.Drawing.Size(696, 398);
            this.tabClass.TabIndex = 1;
            this.tabClass.Text = "Classes";
            this.tabClass.Click += new System.EventHandler(this.tabStep2_Click);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(368, 8);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(105, 13);
            this.label4.TabIndex = 45;
            this.label4.Text = "DB Connect Handler";
            // 
            // txtDBConnect
            // 
            this.txtDBConnect.Location = new System.Drawing.Point(480, 8);
            this.txtDBConnect.Name = "txtDBConnect";
            this.txtDBConnect.Size = new System.Drawing.Size(168, 20);
            this.txtDBConnect.TabIndex = 44;
            this.txtDBConnect.Text = "DaTradeannex";
            // 
            // btnClassGenerator
            // 
            this.btnClassGenerator.Location = new System.Drawing.Point(312, 368);
            this.btnClassGenerator.Name = "btnClassGenerator";
            this.btnClassGenerator.Size = new System.Drawing.Size(75, 23);
            this.btnClassGenerator.TabIndex = 43;
            this.btnClassGenerator.Text = "Generate";
            this.btnClassGenerator.Click += new System.EventHandler(this.btnClassGenerator_Click);
            // 
            // chkDataAccess
            // 
            this.chkDataAccess.Checked = true;
            this.chkDataAccess.CheckState = System.Windows.Forms.CheckState.Checked;
            this.chkDataAccess.Location = new System.Drawing.Point(21, 128);
            this.chkDataAccess.Name = "chkDataAccess";
            this.chkDataAccess.Size = new System.Drawing.Size(112, 16);
            this.chkDataAccess.TabIndex = 41;
            this.chkDataAccess.Text = "Data Access";
            // 
            // gbxDA
            // 
            this.gbxDA.Controls.Add(this.chkChildClass);
            this.gbxDA.Controls.Add(this.dgDataAccess);
            this.gbxDA.Controls.Add(this.txtDAParentClass);
            this.gbxDA.Controls.Add(this.label10);
            this.gbxDA.Controls.Add(this.txtDAComments);
            this.gbxDA.Controls.Add(this.label2);
            this.gbxDA.Controls.Add(this.txtDAClassName);
            this.gbxDA.Controls.Add(this.label5);
            this.gbxDA.Location = new System.Drawing.Point(24, 128);
            this.gbxDA.Name = "gbxDA";
            this.gbxDA.Size = new System.Drawing.Size(328, 232);
            this.gbxDA.TabIndex = 7;
            this.gbxDA.TabStop = false;
            // 
            // chkChildClass
            // 
            this.chkChildClass.Location = new System.Drawing.Point(0, 96);
            this.chkChildClass.Name = "chkChildClass";
            this.chkChildClass.Size = new System.Drawing.Size(104, 24);
            this.chkChildClass.TabIndex = 49;
            this.chkChildClass.Text = "Child Class";
            // 
            // dgDataAccess
            // 
            this.dgDataAccess.AlternatingBackColor = System.Drawing.Color.OldLace;
            this.dgDataAccess.BackColor = System.Drawing.Color.OldLace;
            this.dgDataAccess.BackgroundColor = System.Drawing.Color.Tan;
            this.dgDataAccess.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.dgDataAccess.CaptionBackColor = System.Drawing.Color.SaddleBrown;
            this.dgDataAccess.CaptionForeColor = System.Drawing.Color.OldLace;
            this.dgDataAccess.DataMember = "";
            this.dgDataAccess.FlatMode = true;
            this.dgDataAccess.Font = new System.Drawing.Font("Tahoma", 8F);
            this.dgDataAccess.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.dgDataAccess.GridLineColor = System.Drawing.Color.Tan;
            this.dgDataAccess.HeaderBackColor = System.Drawing.Color.Wheat;
            this.dgDataAccess.HeaderFont = new System.Drawing.Font("Tahoma", 8F, System.Drawing.FontStyle.Bold);
            this.dgDataAccess.HeaderForeColor = System.Drawing.Color.SaddleBrown;
            this.dgDataAccess.LinkColor = System.Drawing.Color.DarkSlateBlue;
            this.dgDataAccess.Location = new System.Drawing.Point(8, 120);
            this.dgDataAccess.Name = "dgDataAccess";
            this.dgDataAccess.ParentRowsBackColor = System.Drawing.Color.OldLace;
            this.dgDataAccess.ParentRowsForeColor = System.Drawing.Color.DarkSlateGray;
            this.dgDataAccess.RowHeaderWidth = 20;
            this.dgDataAccess.SelectionBackColor = System.Drawing.Color.SlateGray;
            this.dgDataAccess.SelectionForeColor = System.Drawing.Color.White;
            this.dgDataAccess.Size = new System.Drawing.Size(312, 96);
            this.dgDataAccess.TabIndex = 48;
            // 
            // txtDAParentClass
            // 
            this.txtDAParentClass.Location = new System.Drawing.Point(104, 40);
            this.txtDAParentClass.Name = "txtDAParentClass";
            this.txtDAParentClass.Size = new System.Drawing.Size(160, 20);
            this.txtDAParentClass.TabIndex = 46;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(8, 40);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(66, 13);
            this.label10.TabIndex = 47;
            this.label10.Text = "Parent Class";
            // 
            // txtDAComments
            // 
            this.txtDAComments.Location = new System.Drawing.Point(104, 64);
            this.txtDAComments.Multiline = true;
            this.txtDAComments.Name = "txtDAComments";
            this.txtDAComments.Size = new System.Drawing.Size(208, 32);
            this.txtDAComments.TabIndex = 44;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(8, 72);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(56, 13);
            this.label2.TabIndex = 45;
            this.label2.Text = "Comments";
            // 
            // txtDAClassName
            // 
            this.txtDAClassName.Location = new System.Drawing.Point(104, 16);
            this.txtDAClassName.Name = "txtDAClassName";
            this.txtDAClassName.Size = new System.Drawing.Size(160, 20);
            this.txtDAClassName.TabIndex = 40;
            this.txtDAClassName.TextChanged += new System.EventHandler(this.txtDAClassName_TextChanged);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(8, 16);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(63, 13);
            this.label5.TabIndex = 41;
            this.label5.Text = "Class Name";
            // 
            // chkMasterClass
            // 
            this.chkMasterClass.Checked = true;
            this.chkMasterClass.CheckState = System.Windows.Forms.CheckState.Checked;
            this.chkMasterClass.Location = new System.Drawing.Point(22, 32);
            this.chkMasterClass.Name = "chkMasterClass";
            this.chkMasterClass.Size = new System.Drawing.Size(104, 16);
            this.chkMasterClass.TabIndex = 40;
            this.chkMasterClass.Text = "Master Class";
            this.chkMasterClass.CheckedChanged += new System.EventHandler(this.chkMasterClass_CheckedChanged);
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(24, 8);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(95, 13);
            this.label9.TabIndex = 37;
            this.label9.Text = "Namespace Name";
            // 
            // txtNamespace
            // 
            this.txtNamespace.Location = new System.Drawing.Point(128, 8);
            this.txtNamespace.Name = "txtNamespace";
            this.txtNamespace.Size = new System.Drawing.Size(160, 20);
            this.txtNamespace.TabIndex = 36;
            this.txtNamespace.TabIndexChanged += new System.EventHandler(this.txtNamespace_TabIndexChanged);
            // 
            // chkBusinessObject
            // 
            this.chkBusinessObject.Checked = true;
            this.chkBusinessObject.CheckState = System.Windows.Forms.CheckState.Checked;
            this.chkBusinessObject.Location = new System.Drawing.Point(360, 37);
            this.chkBusinessObject.Name = "chkBusinessObject";
            this.chkBusinessObject.Size = new System.Drawing.Size(112, 16);
            this.chkBusinessObject.TabIndex = 42;
            this.chkBusinessObject.Text = "Business Object";
            // 
            // gbxBO
            // 
            this.gbxBO.Controls.Add(this.txtCollectionComment);
            this.gbxBO.Controls.Add(this.label14);
            this.gbxBO.Controls.Add(this.txtCollectionName);
            this.gbxBO.Controls.Add(this.label20);
            this.gbxBO.Controls.Add(this.dgBusinessObject);
            this.gbxBO.Controls.Add(this.txtBODataClass);
            this.gbxBO.Controls.Add(this.label12);
            this.gbxBO.Controls.Add(this.txtBOParentClass);
            this.gbxBO.Controls.Add(this.label11);
            this.gbxBO.Controls.Add(this.txtBOComments);
            this.gbxBO.Controls.Add(this.label6);
            this.gbxBO.Controls.Add(this.txtBOClassName);
            this.gbxBO.Controls.Add(this.label8);
            this.gbxBO.Location = new System.Drawing.Point(360, 40);
            this.gbxBO.Name = "gbxBO";
            this.gbxBO.Size = new System.Drawing.Size(328, 320);
            this.gbxBO.TabIndex = 8;
            this.gbxBO.TabStop = false;
            // 
            // txtCollectionComment
            // 
            this.txtCollectionComment.Location = new System.Drawing.Point(104, 160);
            this.txtCollectionComment.Multiline = true;
            this.txtCollectionComment.Name = "txtCollectionComment";
            this.txtCollectionComment.Size = new System.Drawing.Size(216, 40);
            this.txtCollectionComment.TabIndex = 63;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(8, 168);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(51, 13);
            this.label14.TabIndex = 62;
            this.label14.Text = "Comment";
            // 
            // txtCollectionName
            // 
            this.txtCollectionName.Location = new System.Drawing.Point(104, 136);
            this.txtCollectionName.Name = "txtCollectionName";
            this.txtCollectionName.Size = new System.Drawing.Size(168, 20);
            this.txtCollectionName.TabIndex = 59;
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Location = new System.Drawing.Point(8, 136);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(84, 13);
            this.label20.TabIndex = 60;
            this.label20.Text = "Collection Name";
            // 
            // dgBusinessObject
            // 
            this.dgBusinessObject.AlternatingBackColor = System.Drawing.Color.OldLace;
            this.dgBusinessObject.BackColor = System.Drawing.Color.OldLace;
            this.dgBusinessObject.BackgroundColor = System.Drawing.Color.Tan;
            this.dgBusinessObject.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.dgBusinessObject.CaptionBackColor = System.Drawing.Color.SaddleBrown;
            this.dgBusinessObject.CaptionForeColor = System.Drawing.Color.OldLace;
            this.dgBusinessObject.DataMember = "";
            this.dgBusinessObject.FlatMode = true;
            this.dgBusinessObject.Font = new System.Drawing.Font("Tahoma", 8F);
            this.dgBusinessObject.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.dgBusinessObject.GridLineColor = System.Drawing.Color.Tan;
            this.dgBusinessObject.HeaderBackColor = System.Drawing.Color.Wheat;
            this.dgBusinessObject.HeaderFont = new System.Drawing.Font("Tahoma", 8F, System.Drawing.FontStyle.Bold);
            this.dgBusinessObject.HeaderForeColor = System.Drawing.Color.SaddleBrown;
            this.dgBusinessObject.LinkColor = System.Drawing.Color.DarkSlateBlue;
            this.dgBusinessObject.Location = new System.Drawing.Point(8, 208);
            this.dgBusinessObject.Name = "dgBusinessObject";
            this.dgBusinessObject.ParentRowsBackColor = System.Drawing.Color.OldLace;
            this.dgBusinessObject.ParentRowsForeColor = System.Drawing.Color.DarkSlateGray;
            this.dgBusinessObject.RowHeaderWidth = 20;
            this.dgBusinessObject.SelectionBackColor = System.Drawing.Color.SlateGray;
            this.dgBusinessObject.SelectionForeColor = System.Drawing.Color.White;
            this.dgBusinessObject.Size = new System.Drawing.Size(312, 96);
            this.dgBusinessObject.TabIndex = 58;
            // 
            // txtBODataClass
            // 
            this.txtBODataClass.Location = new System.Drawing.Point(104, 66);
            this.txtBODataClass.Name = "txtBODataClass";
            this.txtBODataClass.Size = new System.Drawing.Size(168, 20);
            this.txtBODataClass.TabIndex = 50;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(8, 66);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(58, 13);
            this.label12.TabIndex = 51;
            this.label12.Text = "Data Class";
            // 
            // txtBOParentClass
            // 
            this.txtBOParentClass.Location = new System.Drawing.Point(104, 41);
            this.txtBOParentClass.Name = "txtBOParentClass";
            this.txtBOParentClass.Size = new System.Drawing.Size(168, 20);
            this.txtBOParentClass.TabIndex = 48;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(8, 41);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(66, 13);
            this.label11.TabIndex = 49;
            this.label11.Text = "Parent Class";
            // 
            // txtBOComments
            // 
            this.txtBOComments.Location = new System.Drawing.Point(104, 88);
            this.txtBOComments.Multiline = true;
            this.txtBOComments.Name = "txtBOComments";
            this.txtBOComments.Size = new System.Drawing.Size(216, 40);
            this.txtBOComments.TabIndex = 44;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(8, 96);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(56, 13);
            this.label6.TabIndex = 45;
            this.label6.Text = "Comments";
            // 
            // txtBOClassName
            // 
            this.txtBOClassName.Location = new System.Drawing.Point(104, 16);
            this.txtBOClassName.Name = "txtBOClassName";
            this.txtBOClassName.Size = new System.Drawing.Size(168, 20);
            this.txtBOClassName.TabIndex = 40;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(8, 16);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(63, 13);
            this.label8.TabIndex = 41;
            this.label8.Text = "Class Name";
            // 
            // gbxMasterClass
            // 
            this.gbxMasterClass.Controls.Add(this.txtMCComments);
            this.gbxMasterClass.Controls.Add(this.label1);
            this.gbxMasterClass.Controls.Add(this.txtMCClassName);
            this.gbxMasterClass.Controls.Add(this.label3);
            this.gbxMasterClass.Location = new System.Drawing.Point(24, 40);
            this.gbxMasterClass.Name = "gbxMasterClass";
            this.gbxMasterClass.Size = new System.Drawing.Size(328, 80);
            this.gbxMasterClass.TabIndex = 6;
            this.gbxMasterClass.TabStop = false;
            // 
            // txtMCComments
            // 
            this.txtMCComments.Location = new System.Drawing.Point(104, 40);
            this.txtMCComments.Multiline = true;
            this.txtMCComments.Name = "txtMCComments";
            this.txtMCComments.Size = new System.Drawing.Size(208, 32);
            this.txtMCComments.TabIndex = 38;
            this.txtMCComments.TextChanged += new System.EventHandler(this.txtMCComments_TextChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(8, 40);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(56, 13);
            this.label1.TabIndex = 39;
            this.label1.Text = "Comments";
            // 
            // txtMCClassName
            // 
            this.txtMCClassName.Location = new System.Drawing.Point(104, 16);
            this.txtMCClassName.Name = "txtMCClassName";
            this.txtMCClassName.Size = new System.Drawing.Size(160, 20);
            this.txtMCClassName.TabIndex = 34;
            this.txtMCClassName.TextChanged += new System.EventHandler(this.txtMCClassName_TextChanged);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(8, 16);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(63, 13);
            this.label3.TabIndex = 35;
            this.label3.Text = "Class Name";
            // 
            // tabInsert
            // 
            this.tabInsert.Controls.Add(this.btnSaveSPInsert);
            this.tabInsert.Controls.Add(this.txtSPInsert);
            this.tabInsert.Location = new System.Drawing.Point(4, 22);
            this.tabInsert.Name = "tabInsert";
            this.tabInsert.Size = new System.Drawing.Size(696, 398);
            this.tabInsert.TabIndex = 2;
            this.tabInsert.Text = "Insert SP";
            this.tabInsert.Click += new System.EventHandler(this.tabStep3_Click);
            // 
            // btnSaveSPInsert
            // 
            this.btnSaveSPInsert.Location = new System.Drawing.Point(24, 8);
            this.btnSaveSPInsert.Name = "btnSaveSPInsert";
            this.btnSaveSPInsert.Size = new System.Drawing.Size(75, 23);
            this.btnSaveSPInsert.TabIndex = 7;
            this.btnSaveSPInsert.Text = "Save";
            this.btnSaveSPInsert.Click += new System.EventHandler(this.btnSaveSPInsert_Click);
            // 
            // txtSPInsert
            // 
            this.txtSPInsert.HideSelection = false;
            this.txtSPInsert.Location = new System.Drawing.Point(19, 40);
            this.txtSPInsert.Name = "txtSPInsert";
            this.txtSPInsert.ScrollBars = System.Windows.Forms.RichTextBoxScrollBars.ForcedBoth;
            this.txtSPInsert.Size = new System.Drawing.Size(669, 312);
            this.txtSPInsert.TabIndex = 6;
            this.txtSPInsert.Text = "";
            // 
            // tabUpdate
            // 
            this.tabUpdate.Controls.Add(this.btnSaveSPUpdate);
            this.tabUpdate.Controls.Add(this.txtSPUpdate);
            this.tabUpdate.Location = new System.Drawing.Point(4, 22);
            this.tabUpdate.Name = "tabUpdate";
            this.tabUpdate.Size = new System.Drawing.Size(696, 398);
            this.tabUpdate.TabIndex = 3;
            this.tabUpdate.Text = "Update SP";
            // 
            // btnSaveSPUpdate
            // 
            this.btnSaveSPUpdate.Location = new System.Drawing.Point(8, 8);
            this.btnSaveSPUpdate.Name = "btnSaveSPUpdate";
            this.btnSaveSPUpdate.Size = new System.Drawing.Size(75, 23);
            this.btnSaveSPUpdate.TabIndex = 9;
            this.btnSaveSPUpdate.Text = "Save";
            this.btnSaveSPUpdate.Click += new System.EventHandler(this.btnSaveSPUpdate_Click);
            // 
            // txtSPUpdate
            // 
            this.txtSPUpdate.Location = new System.Drawing.Point(8, 32);
            this.txtSPUpdate.Name = "txtSPUpdate";
            this.txtSPUpdate.ScrollBars = System.Windows.Forms.RichTextBoxScrollBars.ForcedBoth;
            this.txtSPUpdate.Size = new System.Drawing.Size(680, 312);
            this.txtSPUpdate.TabIndex = 8;
            this.txtSPUpdate.Text = "";
            // 
            // tabDelete
            // 
            this.tabDelete.Controls.Add(this.btnSaveSPDelete);
            this.tabDelete.Controls.Add(this.txtSPDelete);
            this.tabDelete.Location = new System.Drawing.Point(4, 22);
            this.tabDelete.Name = "tabDelete";
            this.tabDelete.Size = new System.Drawing.Size(696, 398);
            this.tabDelete.TabIndex = 4;
            this.tabDelete.Text = "Delete SP";
            // 
            // btnSaveSPDelete
            // 
            this.btnSaveSPDelete.Location = new System.Drawing.Point(8, 16);
            this.btnSaveSPDelete.Name = "btnSaveSPDelete";
            this.btnSaveSPDelete.Size = new System.Drawing.Size(75, 23);
            this.btnSaveSPDelete.TabIndex = 10;
            this.btnSaveSPDelete.Text = "Save";
            this.btnSaveSPDelete.Click += new System.EventHandler(this.btnSaveSPDelete_Click);
            // 
            // txtSPDelete
            // 
            this.txtSPDelete.Location = new System.Drawing.Point(8, 40);
            this.txtSPDelete.Name = "txtSPDelete";
            this.txtSPDelete.ScrollBars = System.Windows.Forms.RichTextBoxScrollBars.ForcedBoth;
            this.txtSPDelete.Size = new System.Drawing.Size(680, 312);
            this.txtSPDelete.TabIndex = 9;
            this.txtSPDelete.Text = "";
            // 
            // tabGet
            // 
            this.tabGet.Controls.Add(this.btnSaveSPGet);
            this.tabGet.Controls.Add(this.txtSPGet);
            this.tabGet.Location = new System.Drawing.Point(4, 22);
            this.tabGet.Name = "tabGet";
            this.tabGet.Size = new System.Drawing.Size(696, 398);
            this.tabGet.TabIndex = 5;
            this.tabGet.Text = "Get SP";
            // 
            // btnSaveSPGet
            // 
            this.btnSaveSPGet.Location = new System.Drawing.Point(8, 16);
            this.btnSaveSPGet.Name = "btnSaveSPGet";
            this.btnSaveSPGet.Size = new System.Drawing.Size(75, 23);
            this.btnSaveSPGet.TabIndex = 11;
            this.btnSaveSPGet.Text = "Save";
            this.btnSaveSPGet.Click += new System.EventHandler(this.btnSaveSPGet_Click);
            // 
            // txtSPGet
            // 
            this.txtSPGet.Location = new System.Drawing.Point(8, 40);
            this.txtSPGet.Name = "txtSPGet";
            this.txtSPGet.ScrollBars = System.Windows.Forms.RichTextBoxScrollBars.ForcedBoth;
            this.txtSPGet.Size = new System.Drawing.Size(680, 304);
            this.txtSPGet.TabIndex = 10;
            this.txtSPGet.Text = "";
            // 
            // tabMCCode
            // 
            this.tabMCCode.Controls.Add(this.btnSelectMC);
            this.tabMCCode.Controls.Add(this.txtMasterClass);
            this.tabMCCode.Location = new System.Drawing.Point(4, 22);
            this.tabMCCode.Name = "tabMCCode";
            this.tabMCCode.Size = new System.Drawing.Size(696, 398);
            this.tabMCCode.TabIndex = 7;
            this.tabMCCode.Text = "MC Code";
            // 
            // btnSelectMC
            // 
            this.btnSelectMC.Location = new System.Drawing.Point(16, 8);
            this.btnSelectMC.Name = "btnSelectMC";
            this.btnSelectMC.Size = new System.Drawing.Size(75, 23);
            this.btnSelectMC.TabIndex = 11;
            this.btnSelectMC.Text = "Select";
            this.btnSelectMC.Click += new System.EventHandler(this.btnSelectMC_Click);
            // 
            // txtMasterClass
            // 
            this.txtMasterClass.Location = new System.Drawing.Point(14, 40);
            this.txtMasterClass.Name = "txtMasterClass";
            this.txtMasterClass.ScrollBars = System.Windows.Forms.RichTextBoxScrollBars.ForcedBoth;
            this.txtMasterClass.Size = new System.Drawing.Size(669, 288);
            this.txtMasterClass.TabIndex = 7;
            this.txtMasterClass.Text = "";
            // 
            // tabDACode
            // 
            this.tabDACode.Controls.Add(this.btnSelectDA);
            this.tabDACode.Controls.Add(this.txtDACode);
            this.tabDACode.Location = new System.Drawing.Point(4, 22);
            this.tabDACode.Name = "tabDACode";
            this.tabDACode.Size = new System.Drawing.Size(696, 398);
            this.tabDACode.TabIndex = 9;
            this.tabDACode.Text = "DA Code";
            // 
            // btnSelectDA
            // 
            this.btnSelectDA.Location = new System.Drawing.Point(16, 16);
            this.btnSelectDA.Name = "btnSelectDA";
            this.btnSelectDA.Size = new System.Drawing.Size(75, 23);
            this.btnSelectDA.TabIndex = 11;
            this.btnSelectDA.Text = "Select";
            this.btnSelectDA.Click += new System.EventHandler(this.btnSelectDA_Click);
            // 
            // txtDACode
            // 
            this.txtDACode.Location = new System.Drawing.Point(14, 48);
            this.txtDACode.Name = "txtDACode";
            this.txtDACode.ScrollBars = System.Windows.Forms.RichTextBoxScrollBars.ForcedBoth;
            this.txtDACode.Size = new System.Drawing.Size(669, 280);
            this.txtDACode.TabIndex = 9;
            this.txtDACode.Text = "";
            // 
            // tabBOCode
            // 
            this.tabBOCode.Controls.Add(this.btnSelectBO);
            this.tabBOCode.Controls.Add(this.txtBOCode);
            this.tabBOCode.Location = new System.Drawing.Point(4, 22);
            this.tabBOCode.Name = "tabBOCode";
            this.tabBOCode.Size = new System.Drawing.Size(696, 398);
            this.tabBOCode.TabIndex = 8;
            this.tabBOCode.Text = "BO Code";
            // 
            // btnSelectBO
            // 
            this.btnSelectBO.Location = new System.Drawing.Point(16, 8);
            this.btnSelectBO.Name = "btnSelectBO";
            this.btnSelectBO.Size = new System.Drawing.Size(75, 23);
            this.btnSelectBO.TabIndex = 11;
            this.btnSelectBO.Text = "Select";
            this.btnSelectBO.Click += new System.EventHandler(this.btnSelectBO_Click);
            // 
            // txtBOCode
            // 
            this.txtBOCode.Location = new System.Drawing.Point(14, 40);
            this.txtBOCode.Name = "txtBOCode";
            this.txtBOCode.ScrollBars = System.Windows.Forms.RichTextBoxScrollBars.ForcedBoth;
            this.txtBOCode.Size = new System.Drawing.Size(669, 288);
            this.txtBOCode.TabIndex = 8;
            this.txtBOCode.Text = "";
            // 
            // tabBOCollection
            // 
            this.tabBOCollection.Controls.Add(this.button1);
            this.tabBOCollection.Controls.Add(this.txtBOCollection);
            this.tabBOCollection.Location = new System.Drawing.Point(4, 22);
            this.tabBOCollection.Name = "tabBOCollection";
            this.tabBOCollection.Size = new System.Drawing.Size(696, 398);
            this.tabBOCollection.TabIndex = 10;
            this.tabBOCollection.Text = "BO Collection";
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(16, 16);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 23);
            this.button1.TabIndex = 12;
            this.button1.Text = "Select";
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // txtBOCollection
            // 
            this.txtBOCollection.Location = new System.Drawing.Point(14, 56);
            this.txtBOCollection.Name = "txtBOCollection";
            this.txtBOCollection.ScrollBars = System.Windows.Forms.RichTextBoxScrollBars.ForcedBoth;
            this.txtBOCollection.Size = new System.Drawing.Size(669, 288);
            this.txtBOCollection.TabIndex = 9;
            this.txtBOCollection.Text = "";
            // 
            // frmFinalCodeGenerator
            // 
            this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
            this.ClientSize = new System.Drawing.Size(712, 446);
            this.Controls.Add(this.tabCodeWizard);
            this.Name = "frmFinalCodeGenerator";
            this.Text = "Code Generator Wizard";
            this.Load += new System.EventHandler(this.frmFinalCodeGenerator_Load);
            this.tabCodeWizard.ResumeLayout(false);
            this.tabTable.ResumeLayout(false);
            this.tabTable.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgFields)).EndInit();
            this.tabSP.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgSP)).EndInit();
            this.tabClass.ResumeLayout(false);
            this.tabClass.PerformLayout();
            this.gbxDA.ResumeLayout(false);
            this.gbxDA.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgDataAccess)).EndInit();
            this.gbxBO.ResumeLayout(false);
            this.gbxBO.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgBusinessObject)).EndInit();
            this.gbxMasterClass.ResumeLayout(false);
            this.gbxMasterClass.PerformLayout();
            this.tabInsert.ResumeLayout(false);
            this.tabUpdate.ResumeLayout(false);
            this.tabDelete.ResumeLayout(false);
            this.tabGet.ResumeLayout(false);
            this.tabMCCode.ResumeLayout(false);
            this.tabDACode.ResumeLayout(false);
            this.tabBOCode.ResumeLayout(false);
            this.tabBOCollection.ResumeLayout(false);
            this.ResumeLayout(false);

		}
		#endregion

		

		private void tabStep1_Click(object sender, System.EventArgs e)
		{
			
			
		}

		private void frmFinalCodeGenerator_Load(object sender, System.EventArgs e)
		{
			FillProjectList();
			txtCreatedDate.Text = DateTime.Now.ToString("dd-mmm-yyyy");		
			cmbConnectionType.SelectedItem  = "Sql";
			//			cmbProjectName.SelectedIndex = 1;
			//			FillDataBaseList();
			//			cmbDataBaseName.SelectedIndex =1;
			//			FillTableList();
			//			
			//			GridDesign("DA");			
			//			FillDataAccessGrid();
			//			GridDesign("BO");
			//			FillBussinessObjectGrid();
			
		}	

		

		private void cmbTableName_SelectedValueChanged(object sender, System.EventArgs e)
		{	
			if(cmbTableName.Items.Count>0)
			{
				GridDesign("DA");			
				FillDataAccessGrid();
				GridDesign("BO");
				FillBussinessObjectGrid();
				
					FieldsGridDesign();
					FillSPGrid();
					txtMCClassName.Text=cmbTableName.SelectedValue.ToString().Replace("_","");
					txtMCClassName_TextChanged(sender,e);
				
			}
		}
		private void txtMCClassName_TextChanged(object sender, System.EventArgs e)
		{			
			txtDAParentClass.Text=txtMCClassName.Text;
			txtBOParentClass.Text=txtMCClassName.Text;
			txtBOClassName.Text="Bo"+txtMCClassName.Text;
			txtDAClassName.Text="Da"+txtMCClassName.Text;
			txtCollectionName.Text = "Bo"+txtMCClassName.Text+"Collection";
		}

		private void txtDAClassName_TextChanged(object sender, System.EventArgs e)
		{
			txtBODataClass.Text=txtDAClassName.Text;
		}

		private void tabStep2_Click(object sender, System.EventArgs e)
		{
		
		}

		private void txtMCComments_TextChanged(object sender, System.EventArgs e)
		{
		
		}

		private void chklstDAMethods_SelectedIndexChanged(object sender, System.EventArgs e)
		{
		
		}

		private void chkMasterClass_CheckedChanged(object sender, System.EventArgs e)
		{
		
		}

		private string GentateSPComment()
		{
			string comment="";
			StringBuilder stringBuilder= null;	
			stringBuilder= new StringBuilder();
			stringBuilder.Append("/******************************************************************************************************"+"\n");
			for(int item=0; item <= dgSP.VisibleRowCount; item++)
			{
				if(item==0)
				{
					comment=dgSP[item,1].ToString();
					stringBuilder.Append("\tPurpose: "+" "+" "+comment+"\n");
					
				}
				if(item==1)
				{
					comment=dgSP[item,1].ToString();
					stringBuilder.Append("\tCreated By: "+" "+" "+comment+"\n");
					
				}
				if(item==2)
				{
					comment=dgSP[item,1].ToString();
					stringBuilder.Append("\tCreated Date: "+" "+" "+comment+"\n");
					
				}
				if(item==3)
				{
					comment=dgSP[item,1].ToString();
					stringBuilder.Append("\tLast Modified By: "+" "+" "+comment+"\n");
					
				}
				if(item==4)
				{
					comment=dgSP[item,1].ToString();
					stringBuilder.Append("\tLast Modified Date: "+" "+" "+comment+"\n");
					
				}
				if(item==5)
				{
					comment=dgSP[item,1].ToString();
					stringBuilder.Append("\tChange History: "+" "+" "+comment+"\n");
					
				}
				if(item==6)
				{
					comment=dgSP[item,1].ToString();
					stringBuilder.Append("\tTable Used: "+" "+" "+comment+"\n");
				
					
				}
			}
			stringBuilder.Append("******************************************************************************************************/"+"\n");
			return stringBuilder.ToString();
			
			
		}

		private void btnGenerateSP_Click(object sender, System.EventArgs e)
		{
			string tableName=cmbTableName.SelectedValue.ToString();


			RichTextBox txtSp=new RichTextBox();

			ArrayList Procedures=new ArrayList();
			Procedures.Add("ins");
			Procedures.Add("upd");
			Procedures.Add("del");
			Procedures.Add("get");
			StringBuilder stringBuilder= null;			
			
			for(int procedureCount=0;procedureCount<Procedures.Count;procedureCount++)
			{
				stringBuilder= new StringBuilder();
				stringBuilder.Append("CREATE PROCEDURE "+" "+"usp_"+Procedures[procedureCount].ToString()+tableName +"\n");

				stringBuilder.Append(GetInputParameters(Procedures[procedureCount].ToString(),true,true));
				
				stringBuilder.Append(" AS\n");

				//comments of sp datagrid
				stringBuilder.Append(GentateSPComment());

				stringBuilder.Append("BEGIN\n");
				
				//				if(!Procedures[procedureCount].Equals("get"))
				//				{
				//					stringBuilder.Append("BEGIN TRANSACTION\n");
				//				}
				switch(Procedures[procedureCount].ToString())
				{
					case "ins":
					{
						stringBuilder.Append("Insert into "+tableName+"\n(");
						stringBuilder.Append(GetFields(ProcedureType.Insert,false));
						txtSp=txtSPInsert;
						stringBuilder.Append(")\n");
						stringBuilder.Append("values(\n");
						stringBuilder.Append(GetInputParameters(Procedures[procedureCount].ToString(),false,true));
						stringBuilder.Append(")\n");
						break;
					}
					case "upd":
					{
						txtSp=txtSPUpdate;
						stringBuilder.Append("update "+tableName+" set \n");
						stringBuilder.Append(GetFields(ProcedureType.Update,false));

						break;
					}
					case "del":
					{
						stringBuilder.Append("Delete "+tableName+ " where\n");
						stringBuilder.Append(GetFields(ProcedureType.Delete,false));
						txtSp=txtSPDelete;
						break;
					}
					case "get":
					{
						txtSp=txtSPGet;
						stringBuilder.Append("Select ");
						stringBuilder.Append(GetFields(ProcedureType.Get,false));
						stringBuilder.Append(" from "+tableName+ " where\n");
						stringBuilder.Append(GetFields(ProcedureType.Get,true));
						break;
					}
				}
				
				
		

				//				if(!Procedures[procedureCount].Equals("Get"))
				//				{
				//					stringBuilder.Append("\nif(@@ERROR>0 )\n");
				//					stringBuilder.Append("\tBEGIN\n");	
				//					stringBuilder.Append("\t\tROLLBACK TRANSACTION\n");
				//					stringBuilder.Append("\t\tRETURN\n");
				//					stringBuilder.Append("\tEND\n");
				//					stringBuilder.Append("COMMIT TRANSACTION\n");
				//				}
				stringBuilder.Append("\nEND\n");
				
				
				txtSp.Text = stringBuilder.ToString();
			}
		}

		private void tabStep3_Click(object sender, System.EventArgs e)
		{
		
		}

		private void dgFields_Navigate(object sender, System.Windows.Forms.NavigateEventArgs ne)
		{
		
		}

		private void tabSP_Click(object sender, System.EventArgs e)
		{
		
		}

		private void chkInsertSelectAll_CheckedChanged(object sender, System.EventArgs e)
		{
			if(chkInsertSelectAll.Checked)
			{
								
			}
		}

		private void btnClassGenerator_Click(object sender, System.EventArgs e)
		{
			if(chkMasterClass.Checked)
				GenerateMasterClass();
			if(chkBusinessObject.Checked)
				GenerateBOClass();
			if(chkDataAccess.Checked)
				GenerateDAClass();

		}

		private void btnSaveSPInsert_Click(object sender, System.EventArgs e)
		{
			saveFileDialog1.ShowDialog();
			txtSPInsert.SelectAll();
			txtSPInsert.SaveFile(saveFileDialog1.FileName,RichTextBoxStreamType.PlainText);
		}

		private void btnSaveSPUpdate_Click(object sender, System.EventArgs e)
		{
			saveFileDialog1.ShowDialog();
			txtSPUpdate.SelectAll();
			txtSPUpdate.SaveFile(saveFileDialog1.FileName,RichTextBoxStreamType.PlainText);
		}

		private void btnSaveSPDelete_Click(object sender, System.EventArgs e)
		{
			saveFileDialog1.ShowDialog();
			txtSPDelete.SelectAll();
			txtSPDelete.SaveFile(saveFileDialog1.FileName,RichTextBoxStreamType.PlainText);
		}

		private void btnSaveSPGet_Click(object sender, System.EventArgs e)
		{			
			txtSPGet.SelectAll();
			txtSPGet.SaveFile(saveFileDialog1.FileName,RichTextBoxStreamType.PlainText);
		}

		private void btnSelectMC_Click(object sender, System.EventArgs e)
		{
			txtMasterClass.SelectAll();
		}

		private void btnSelectDA_Click(object sender, System.EventArgs e)
		{
			txtDACode.SelectAll();
		}

		private void btnSelectBO_Click(object sender, System.EventArgs e)
		{
			txtBOCode.SelectAll();
		}

		private void cmbDataBaseName_SelectedIndexChanged(object sender, System.EventArgs e)
		{
			if(cmbDataBaseName.SelectedIndex >= 0)
			{
				FillTableList();
			}
		}

		private void txtNamespace_TabIndexChanged(object sender, System.EventArgs e)
		{
			if(txtNamespace.Text.Length ==0)
			{
				txtNamespace.Focus();
			}
		}

		private void cmbProjectName_SelectedIndexChanged(object sender, System.EventArgs e)
		{
			if (cmbProjectName.SelectedIndex >= 0)
				FillDataBaseList();
		}

		private void button1_Click(object sender, System.EventArgs e)
		{
			txtBOCollection.SelectAll();
		}

		private void tabCodeWizard_SelectedIndexChanged(object sender, System.EventArgs e)
		{
		
		}

		private void cmbTableName_SelectedIndexChanged(object sender, System.EventArgs e)
		{
		
		}

	

		

	}
}
