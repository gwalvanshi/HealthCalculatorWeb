﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Configuration;
namespace CS.BoleynCinema.WinService
{
    public class Logger
    {
        public static string Address = System.Configuration.ConfigurationManager.AppSettings["BaseAddress"].ToString();       
        public static void Log(string logMessage, string methodName,int usedId)
        {
            Uri url = new Uri(Address);
            var activityLogConnection = new BoleynDataService.Container(url);
            var activityLog = new BoleynDataService.ActivityLog
            {
                LogId=0,
               UserId=usedId,
               LogMessage=logMessage,
               MethodName=methodName,
               LogDate=DateTime.Now
            };
            activityLogConnection.AddToActivityLogs(activityLog);
            activityLogConnection.SaveChanges();
            activityLogConnection = null;
            url = null;
        }

        //public static void LogError(string logMessage, string methodName)
        //{
        //    string message = string.Format("Time: {0}", DateTime.Now.ToString("dd/MM/yyyy hh:mm:ss tt"));
        //    message += Environment.NewLine;
        //    message += "-----------------------------------------------------------";
        //    message += Environment.NewLine;
        //    message += string.Format("Method: {0}", methodName);
        //    message += Environment.NewLine;
        //    message += string.Format("Message: {0}", logMessage);
        //    message += Environment.NewLine;
        //    message += "-----------------------------------------------------------";
        //    message += Environment.NewLine;
        //    string path = ConfigurationSettings.AppSettings["ErrorLogFile"].ToString();
        //    using (StreamWriter writer = new StreamWriter(path, true))
        //    {
        //        writer.WriteLine(message);
        //        writer.Close();
        //    }
        //}

        //public static void LogError(string logMessage, string methodName)
        //{

        //    using (StreamWriter w = File.AppendText("ErrorLog.txt"))
        //    {

        //        Log(logMessage, methodName, w);             

        //    }

        //}



        //public static void Log(string logMessage, string  methodName,TextWriter w)
        //{

        //    w.Write("\r\nLog Entry : ");

        //    w.WriteLine("{0} {1}", DateTime.Now.ToLongTimeString(),

        //        DateTime.Now.ToLongDateString());

        //    w.WriteLine("  :");

        //    w.WriteLine("  :{0}", logMessage + "  " + methodName);

        //    w.WriteLine("-------------------------------");

        //}
    }
}
