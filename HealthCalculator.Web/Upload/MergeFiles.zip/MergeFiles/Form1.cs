﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MergeFiles
{
    public partial class Form1 : Form
    {
        private System.Windows.Forms.Label lblMessage= new Label();
        private System.ComponentModel.BackgroundWorker backgroundWorker1= new BackgroundWorker();
        public Form1()
        {
           
            InitializeComponent();
            backgroundWorker1.DoWork += new DoWorkEventHandler(backgroundWorker1_DoWork);
            backgroundWorker1.RunWorkerCompleted += new RunWorkerCompletedEventHandler(backgroundWorker1_RunWorkerCompleted);
            backgroundWorker1.ProgressChanged += new ProgressChangedEventHandler(backgroundWorker1_ProgressChanged);
            MergeFileLocation.ReadOnly = true;

        }
        private void backgroundWorker1_ProgressChanged(object sender,
           ProgressChangedEventArgs e)
        {
            // resultLabel.Text = e.ProgressPercentage.ToString();
            //this.progressBar1.Value = e.ProgressPercentage;
        }
        private void backgroundWorker1_RunWorkerCompleted(
          object sender, RunWorkerCompletedEventArgs e)
        {
            // First, handle the case where an exception was thrown.
            if (e.Error != null)
            {
                MessageBox.Show(e.Error.Message);
            }
            else if (e.Cancelled)
            {
                // Next, handle the case where the user canceled 
                // the operation.
                // Note that due to a race condition in 
                // the DoWork event handler, the Cancelled
                // flag may not have been set, even though
                // CancelAsync was called.
                lblMessage.Text = "Canceled";
            }
            else
            {
                // Finally, handle the case where the operation 
                // succeeded.
                lblMessage.Text = "data";
            }

          
        }
        private void THREAD_MOD(string teste)
        {
            label2.Text = teste;
        }
        private void backgroundWorker1_DoWork(object sender,
           DoWorkEventArgs e)
        {
            // Get the BackgroundWorker that raised this event.
            BackgroundWorker worker = sender as BackgroundWorker;

            // Assign the result of the computation
            // to the Result property of the DoWorkEventArgs
            // object. This is will be available to the 
            // RunWorkerCompleted eventhandler.
            //  e.Result = ComputeFibonacci((int)e.Argument, worker, e);

            try
            {
               
                Action<string> DelegateTeste_ModifyText = THREAD_MOD;
                Invoke(DelegateTeste_ModifyText, "Merge is started.Please do not close the window.......");
                string outPath = e.Argument.ToString(); // Substitute this with your Input Folder           
                string prevFileName = "";
                string maiFileName = "";
                List<string> strDir = GetAllDir(e.Argument.ToString());
                foreach (var Dir in strDir)
                {
                    FileStream outputFile = null;
                    foreach (string tempFile in Directory.GetFiles(Dir, "*.tmp"))
                    {

                        int dotCount = tempFile.ToCharArray().Count(c => c == '.');
                        string fileName = Path.GetFileNameWithoutExtension(tempFile);
                        string baseFileName = "Video";//fileName.Substring(0, fileName.IndexOf(".A~~"));
                        string extension = string.Empty;
                        if (dotCount > 2)
                        {
                            extension = Path.GetExtension(fileName);
                        }
                        string[] outPutDirArray = Dir.Split('\\');
                        int dirLenght = outPutDirArray.Length;
                        string outPutDir = string.Empty;
                        for (int i = 0; i < dirLenght - 1; i++)
                        {
                            outPutDir += outPutDirArray[i] + @"\";
                        }

                        //string outPutCurretPath = Dir + @"\";
                        string outPutCurretPath = outPutDir;

                        if (!prevFileName.Equals(baseFileName))
                        {
                            if (outputFile != null)
                            {
                                outputFile.Flush();
                                outputFile.Close();
                            }
                            outputFile = new FileStream(outPutCurretPath + baseFileName + extension, FileMode.OpenOrCreate, FileAccess.Write);
                        }

                        int bytesRead = 0;
                        byte[] buffer = new byte[1024];
                        FileStream inputTempFile = new FileStream(tempFile, FileMode.OpenOrCreate, FileAccess.Read);

                        while ((bytesRead = inputTempFile.Read(buffer, 0, 1024)) > 0)
                            outputFile.Write(buffer, 0, bytesRead);

                        inputTempFile.Close();
                        System.IO.File.Delete(tempFile);
                        prevFileName = baseFileName;
                    }
                    if (outputFile != null)
                    {
                        outputFile.Close();

                    }
                    if (Directory.GetFiles(Dir).Length > 0)
                    {
                        Directory.Delete(Dir, true);
                    }
                }
                string[] tmpManDirFiles = Directory.GetFiles(e.Argument.ToString(), "*.tmp");
                if (tmpManDirFiles.Length > 1)
                {
                    outPath = outPath + @"\";
                    FileStream outputDirFile = null;
                    foreach (string tempDirFile in Directory.GetFiles(e.Argument.ToString(), "*.tmp"))
                    {
                        string fileName = Path.GetFileNameWithoutExtension(tempDirFile);
                        string baseFileName = fileName.Substring(0, fileName.IndexOf(Convert.ToChar(".")));
                        string extension = Path.GetExtension(fileName);

                        if (!maiFileName.Equals(baseFileName))
                        {
                            if (outputDirFile != null)
                            {
                                outputDirFile.Flush();
                                outputDirFile.Close();
                            }
                            outputDirFile = new FileStream(outPath + baseFileName + extension, FileMode.OpenOrCreate, FileAccess.Write);
                        }

                        int bytesRead = 0;
                        byte[] buffer = new byte[1024];
                        FileStream inputTempFile = new FileStream(tempDirFile, FileMode.OpenOrCreate, FileAccess.Read);

                        while ((bytesRead = inputTempFile.Read(buffer, 0, 1024)) > 0)
                            outputDirFile.Write(buffer, 0, bytesRead);

                        inputTempFile.Close();
                        System.IO.File.Delete(tempDirFile);
                        maiFileName = baseFileName;
                    }
                    if (outputDirFile != null)
                    {
                        outputDirFile.Close();

                    }
                }
                Action<string> DelegateTeste_ModifyText2 = THREAD_MOD;
                Invoke(DelegateTeste_ModifyText2, "");
                MessageBox.Show("Merge sucessfully");

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                // Logger.Log("Merge", ex.Message);               

            }
        }
        public List<string> GetAllDir(string directory)
        {
            return Directory.GetDirectories(directory, "*.*", SearchOption.AllDirectories).ToList();
        }
        private void Merge_Click(object sender, EventArgs e)
        {

            string DirectoryName = MergeFileLocation.Text.Trim();
            backgroundWorker1.RunWorkerAsync(DirectoryName);

        }

        private void btnBrowseFile_Click(object sender, EventArgs e)
        {
            FolderBrowserDialog fbd = new FolderBrowserDialog();
            DialogResult result = fbd.ShowDialog();
            if ((result == DialogResult.OK))
            {
                MergeFileLocation.Text = fbd.SelectedPath;
            }
        }
    }
}
